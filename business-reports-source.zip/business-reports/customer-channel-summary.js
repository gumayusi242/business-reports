const LEVELS = ['A', 'B', 'C', 'D', 'S'];
const money = value => {
  const text = String(value ?? '').trim();
  if (!/^-?\d+(?:\.\d{1,2})?$/.test(text)) throw new Error('销货净额异常，请刷新并核对客户数据。');
  const [whole, fraction = ''] = text.replace('-', '').split('.');
  const cents = (Number(whole) * 100 + Number(fraction.padEnd(2, '0'))) * (text.startsWith('-') ? -1 : 1);
  if (!Number.isSafeInteger(cents)) throw new Error('销货净额超出可汇总范围。');
  return cents;
};
const sum = (a, b) => {
  const value = a + b;
  if (!Number.isSafeInteger(value)) throw new Error('汇总金额超出可计算范围。');
  return value;
};
const ratio = (value, total) => total === 0 ? null : value / total;

const INDIRECT_INDUSTRIES = ['渠道@经销商', '渠道@经销商备案客户', '渠道@贸易商'];
const CONTRACT_INDUSTRY = '经销商@经销商';

export function summarizeChannels(records, metadata = {}) {
  const rows = LEVELS.map(grade => ({grade, directCount: 0, indirectCount: 0, contractCount: 0, directCents: 0, indirectCents: 0, contractCents: 0}));
  let excluded = 0;
  for (const record of records) {
    const row = rows.find(row => row.grade === record.currentGrade);
    const industry = String(record.industry || '').trim();
    const group = industry === CONTRACT_INDUSTRY ? 'contract' : INDIRECT_INDUSTRIES.includes(industry) ? 'indirect' : record.customerGroup === '普通客户' ? 'direct' : null;
    if (!row || !group || record.customerGroup === '废料回收') {excluded++; continue;}
    row[group + 'Count']++;
    row[group + 'Cents'] = sum(row[group + 'Cents'], money(record.amount));
  }
  const total = rows.reduce((total, row) => {
    for (const group of ['direct', 'indirect', 'contract']) {
      total[group + 'Count'] += row[group + 'Count'];
      total[group + 'Cents'] = sum(total[group + 'Cents'], row[group + 'Cents']);
    }
    return total;
  }, {directCount: 0, indirectCount: 0, contractCount: 0, directCents: 0, indirectCents: 0, contractCents: 0});
  const build = (left, right) => {
    const values = row => {
      const a = left(row), b = right(row), ta = left(total), tb = right(total);
      return [row.grade, a.count, ratio(a.count, ta.count), a.cents / 100, ratio(a.cents, ta.cents),
        b.count, ratio(b.count, tb.count), b.cents / 100, ratio(b.cents, tb.cents),
        a.count + b.count, ratio(a.count + b.count, ta.count + tb.count), sum(a.cents, b.cents) / 100,
        ratio(sum(a.cents, b.cents), sum(ta.cents, tb.cents))];
    };
    return {rows: rows.map(values), total: values({...total, grade: '合计'})};
  };
  const direct = row => ({count: row.directCount, cents: row.directCents});
  const indirect = row => ({count: row.indirectCount, cents: row.indirectCents});
  const contract = row => ({count: row.contractCount, cents: row.contractCents});
  const customers = row => ({count: row.directCount + row.indirectCount, cents: sum(row.directCents, row.indirectCents)});
  return {...metadata, primary: build(customers, contract), customerDetail: build(direct, indirect), excluded};
}

const percentageColumns = [2, 4, 6, 8, 10, 12, 14, 16];
export function combinedSummaryRows(summary) {
  const combine = (detail, primary) => [detail[0], ...detail.slice(1, 9), ...primary.slice(5)];
  return [...summary.customerDetail.rows.map((row, i) => combine(row, summary.primary.rows[i])), combine(summary.customerDetail.total, summary.primary.total)];
}
export function channelSummaryHtml(summary, escapeHtml) {
  const row = values => '<tr>' + values.map((value, column) => `<${column ? 'td' : 'th'}>${value == null ? '—' : column === 0 ? escapeHtml(value) : percentageColumns.includes(column) ? value === 1 ? '100%' : (value * 100).toFixed(2) + '%' : Number([3, 7, 11, 15].includes(column) ? value / 10000 : value).toLocaleString('zh-CN', {minimumFractionDigits: [3, 7, 11, 15].includes(column) ? 2 : 0, maximumFractionDigits: 2})}</${column ? 'td' : 'th'}>`).join('') + '</tr>';
  const rows = combinedSummaryRows(summary);
  const metrics = '<th>客户数</th><th>客户占比</th><th>销售额</th><th>销售额占比</th>';
  return `<div class="cc-summary-scroll"><table class="cc-summary-table cc-single-table"><colgroup><col style="width:3%">${'<col style="width:5.5%"><col style="width:5.5%"><col style="width:7.5%"><col style="width:5.75%">'.repeat(4)}</colgroup><thead><tr><th rowspan="3">等级</th><th colspan="8">客户</th><th colspan="4" rowspan="2">签约经销商</th><th colspan="4" rowspan="2">全部合计</th></tr><tr><th colspan="4">直接客户</th><th colspan="4">间接客户</th></tr><tr>${metrics.repeat(4)}</tr></thead><tbody>${rows.slice(0,5).map(row).join('')}</tbody><tfoot>${row(rows[5])}</tfoot></table></div>`;
}

const xml = value => String(value ?? '').replace(/[<>&"']/g, ch => ({'<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;'}[ch]));
const columnName = index => String.fromCharCode(65 + index);
const numeric = (ref, value, style, formula) => value == null ? `<c r="${ref}" s="${style}" t="str">${formula ? `<f>${xml(formula)}</f>` : ''}<v>—</v></c>` : `<c r="${ref}" s="${style}">${formula ? `<f>${xml(formula)}</f>` : ''}<v>${value}</v></c>`;
const textCell = (ref, value, style = 0) => `<c r="${ref}" s="${style}" t="inlineStr"><is><t xml:space="preserve">${xml(value)}</t></is></c>`;

export async function buildChannelSummaryXlsx(summary, Zip) {
  if (!Zip) throw new Error('Excel组件尚未加载，请刷新页面后重试。');
  const zip = new Zip(), NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
  zip.file('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>');
  zip.file('_rels/.rels', '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
  zip.file('xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="${NS}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="等级与渠道占比汇总" sheetId="1" r:id="rId1"/></sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>`);
  zip.file('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>');
  const font = bold => `<font><sz val="11"/><name val="Microsoft YaHei"/>${bold ? '<b/>' : ''}<color rgb="FF222222"/></font>`;
  const xf = (fontId, numFmtId = 0, borderId = 1, fillId = 0, align = 'center') => `<xf numFmtId="${numFmtId}" fontId="${fontId}" fillId="${fillId}" borderId="${borderId}" xfId="0" applyNumberFormat="1" applyAlignment="1"><alignment horizontal="${align}" vertical="center" wrapText="1"/></xf>`;
  zip.file('xl/styles.xml', `<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="${NS}"><numFmts count="2"><numFmt numFmtId="164" formatCode="#,##0.00"/><numFmt numFmtId="165" formatCode="0.00%"/></numFmts><fonts count="3">${font(false)}${font(true)}<font><b/><sz val="16"/><name val="Microsoft YaHei"/><color rgb="FF222222"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="2"><border/><border><left style="thin"><color rgb="FF777777"/></left><right style="thin"><color rgb="FF777777"/></right><top style="thin"><color rgb="FF777777"/></top><bottom style="thin"><color rgb="FF777777"/></bottom></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="10">${xf(0, 0, 0)}${xf(2, 0, 0)}${xf(1)}${xf(0)}${xf(0, 164)}${xf(0, 165)}${xf(1)}${xf(1, 164)}${xf(1, 165)}${xf(0, 0, 0, 0, 'left')}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`);
  let rows = `<row r="1" ht="34" customHeight="1">${textCell('A1', '客户等级渠道占比汇总', 1)}</row>`;
  const headers = [
    ['等级','客户',null,null,null,null,null,null,null,'签约经销商',null,null,null,'全部合计'],
    [null,'直接客户',null,null,null,'间接客户'],
    [null,...Array.from({length:4},()=>['客户数','客户占比','销售额','销售额占比']).flat()]
  ];
  headers.forEach((values,i)=>{rows+=`<row r="${i+2}" ht="30" customHeight="1">${Array.from({length:17},(_,c)=>textCell(`${columnName(c)}${i+2}`,values[c],2)).join('')}</row>`;});
  combinedSummaryRows(summary).forEach((values,index)=>{
    const r=index+5,isTotal=index===5;
    rows+=`<row r="${r}" ht="28" customHeight="1">${values.map((value,c)=>{
      if(c===0)return textCell(`A${r}`,value,isTotal?6:3);
      const col=columnName(c),group=Math.floor((c-1)/4),metric=(c-1)%4;
      const denom=columnName(1+group*4+(metric===3?2:0));
      const style=metric===1||metric===3?isTotal?8:5:metric===2?isTotal?7:4:isTotal?6:3;
      let formula;
      if(isTotal)formula=metric===1||metric===3?`IF(${denom}10=0,"—",SUM(${col}5:${col}9))`:`SUM(${col}5:${col}9)`;
      else if(metric===1||metric===3){const numerator=columnName(c-1);formula=`IF(${denom}10=0,"—",${numerator}${r}/$${denom}$10)`;}
      else if(group===3)formula=`SUM(${columnName(c-12)}${r},${columnName(c-8)}${r},${columnName(c-4)}${r})`;
      return numeric(`${col}${r}`,value,style,formula);
    }).join('')}</row>`;
  });
  const notes=[`销货期间：${summary.periodStart||'—'} 至 ${summary.periodEnd||'—'}；金额单位：人民币元，未税销货净额。`,`统计范围：${summary.scope||'全部客户'}；数据更新：${String(summary.updatedAt||'—').slice(0,19).replace('T',' ')}。`,'签约经销商＝经销商@经销商；间接客户＝渠道@经销商、渠道@经销商备案客户、渠道@贸易商；直接客户＝普通客户组。',`全部合计＝直接客户＋间接客户＋签约经销商。各列组占比以本组合计为分母。${summary.excluded?`另有${summary.excluded}家免评级或待核对客户未纳入。`:''}`];
  const merges=['A1:Q1','A2:A4','B2:I2','B3:E3','F3:I3','J2:M3','N2:Q3'];
  notes.forEach((note,i)=>{rows+=`<row r="${i+12}" ht="26" customHeight="1">${textCell(`A${i+12}`,note,9)}</row>`;merges.push(`A${i+12}:Q${i+12}`);});
  const widths=[8,...Array.from({length:4},()=>[12,14,22,16]).flat()];
  zip.file('xl/worksheets/sheet1.xml',`<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="${NS}"><dimension ref="A1:Q15"/><sheetViews><sheetView workbookViewId="0" showGridLines="0"/></sheetViews><sheetFormatPr defaultRowHeight="22"/><cols>${widths.map((w,i)=>`<col min="${i+1}" max="${i+1}" width="${w}" customWidth="1"/>`).join('')}</cols><sheetData>${rows}</sheetData><mergeCells count="${merges.length}">${merges.map(ref=>`<mergeCell ref="${ref}"/>`).join('')}</mergeCells><printOptions horizontalCentered="1"/><pageMargins left="0.25" right="0.25" top="0.4" bottom="0.4" header="0.2" footer="0.2"/><pageSetup paperSize="8" orientation="landscape" fitToWidth="1" fitToHeight="1"/></worksheet>`);
  return zip.generateAsync({type: 'uint8array', compression: 'DEFLATE'});
}
