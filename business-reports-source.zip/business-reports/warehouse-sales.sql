SELECT occ01 AS customerId, occ03 AS industryCode, oca02 AS industry,
       occ18 AS customerName, occud06 AS erpGrade, gen02 AS salesPerson,
       SUM(xhm) AS amount
FROM (
  SELECT occ01, occ03, oca02, occ18, occud06, gen02,
         COALESCE(SUM(oga24 * ogb14), 0) AS xhm
  FROM ods_erp_oga_file
  JOIN ods_erp_ogb_file ON oga01 = ogb01
  JOIN ods_erp_occ_file ON occ01 = oga03 AND LEFT(occ01, 4) <> 'DEMO'
  JOIN ods_erp_gen_file ON gen01 = occ04 AND occ04 NOT IN ('01035','01096','01033')
  JOIN ods_erp_ima_file ON ogb04 = ima01
  LEFT JOIN ods_erp_azf_file ON azf01 = ima09 AND azf02 = 'D'
  LEFT JOIN ods_erp_oca_file ON occ03 = oca01
  WHERE oga00 = '1' AND oga09 IN ('2','3') AND ogapost = 'Y'
    AND LEFT(ogb31, 4) NOT IN ('3003','3004','3201','3202','3999','3011')
    AND oga02 >= %s AND oga02 < %s
  GROUP BY occ01, occ03, oca02, occ18, occud06, gen02
  UNION ALL
  SELECT occ01, occ03, oca02, occ18, occud06, gen02,
         COALESCE(-SUM(oha24 * ohb14), 0) AS xhm
  FROM ods_erp_oha_file
  JOIN ods_erp_ohb_file ON oha01 = ohb01
  JOIN ods_erp_occ_file ON occ01 = oha03 AND LEFT(occ01, 4) <> 'DEMO'
  JOIN ods_erp_gen_file ON gen01 = occ04 AND occ04 NOT IN ('01035','01096','01033')
  JOIN ods_erp_ima_file ON ohb04 = ima01
  LEFT JOIN ods_erp_azf_file ON azf01 = ima09 AND azf02 = 'D'
  LEFT JOIN ods_erp_oca_file ON occ03 = oca01
  WHERE ohapost = 'Y' AND LEFT(oha01, 4) NOT IN ('6003','6999')
    AND oha02 >= %s AND oha02 < %s
  GROUP BY occ01, occ03, oca02, occ18, occud06, gen02
) AS net_sales
GROUP BY occ01, occ03, oca02, occ18, occud06, gen02
ORDER BY gen02, occ01
