import json
import tempfile
import unittest
from datetime import datetime as RealDateTime
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch

from customer_ratings import CustomerRatings, calculate, protected_grade, sales_score, rounded, sales_window
from warehouse_sales import atomic_json


class FakeWarehouse:
    config = None
    def query(self, start, end, filename):
        assert filename == 'customer-ratings.sql'
        return [{'customerId': 'old', 'customerName': 'Old', 'industry': 'Manufacturing', 'salesPerson': 'QA', 'erpGrade': 'A', 'saleYear': start.year, 'month': start.month, 'amount': Decimal('500000.005')},
                {'customerId': 'old', 'saleYear': start.year + (start.month == 12), 'month': start.month % 12 + 1, 'amount': Decimal('-0.005')},
                {'customerId': 'new', 'saleYear': start.year, 'month': start.month, 'amount': Decimal('1000000')}], '2026-10-16'


class TestRatings(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.root = Path(self.temp.name)
        self.scores = {'baselineGrade': 'A', 'newCustomer': False, 'opportunity': 100, 'credit': 100, 'position': 100}
        atomic_json(self.root / 'customer-rating-scores.json', {'revision': 'one', 'records': {'old': self.scores}})
        self.engine = CustomerRatings(self.root, FakeWarehouse())

    def tearDown(self):
        self.temp.cleanup()

    def test_sales_boundaries(self):
        for amount, expected in [('-1',0), ('0',0), ('49999.999',0), ('50000',25), ('199999.999',25), ('200000',50), ('499999.99',50), ('500000',75), ('999999.99',75), ('1000000',100)]:
            self.assertEqual(sales_score(amount), expected)

    def test_cross_year_window(self):
        start, end, labels = sales_window(2026, 10)
        self.assertEqual(str(start), '2025-10-01')
        self.assertEqual(labels, ['2025-10','2025-11','2025-12','2026-01','2026-02','2026-03','2026-04','2026-05','2026-06','2026-07','2026-08','2026-09','2026-10'])
        self.assertEqual(sales_window(2026, 9)[1].isoformat(), '2026-09-30')

    def test_weights_and_exceptions(self):
        result = calculate(1000000, self.scores)
        self.assertEqual(result['weighted'], ['70.00','20.00','5.00','5.00'])
        self.assertEqual(result['totalScore'], '100.00')
        self.assertEqual(calculate(500000, self.scores)['totalScore'], '82.50')
        self.assertEqual(calculate(50000, self.scores)['calculatedGrade'], 'C')
        self.assertEqual(calculate(49999, self.scores)['calculatedGrade'], 'S')
        self.assertEqual(calculate(1000000, {**self.scores, 'newCustomer': True})['calculatedGrade'], 'S')
        self.assertEqual(calculate(1000000, {**self.scores, 'newCustomer': None})['calculatedGrade'], 'S')
        self.assertEqual(calculate(0, {**self.scores, 'baselineGrade': 'V'})['calculatedGrade'], 'A')
        self.assertIsNone(calculate(1000000, {})['totalScore'])
        self.assertEqual(rounded('1.005'), '1.01')

    def test_no_half_downgrades(self):
        for current in ['A','B','C','D','S']:
            for proposed in ['A','B','C','D','S']:
                order = ['S','D','C','B','A']
                self.assertGreaterEqual(order.index(protected_grade(current, proposed, 'half')), order.index(current))
                self.assertEqual(protected_grade(current, proposed, 'annual'), proposed)

    def test_sync_and_persistent_scores(self):
        result = self.engine.sync(2026)
        old = next(r for r in result['records'] if r['customerId'] == 'old')
        self.assertEqual(old['amount'], '500000.00')
        self.assertEqual(old['months'][1], '-0.005')
        self.assertEqual(old['currentGrade'], 'A')
        new = next(r for r in result['records'] if r['customerId'] == 'new')
        self.assertIsNone(new['newCustomer'])
        self.assertEqual(new['currentGrade'], 'S')
        self.assertIsNone(new['totalScore'])
        payload = {'revision': result['revision'], 'customerId': 'old', 'opportunity': 25, 'position': 25, 'credit': 100, 'newCustomer': False}
        self.engine.update_scores(payload, 'admin')
        with self.assertRaises(ValueError):
            self.engine.update_scores(payload, 'admin')
        refreshed = self.engine.sync(2026)
        old = next(r for r in refreshed['records'] if r['customerId'] == 'old')
        self.assertEqual(old['opportunity'], 25)
        self.assertEqual(old['currentGrade'], 'A')
        self.assertEqual(old['calculatedGrade'], 'B')
        self.assertEqual(old['halfGrade'], 'A')
        self.assertEqual(len(refreshed['events']), 1)
        reopened = CustomerRatings(self.root, FakeWarehouse()).snapshot(2026)
        self.assertEqual(reopened['revision'], refreshed['revision'])

    def test_sync_failure_preserves_success(self):
        self.engine.sync(2026)
        before = self.engine.snapshot(2026)
        with patch.object(self.engine.warehouse, 'query', side_effect=RuntimeError('private password')):
            with self.assertRaises(RuntimeError): self.engine.sync(2026)
        after = self.engine.snapshot(2026)
        self.assertEqual(before['records'], after['records'])
        self.assertNotIn('password', after['lastError'])

    def test_review_window_and_downgrades(self):
        class June(RealDateTime):
            @classmethod
            def now(cls, tz=None): return cls(2026,6,30,tzinfo=tz)
        class December(RealDateTime):
            @classmethod
            def now(cls, tz=None): return cls(2026,12,31,tzinfo=tz)
        with patch('customer_ratings.datetime', June):
            snapshot = self.engine.sync(2026)
            payload = {'year': 2026, 'month': 6, 'mode': 'half', 'revision': snapshot['revision'], 'ledgerRevision': snapshot['ledgerRevision']}
            self.assertEqual(self.engine.review(payload, 'admin'), 0)
            with self.assertRaises(ValueError): self.engine.review({**payload, 'mode': 'annual'}, 'admin')
        # A lower proposal is retained in June and actually downgraded at annual review.
        scores = self.engine.stores()[0]
        self.engine.update_scores({'revision': scores['revision'], 'customerId': 'old', 'opportunity': 0, 'credit': 100, 'position': 0, 'newCustomer': False}, 'admin')
        with patch('customer_ratings.datetime', December):
            snapshot = self.engine.sync(2026)
            count = self.engine.review({'year':2026, 'month':12, 'mode':'annual', 'revision':snapshot['revision'], 'ledgerRevision':snapshot['ledgerRevision']}, 'admin')
            self.assertEqual(count, 1)
            self.assertEqual(next(r for r in self.engine.snapshot(2026)['records'] if r['customerId']=='old')['currentGrade'], 'C')


if __name__ == '__main__':
    unittest.main()
