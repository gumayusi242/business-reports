"""Annual customer ratings, separate from ERP price grades and legacy analysis."""
import json
import hashlib
import secrets
import threading
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

from warehouse_sales import LOCAL_TIME, atomic_json

MONEY = Decimal('0.01')
# This non-marketing owner is excluded only from customer analysis.
EXCLUDED_ANALYSIS_SALES_PEOPLE = frozenset({'符一超'})
DEALER_INDUSTRIES = frozenset({'渠道@贸易商', '渠道@经销商', '渠道@经销商备案客户', '经销商@经销商'})

RECYCLING_CUSTOMERS = frozenset({'05740690', '05740808', '05740834', '05740693'})

def customer_group(industry, customer=''):
    if str(customer) in RECYCLING_CUSTOMERS:
        return '废料回收'
    return '经销商' if str(industry or '').strip() in DEALER_INDUSTRIES else '普通客户'

RATING_WEIGHTS = {'sales': 80, 'opportunity': 10, 'credit': 5, 'position': 5}
SALES_SCORE_RULE = {'mode': 'rounded_ten_thousands_capped_at_100', 'unitAmount': 10000,
                    'capAmount': 1000000, 'capScore': 100, 'rounding': 'ROUND_HALF_UP',
                    'effectiveDate': '2026-11-19'}
RANK = {'S': 0, 'D': 1, 'C': 2, 'B': 3, 'A': 4, 'V': 4}
SCORES = {0, 25, 50, 75, 100}
DETAIL_SCORES = {0, 20, 40, 60, 80, 100}
DETAIL_GROUPS = {'opportunity': ('cooperationPotential', 'futureOrders', 'expansionSpace'),
                 'position': ('industryInfluence', 'benchmarkValue')}

def detail_scores(details):
    keys = {key for group in DETAIL_GROUPS.values() for key in group}
    if not isinstance(details, dict) or set(details) != keys or any(type(v) is not int or v not in DETAIL_SCORES for v in details.values()):
        raise ValueError('五个细项必须全部评分，分值只能为0、20、40、60、80、100')
    weights = {'opportunity': (Decimal('.40'), Decimal('.30'), Decimal('.30')),
               'position': (Decimal('.50'), Decimal('.50'))}
    return {name: sum((Decimal(details[key]) * weight for key, weight in zip(keys, weights[name])), Decimal(0))
            for name, keys in DETAIL_GROUPS.items()}

PRIVATE = {'customer-rating-scores.json', 'customer-rating-ledger.json', 'customer-rating-cache.json'}


def rounded(value):
    return str(Decimal(str(value)).quantize(MONEY, rounding=ROUND_HALF_UP))


def sales_score(amount):
    amount = Decimal(str(amount))
    return 100 if amount >= 1000000 else int((amount / Decimal('10000')).quantize(Decimal('1'), rounding=ROUND_HALF_UP))


def calculate(amount, scores):
    scores = dict(scores)
    if scores.get('customerGroup') == '废料回收' or scores.get('customerId') in RECYCLING_CUSTOMERS:
        return {'lowSales': Decimal(str(amount)) < 50000, 'scoreExempt': True, 'scoreNotApplicable': True,
                'scoreExemptReason': '废料回收客户，不参与评分', 'salesScore': sales_score(amount),
                'totalScore': None, 'weighted': [], 'calculatedGrade': '免评分', 'reason': '废料回收客户单独分组，不参与客户评分和等级评定'}
    if scores.get('scoreDetails') is not None:
        scores.update(detail_scores(scores['scoreDetails']))
    low_sales = Decimal(str(amount)) < 50000
    exempt_reason = '新客户' if scores.get('newCustomer') is True else '年度销货净额不足5万元' if low_sales else ''
    exemption = {'lowSales': low_sales, 'scoreExempt': bool(exempt_reason), 'scoreExemptReason': exempt_reason}
    raw = sales_score(amount)
    parts = [Decimal(raw) * Decimal(RATING_WEIGHTS['sales']) / 100]
    for key in ('opportunity', 'credit', 'position'):
        weight = Decimal(RATING_WEIGHTS[key]) / 100
        value = scores.get(key)
        valid = (isinstance(value, Decimal) and value.is_finite() and 0 <= value <= 100) if key != 'credit' and scores.get('scoreDetails') is not None else type(value) is int and value in SCORES
        if key == 'credit':
            valid = type(value) is int and value in range(-100, 101, 20)
        if not valid:
            return {**exemption, 'salesScore': raw, 'totalScore': None, 'weighted': [],
                    'calculatedGrade': 'S' if exempt_reason or scores.get('baselineGrade') == 'S' else None,
                    'reason': exempt_reason + '，直接归为S类，无需五项评分' if exempt_reason else '暂保留S，客户身份及评分待确认' if scores.get('baselineGrade') == 'S' else '三项评分待补全'}
        parts.append(Decimal(value) * Decimal(weight))
    total = sum(parts)
    if exempt_reason:
        grade, reason = 'S', exempt_reason + '，直接归为S类，无需五项评分'
    elif scores.get('baselineGrade') == 'V':
        grade, reason = 'A', 'V签约经销商按A管理，ERP价格等级保留'
    elif scores.get('newCustomer') is True:
        grade, reason = 'S', '新客户固定S类'
    elif scores.get('newCustomer') is None:
        grade, reason = 'S', '新客身份待确认，暂保留S类'
    elif Decimal(str(amount)) < 50000:
        grade, reason = 'S', '统计期销货净额不足5万元'
    else:
        grade = 'A' if total >= 80 else 'B' if total >= 60 else 'C' if total >= 40 else 'D'
        reason = '按综合得分分级'
    return {**exemption, 'salesScore': raw, 'totalScore': str(total.quantize(Decimal('0.1'), rounding=ROUND_HALF_UP)), 'weighted': [rounded(x) for x in parts],
            'calculatedGrade': grade, 'reason': reason}


def protected_grade(current, proposed, mode):
    current = 'A' if current == 'V' else current
    if mode == 'half' and RANK[proposed] < RANK[current]:
        return current
    return proposed


def sales_window(year, month=None):
    today = datetime.now(LOCAL_TIME).date()
    month = today.month if month is None else month
    selected = date(year, month, 1)
    if selected < date(2026, 1, 1) or selected > today.replace(day=1):
        raise ValueError('统计月份超出可查询范围')
    start = date(year - 1, month, 1)
    next_month = date(year + (month == 12), month % 12 + 1, 1)
    end = min(today, next_month - timedelta(days=1))
    labels = [f'{(start.year * 12 + start.month - 1 + i) // 12:04d}-{(start.month - 1 + i) % 12 + 1:02d}' for i in range(13)]
    return start, end, labels


class CustomerRatings:
    def __init__(self, data_dir, warehouse):
        self.root = Path(data_dir)
        self.warehouse = warehouse
        self.lock = threading.RLock()
        self.sync_guard = threading.Lock()
        self.credit_provider = None
        self.running = False

    def read(self, filename, fallback):
        path = self.root / filename
        return json.loads(path.read_text(encoding='utf-8')) if path.exists() else fallback

    def stores(self):
        scores = self.read('customer-rating-scores.json', {'revision': '', 'records': {}})
        ledger = self.read('customer-rating-ledger.json', {'effective': {}, 'events': [], 'revision': ''})
        for customer, values in ledger.get('scoreOverrides', {}).items():
            if customer in scores['records']:
                scores['records'][customer].update(values)
        scores['revision'] = scores.get('revision', '') + ':' + ledger.get('revision', '')
        return scores, ledger, self.read('customer-rating-cache.json', {'periods': {}, 'lastError': ''})

    @staticmethod
    def customer_revision(customer, record, ledger):
        manual = {key: record.get(key) for key in ('scoreDetails', 'newCustomer')}
        if record.get('scoreDetails') is None:
            manual.update({key: record.get(key) for key in ('opportunity','position')})
        state = {'customer': customer, 'manual':manual,
                 'revision':ledger.get('scoreRevisions', {}).get(customer, '')}
        return hashlib.sha256(json.dumps(state, sort_keys=True, ensure_ascii=False).encode()).hexdigest()

    def snapshot(self, year, month=None):
        today = datetime.now(LOCAL_TIME).date()
        start, end, labels = sales_window(year, month)
        period = labels[-1]
        month = int(period[5:])
        with self.lock:
            scores, ledger, cache = self.stores()
            annual = cache.get('periods', {}).get(period, {})
            records = []
            customers = set(annual.get('customers', {})) | set(scores.get('records', {}))
            customers = {customer for customer in customers
                         if str(annual.get('customers', {}).get(customer, {}).get('salesPerson',
                               scores.get('records', {}).get(customer, {}).get('salesPerson', ''))).strip()
                         not in EXCLUDED_ANALYSIS_SALES_PEOPLE}
            credit_data = self.credit_provider(customers) if self.credit_provider else None
            for customer in customers:
                reference = scores.get('records', {}).get(customer, {})
                if reference.get('scoreDetails') is not None:
                    reference = {**reference, **{key: float(rounded(value)) for key, value in detail_scores(reference['scoreDetails']).items()}}
                if credit_data is not None:
                    reference = {**reference, 'credit': credit_data['records'][customer]['credit']}
                sale = annual.get('customers', {}).get(customer, {})
                # No sales in the selected window is zero, never a stale prior snapshot.
                amount = sum((Decimal(x) for x in sale.get('months', ['0'] * 13)), Decimal(0))
                rating = calculate(amount, {**reference, 'customerId': customer})
                industry = sale.get('industry', reference.get('industry', ''))
                # Historical confirmations remain audit records; current grade follows live scores.
                current = rating['calculatedGrade']
                proposal = rating['calculatedGrade']
                records.append({'customerId': customer, 'customerName': sale.get('customerName', reference.get('customerName', '')),
                                'industry': industry, 'customerGroup': customer_group(industry, customer),
                                'salesPerson': sale.get('salesPerson', reference.get('salesPerson', '')),
                                'erpGrade': sale.get('erpGrade', reference.get('baselineGrade', '')),
                                'baselineGrade': reference.get('baselineGrade', 'S'), 'currentGrade': current,
                                'customerRevision': self.customer_revision(customer, reference, ledger),
                                'halfGrade': current,
                                'amount': rounded(amount), 'months': sale.get('months', ['0'] * 13),
                                'opportunity': reference.get('opportunity'), 'credit': reference.get('credit'),
                                'creditDetails': credit_data['records'][customer] if credit_data else None,
                                'scoreDetails': reference.get('scoreDetails'),
                                'position': reference.get('position'), 'newCustomer': reference.get('newCustomer'), **rating})
            records.sort(key=lambda x: (-Decimal(x['amount']), x['customerId']))
            months = [rounded(sum((Decimal(row['months'][m]) for row in records), Decimal(0))) for m in range(13)]
            half_allowed = year == today.year and month == 6 and today.month == 6
            annual_allowed = (year == today.year and month == 12 and today.month == 12) or (year == today.year - 1 and month == 12 and today.month == 1)
            return {'year': year, 'month': month, 'period': period, 'monthLabels': labels,
                    'periodStart': start.isoformat(), 'periodEnd': annual.get('periodEnd', ''),
                    'updatedAt': annual.get('updatedAt', ''), 'warehouseUpdatedAt': annual.get('warehouseUpdatedAt', ''),
                    'records': records, 'months': months, 'ready': bool(annual), 'running': self.running,
                    'lastError': cache.get('lastError', ''), 'revision': scores.get('revision', ''),
                    'creditSource': {k: v for k, v in credit_data.items() if k != 'records'} if credit_data else None,
                    'ledgerRevision': ledger.get('revision', ''), 'events': ledger.get('events', [])[-100:][::-1],
                    'gradingMode': 'automatic', 'salesScoreRule': dict(SALES_SCORE_RULE), 'reviewAllowed': {'half': False, 'annual': False},
                    'maxMonth': today.strftime('%Y-%m')}

    def sync(self, year, month=None):
        start, end, labels = sales_window(year, month)
        period = labels[-1]
        if not self.sync_guard.acquire(blocking=False):
                raise ValueError('跨年销货数据正在同步')
        self.running = True
        try:
            rows, updated = self.warehouse.query(start, end, 'customer-ratings.sql')
            customers = {}
            for row in rows:
                customer = str(row['customerId']).strip()
                record = customers.setdefault(customer, {key: str(row.get(key) or '') for key in ['customerName', 'industry', 'salesPerson', 'erpGrade']})
                record.setdefault('months', ['0'] * 13)
                month_index = (int(row['saleYear']) - start.year) * 12 + int(row['month']) - start.month
                if not 0 <= month_index < 13:
                    raise ValueError('数仓返回的月份无效')
                record['months'][month_index] = str(Decimal(record['months'][month_index]) + Decimal(str(row['amount'])))
            with self.lock:
                scores, ledger, cache = self.stores()
                # Unknown customers remain S and require explicit non-sales scoring.
                for customer, row in customers.items():
                    if customer not in scores['records']:
                        scores['records'][customer] = {**{k: row[k] for k in ['customerName', 'industry', 'salesPerson']},
                                                     'baselineGrade': 'S', 'newCustomer': None,
                                                     'opportunity': None, 'position': None, 'credit': 100}
                scores['revision'] = secrets.token_hex(12)
                atomic_json(self.root / 'customer-rating-scores.json', scores)
                cache.setdefault('periods', {})[period] = {'customers': customers, 'periodEnd': end.isoformat(),
                                            'updatedAt': datetime.now(LOCAL_TIME).isoformat(), 'warehouseUpdatedAt': updated}
                cache['lastError'] = ''
                atomic_json(self.root / 'customer-rating-cache.json', cache)
            return self.snapshot(year, int(period[5:]))
        except Exception:
            with self.lock:
                cache = self.stores()[2]
                cache['lastError'] = '跨年销货同步失败，已保留上次成功数据'
                atomic_json(self.root / 'customer-rating-cache.json', cache)
            raise
        finally:
            self.running = False
            self.sync_guard.release()

    def update_scores(self, payload, actor, actor_name=""):
        with self.lock:
            scores, ledger, _ = self.stores()
            customer = str(payload.get('customerId', ''))
            if customer not in scores['records']:
                raise ValueError('客户不存在')
            if 'customerRevision' in payload:
                if payload['customerRevision'] != self.customer_revision(customer, scores['records'][customer], ledger):
                    raise ValueError('该客户的评分或身份已被更新，请刷新后核对；当前填写内容已保留')
            elif payload.get('revision') != scores.get('revision'):
                raise ValueError('页面评分版本已更新，请重新加载页面后重试')
            if customer in RECYCLING_CUSTOMERS:
                raise ValueError('废料回收客户不参与评分，无需确认身份')
            before = dict(scores['records'][customer])
            year = int(payload.get('year', datetime.now(LOCAL_TIME).year))
            month = int(payload.get('month', datetime.now(LOCAL_TIME).month))
            snapshot = self.snapshot(year, month)
            frozen = next((row for row in snapshot['records'] if row['customerId'] == customer), None)
            if frozen is None:
                raise ValueError('该客户不在营销部客户分析范围内，无需评分')
            identity = payload.get('newCustomer', before.get('newCustomer'))
            if type(identity) is not bool:
                raise ValueError('请先确认是否为新客户，再保存')
            exempt = identity is True or Decimal(str(frozen['amount'])) < 50000
            if exempt:
                # Retain previous manual inputs rather than replacing them with invented scores.
                values = {key: before[key] for key in ('scoreDetails', 'opportunity', 'position') if key in before}
                values['newCustomer'] = identity
            else:
                if 'scoreDetails' not in payload:
                    raise ValueError('非新客户且年度销货净额达到5万元，请完成五项评分')
                averages = detail_scores(payload['scoreDetails'])
                values = {key: float(rounded(value)) for key, value in averages.items()}
                values.update(scoreDetails=dict(payload['scoreDetails']), newCustomer=identity)
            updated = {**frozen, **values}
            updated.update(calculate(frozen['amount'], updated))
            ledger.setdefault('scoreRevisions', {})[customer] = secrets.token_hex(12)
            updated['customerRevision'] = self.customer_revision(customer, updated, ledger)
            updated['currentGrade'] = updated['calculatedGrade']
            updated['halfGrade'] = updated['currentGrade']
            number = 1 + sum(event.get('customerId') == customer and 'versionId' in event for event in ledger.get('events', []))
            version = {'versionId': secrets.token_hex(12), 'versionNumber': number,
                       'actorName': actor_name, 'period': snapshot['period'],
                       'scoreMode': 's-exempt-identity' if exempt else 'five-details',
                       'snapshot': updated, 'previousSnapshot': frozen,
                       'source': {'periodStart': snapshot['periodStart'], 'periodEnd': snapshot['periodEnd'],
                                  'updatedAt': snapshot['updatedAt'], 'creditSource': snapshot.get('creditSource')},
                       'rules': {**RATING_WEIGHTS, 'salesScoreRule': dict(SALES_SCORE_RULE),
                                 'sExemption': {'newCustomer': True, 'salesBelow': 50000, 'skipDetails': True},
                                 'opportunityShares': [40,30,30], 'positionShares': [50,50],
                                 'orderBasis': 'earliest_overdue_pickup_business_due_plus_3_months',
                                 'orderGraceMonths': 3, 'orderScope': 'orderQueryStatus=逾拿货',
                                 'creditMode': 'sum', 'creditBands': [50,30,10,-10,-30,-50],
                                 'gradeThresholds': {'A':80,'B':60,'C':40}, 'rounding':'HALF_UP_1'}}
            ledger.setdefault('scoreOverrides', {})[customer] = values
            ledger['events'].append({'time': datetime.now(LOCAL_TIME).isoformat(), 'actor': actor, 'type': 'score',
                                     'customerId': customer, 'before': {k: before.get(k) for k in values}, 'after': values, **version})
            ledger['revision'] = secrets.token_hex(12)
            atomic_json(self.root / 'customer-rating-ledger.json', ledger)

    def score_versions(self, customer='', offset=0, limit=50, keyword='', actor='', latest=False):
        with self.lock:
            events = self.stores()[1].get('events', [])
            all_items = [event for event in reversed(events) if event.get('type') == 'score'
                         and (not customer or event.get('customerId') == customer)]
            counts = {}
            for event in all_items:
                key = event.get('customerId', '')
                counts[key] = counts.get(key, 0) + 1
            actors = sorted({(str(e.get('actor', '')), str(e.get('actorName') or '')) for e in all_items})
            if latest:
                seen = set()
                items = []
                for event in all_items:
                    key = event.get('customerId', '')
                    if key not in seen:
                        seen.add(key)
                        items.append(event)
            else:
                items = all_items
            keyword = keyword.strip().casefold()
            items = [event for event in items if
                     (not keyword or keyword in (str(event.get('customerId', '')) + ' ' +
                      str((event.get('snapshot') or {}).get('customerName', ''))).casefold())
                     and (not actor or str(event.get('actor', '')) == actor)]
            return {'total': len(items), 'offset': offset, 'limit': limit, 'latest': latest,
                    'actors': [{'username': code, 'name': name} for code, name in actors],
                    'versions': [{**event, 'customerVersionCount': counts.get(event.get('customerId', ''), 0)}
                                 for event in items[offset:offset+limit]]}

    def review(self, payload, actor):
        raise ValueError('当前等级随评分自动更新，无需手动定级')

    def start(self):
        if not self.warehouse.config:
            return
        def loop():
            while True:
                now = datetime.now(LOCAL_TIME)
                due = now.replace(hour=8, minute=0, second=0, microsecond=0)
                with self.lock:
                    cache = self.stores()[2]
                success = cache.get('periods', {}).get(now.strftime('%Y-%m'), {}).get('updatedAt', '')
                if now >= due and (not success or datetime.fromisoformat(success) < due):
                    try:
                        self.sync(now.year, now.month)
                    except Exception:
                        threading.Event().wait(1800)
                threading.Event().wait(30)
        threading.Thread(target=loop, name='customer-ratings-daily', daemon=True).start()
