import {openScoreDialog, detailHistory} from './customer-scoring.js?v=20261119-linear-sales-1';
export function createCustomerRatings({root, api, isAdmin, escapeHtml: esc}) {
  const grades = ['A', 'B', 'C', 'D', 'S', '免评分'];
  const colors = ['#0c7770', '#245eac', '#687d2e', '#ac6430', '#7a8290'];
  const fmt = (v, n = 2) => Number(v || 0).toLocaleString('zh-CN', {minimumFractionDigits: n, maximumFractionDigits: n});
  let data = null, year = new Date().getFullYear(), month = new Date().getMonth() + 1, error = '', busy = false, page = 1, selected = '';
  let filters = {keyword: '', person: '', industry: '', group: '', grade: '', status: ''};
  let dialog = null, generation = 0;

  function filtered() {
    return (data?.records || []).filter(r => (!filters.keyword || `${r.customerId} ${r.customerName}`.toLowerCase().includes(filters.keyword.toLowerCase())) &&
      (!filters.group || r.customerGroup === filters.group) && (!filters.person || r.salesPerson === filters.person) && (!filters.industry || r.industry === filters.industry) &&
      (!filters.grade || r.currentGrade === filters.grade) && (!filters.status || (filters.status === 'pending' ? !r.scoreExempt&&(r.totalScore === null || r.newCustomer === null) : r.scoreExempt||(r.totalScore !== null && r.newCustomer !== null))));
  }
  const options = (values, value, all) => `<option value="">${all}</option>` + values.map(v => `<option value="${esc(v)}" ${v === value ? 'selected' : ''}>${esc(v)}</option>`).join('');
  const badge = grade => `<span class="cr-grade cr-grade-${grade || 'pending'}">${grade || '待评分'}</span>`;
  function matrix(rows) {
    const total = rows.reduce((s, r) => s + Number(r.amount), 0);
    return `<table class="cr-matrix"><thead><tr><th>等级</th><th>客户数（家）</th><th>销货净额（万元）</th><th>总额占比</th></tr></thead><tbody>${[...grades, ...(rows.some(r => !r.currentGrade) ? ['pending'] : [])].map((g, i) => {
      const items = rows.filter(r => (r.currentGrade || 'pending') === g), amount = items.reduce((s, r) => s + Number(r.amount), 0);
      return `<tr><th>${badge(g === 'pending' ? null : g)}</th><td>${fmt(items.length, 0)}</td><td><div class="cr-bar-cell"><span>${fmt(amount / 10000)}</span><i style="width:${total > 0 ? Math.min(100, Math.max(0, amount / total * 100)) : 0}%;background:${colors[i] || '#7a8290'}"></i></div></td><td>${total > 0 ? fmt(amount / total * 100) + '%' : '—'}</td></tr>`;
    }).join('')}</tbody><tfoot><tr><th>合计</th><td>${fmt(rows.length, 0)}</td><td>${fmt(total / 10000)}</td><td>${total > 0 ? '100.00%' : '—'}</td></tr></tfoot></table>`;
  }
  function chart(rows) {
    const months = Array.from({length: 13}, (_, m) => rows.reduce((sum, r) => sum + Number(r.months[m]), 0) / 10000);
    const observed = data.monthLabels.length;
    const min = Math.min(0, ...months), max = Math.max(1, ...months), extent = max - min;
    const y = value => 166 - (value - min) / extent * 128;
    return `<div class="cr-chart-scroll"><svg class="cr-month-chart" viewBox="0 0 1000 210" role="img" aria-label="去年同月至本月各月销货净额，单位万元">${[0, 1, 2, 3, 4].map(i => {
      const value = min + extent * i / 4, pos = y(value);
      return `<line x1="70" x2="980" y1="${pos}" y2="${pos}" stroke="#e3e9ed"/><text x="60" y="${pos + 4}" text-anchor="end">${fmt(value, 0)}</text>`;
    }).join('')}<line x1="70" x2="980" y1="${y(0)}" y2="${y(0)}" stroke="#aebdca"/>${months.map((v, m) => {
      const x = 80 + m * 69;
      return `${m < observed ? `<rect x="${x}" y="${Math.min(y(v), y(0))}" width="38" height="${Math.abs(y(v) - y(0))}" fill="${v < 0 ? '#ba3c30' : '#0c7770'}"><title>${data.monthLabels[m]}：${fmt(v)}万元</title></rect><text x="${x + 19}" y="${v < 0 ? y(v) + 14 : y(v) - 7}" text-anchor="middle" class="cr-chart-value">${fmt(v)}</text>` : `<text x="${x + 19}" y="${y(0) - 10}" text-anchor="middle">—</text>`}<text x="${x + 19}" y="197" text-anchor="middle">${data.monthLabels[m]}</text>`;
    }).join('')}<text x="8" y="16">万元</text></svg></div>`;
  }
  function draw() {
    if (!isAdmin()) {root.innerHTML = ''; return;}
    const rows = filtered();
    const people = [...new Set((data?.records || []).map(r => r.salesPerson).filter(Boolean))].sort();
    const industries = [...new Set((data?.records || []).map(r => r.industry).filter(Boolean))].sort();
    const pages = Math.max(1, Math.ceil(rows.length / 30)); page = Math.min(page, pages);
    root.innerHTML = `<div class="section-head"><div><h2>客户综合分析</h2><p class="subtle">${data?.periodStart ? `${esc(data.periodStart)} 至 ${esc(data.periodEnd || '待同步')}` : '去年同月1日至本月'} · 销货净额 · 人民币未税</p></div><div class="cr-actions"><label>统计月份 <input type="month" id="cr-period" min="2026-01" max="${data?.maxMonth || new Date().toLocaleDateString('sv-SE').slice(0,7)}" value="${year}-${String(month).padStart(2,'0')}" ${busy ? 'disabled' : ''}></label><button class="ghost-button" data-action="refresh" ${busy ? 'disabled' : ''}>刷新</button><button class="primary-button" data-action="sync" ${busy || data?.running ? 'disabled' : ''}>${busy || data?.running ? '同步中…' : '同步数仓'}</button><button class="ghost-button" data-action="export" ${!data || busy ? 'disabled' : ''}>导出当前筛选</button><button class="ghost-button" data-action="history">评分历史版本</button></div></div>
      <p class="subtle cr-sync">每天08:00同步 · 最近成功 ${esc(data?.updatedAt?.slice(0, 19).replace('T', ' ') || '尚未同步')} · 定级不修改ERP价格权限</p>
      ${error || data?.lastError ? `<p class="cr-error" role="alert">${esc(error || data.lastError)}</p>` : ''}
      <div class="cr-rule"><strong>综合得分＝销售额80%＋业务机会10%＋信誉度5%＋行业地位5%</strong><span>A ≥80；B ≥60；C ≥40；D ＜40。新客户或期内销货净额不足5万元直接归S，无需五项评分；其余V按A管理。</span><span>销售额评分：≥100万元为100分，其余按销货净额÷1万元四舍五入取整（如89.5万为90分、56.3万为56分），综合总分四舍五入保留1位小数。信誉度＝应收日期评分＋订单交期评分，随最新数据计算。</span><span>渠道@贸易商、渠道@经销商、渠道@经销商备案客户及经销商@经销商归入经销商组，组内仍按相同规则分为A/B/C/D/S。废料回收客户单独分组并免评分，不参与等级评定。当前等级随最新评分自动升降，无需定级确认。原S类新客身份未确认时暂留S，不自动推定新客期限。</span></div>
      <form id="cr-filters" class="cr-filters"><label>客户编号／名称<input name="keyword" value="${esc(filters.keyword)}" placeholder="编号或名称"></label><label>业务员<select name="person">${options(people, filters.person, '全部业务员')}</select></label><label>行业<select name="industry">${options(industries, filters.industry, '全部行业')}</select></label><label>等级<select name="grade">${options(grades, filters.grade, '全部等级')}</select></label><label>定级状态<select name="status">${options(['complete', 'pending'], filters.status, '全部状态').replace('>complete<', '>已评分<').replace('>pending<', '>待补评分／身份<')}</select></label><button class="primary-button" type="submit">筛选</button><button class="ghost-button" type="button" data-action="reset">重置</button></form>
      <div class="cr-view-row"><strong>当前等级 · 随评分自动更新</strong><span class="subtle">筛选 ${fmt(rows.length, 0)} 家 · 净额 ${fmt(rows.reduce((s, r) => s + Number(r.amount), 0) / 10000)} 万元</span></div>
      ${!data?.ready ? `<p class="cr-empty" role="status">${busy ? '正在读取跨年销货数据…' : '该统计月份数据尚未同步，请同步数仓。'}</p>` : `<details class="ca-overview"><summary>展开等级分布与月度销货趋势</summary><div class="cr-group-matrices">${(filters.group?[filters.group]:['普通客户','经销商','废料回收']).map(group=>`<section><h3>${group}等级分布</h3>${matrix(rows.filter(r=>r.customerGroup===group))}</section>`).join('')}</div><section class="cr-month-section"><h3>去年同月至本月 · 各月销货净额</h3>${chart(rows)}</section></details><section class="cr-details"><div class="cr-view-row"><h3>客户综合评分明细</h3></div><div class="cr-table-scroll"><table class="cr-detail-table"><thead><tr><th>客户编号</th><th>客户名称</th><th><label class="cr-header-filter"><span>客户分组</span><select id="cr-group-filter" name="group" form="cr-filters" aria-label="客户分组筛选">${options(['普通客户','经销商','废料回收'], filters.group, '全部客户')}</select></label></th><th>期内销货净额（元）</th><th>销售分<br>80%</th><th>业务机会<br>10%</th><th>信誉分<br>5%</th><th>行业地位<br>5%</th><th>综合得分</th><th>当前等级</th><th>操作</th></tr></thead><tbody>${rows.slice((page - 1) * 30, page * 30).map(r => `<tr><td><button class="cr-link" data-customer="${esc(r.customerId)}">${esc(r.customerId)}</button></td><td title="${esc(r.customerName)}">${esc(r.customerName)}</td><td><span class="cr-customer-group">${esc(r.customerGroup)}</span></td><td>${fmt(r.amount)}</td><td>${r.salesScore}</td><td>${r.scoreExempt?'免评分':r.opportunity == null ? '待评分' : fmt(r.opportunity)}</td><td><button class="cr-link" data-customer="${esc(r.customerId)}" title="查看应收与交期评分依据">${r.credit == null ? '待核对' : fmt(r.credit)}</button><small class="ca-credit-date">${esc(r.creditDetails?.latestAccountDate || '无未结清应收')}</small></td><td>${r.scoreExempt?'免评分':r.position == null ? '待评分' : fmt(r.position)}</td><td>${r.scoreExempt?'免评分':r.totalScore ?? '待评分'}</td><td>${badge(r.currentGrade)}</td><td class="ca-row-actions"><span class="cs-identity-status ${r.scoreNotApplicable?'is-not-applicable':typeof r.newCustomer==='boolean'?'is-confirmed':'is-pending'}">${r.scoreNotApplicable?'废料回收 · 免评分':r.newCustomer===true?'已确认 · 新客户':r.newCustomer===false?'已确认 · 非新客户':'待确认身份'}</span>${r.scoreNotApplicable?'':`<button class="ghost-button" data-score-customer="${esc(r.customerId)}">${r.scoreExempt?(typeof r.newCustomer==='boolean'?'修改身份':'确认身份'):'评分'}</button>`}<button class="ghost-button" data-customer="${esc(r.customerId)}">详情</button></td></tr>`).join('') || '<tr><td colspan="11">没有符合条件的客户</td></tr>'}</tbody></table></div><div class="cr-pagination"><span>${page} / ${pages} 页 · 每页30家</span><button class="ghost-button" data-action="prev" ${page === 1 ? 'disabled' : ''} aria-label="上一页">‹</button><button class="ghost-button" data-action="next" ${page === pages ? 'disabled' : ''} aria-label="下一页">›</button></div></section>`}`;
  }
  async function load(sync = false) {
    if (busy || !isAdmin()) return;
    busy = true; error = ''; const token = ++generation; draw();
    try {
      const result = await api(sync ? '/api/customer-ratings/sync' : `/api/customer-ratings?year=${year}&month=${month}`, sync ? {method: 'POST', body: JSON.stringify({year, month})} : undefined);
      if (token === generation) data = result;
    } catch (e) {if (token === generation) error = e.message;}
    finally {if (token === generation) {busy = false; draw();}}
  }
  function openDialog(html) {
    dialog?.remove();
    const modal = document.createElement('dialog'); modal.className = 'cr-dialog';
    dialog = modal;
    modal.innerHTML = `<button class="ghost-button cr-close" aria-label="关闭">×</button>${html}`;
    document.body.append(modal); modal.querySelector('.cr-close').onclick = () => modal.close();
    modal.addEventListener('close', () => {modal.remove(); if (dialog === modal) dialog = null;});
    modal.showModal();
  }
  function detail(id) {
    selected = id;
    const r = data.records.find(x => x.customerId === id);
    if (!r) return;
    openDialog(`<h2>${esc(r.customerName)}</h2><p class="subtle">${esc(r.customerId)} · ${esc(r.customerGroup)} · ${esc(r.industry)} · ${esc(r.salesPerson)}</p><div class="cr-detail-summary"><span>期内销货净额 <strong>${fmt(r.amount)} 元</strong></span><span>当前等级 ${badge(r.currentGrade)}</span></div><p>${esc(r.reason)}</p><table class="cr-score-table"><thead><tr><th>评分项目</th><th>原始分</th><th>权重</th><th>加权分</th></tr></thead><tbody>${[['销货额', r.salesScore, '80%'], ['业务机会', r.opportunity, '10%'], ['信誉度', r.credit, '5%'], ['行业地位', r.position, '5%']].map(([label, score, weight], i) => `<tr><td>${label}</td><td>${r.scoreExempt&&(i===1||i===3)?'免评分':score ?? '待评分'}</td><td>${weight}</td><td>${r.scoreExempt&&(i===1||i===3)?'免评分':r.weighted[i] || '—'}</td></tr>`).join('')}</tbody><tfoot><tr><th>综合得分</th><td colspan="3">${r.scoreExempt?'免评分':r.totalScore ?? '待评分'}</td></tr></tfoot></table>${creditEvidence(r)}<button class="primary-button" data-edit-scores ${r.scoreNotApplicable?'hidden':''}>${r.scoreExempt?'确认客户身份':'编辑五项评分'}</button><h3>各月销货净额（元）</h3><div class="cr-month-list">${r.months.map((v, m) => `<span>${data.monthLabels[m]} <strong>${fmt(v)}</strong></span>`).join('')}</div>`);
    dialog.querySelector('[data-edit-scores]').onclick = () => editScores(id);
  }

  function editScores(id) {
    const record = data?.records.find(r => r.customerId === id);
    if (!record) return;
    dialog?.close();
    const editor = openScoreDialog({record, revision:data.revision, year, month, api, esc,
      onSaved: result => {data = result; draw();}});
    dialog = editor;
    editor.addEventListener('close', () => {if (dialog === editor) dialog = null;});
  }

  function creditEvidence(r) {
    const c = r.creditDetails || {}, order = c.worstOrder;
    return `<h3>信誉评分依据</h3><p class="subtle">信誉原始分＝应收评分＋交期评分（−100至100分），两项之和×5%计入综合分。两项均按：不超期50、1–30天30、31–60天10、61–90天−10、91–180天−30、超过180天−50分。</p>
      <div class="ca-credit-grid"><section><h4>未结清应收 · −50至50分</h4><p>最新未结清应收日期：<strong>${esc(c.latestAccountDate || '无未结清应收')}</strong></p><p>距今天数：${c.elapsedDays ?? '—'} 天</p><p>应收评分：<strong>${c.receivableScore ?? '待核对'}</strong></p><small>仅取有效且未收余额大于0的应收单；全部收清或无记录记50分。</small></section>
      <section><h4>逾拿货订单 · −50至50分</h4><p>最早逾拿货订单：${esc(order?.orderNo || (c.invalidOrderLines?'待核对':'无逾拿货订单'))} ${esc(order?.lineNo || '')}</p><p>订单日期：${esc(order?.orderDate || '—')}</p><p>计划交期：${esc(order?.planDueDate || '—')} · 状态：${esc(order?.orderStatus || '—')}</p><p>最早业务交期：<strong>${esc(order?.businessDueDate || '—')}</strong></p><p>三个月截止：${esc(order?.deadline || '—')}；超期：${order?.overdueDays ?? '—'} 天</p><p>交期评分：<strong>${c.stockScore ?? '待核对'}</strong></p><small>仅统计订单综合查询中“逾拿货”状态的订单，取其中最早业务交期；业务交期加3个自然月后计算超期天数。其他状态不参与，无逾拿货订单记50分。${c.invalidOrderLines ? '有业务交期缺失或异常，待核对。' : ''}</small></section></div>
      <p class="subtle">信誉评分日期 ${esc(data?.creditSource?.asOfDate || '—')} · 应收数仓更新 ${esc(data?.creditSource?.warehouseUpdatedAt || '—')} · 订单数据日期 ${esc(data?.creditSource?.ordersAsOfDate || '—')}</p>`;
  }

  function exportRows() {
    if (!isAdmin() || !data || busy) return;
    const rows = [['客户编号','客户名称','客户分组','行业','客户身份','评分要求','业务员','期内销货净额','销售分','业务机会分','行业地位分','最新未结清应收日期','应收评分','最早逾拿货订单','订单日期','订单状态','计划交期','业务交期','三个月截止','交期超期天数','交期评分','信誉分','综合分','当前等级'], ...filtered().map(r => [r.customerId,r.customerName,r.customerGroup,r.industry,r.newCustomer===true?'新客户':r.newCustomer===false?'非新客户':'待确认',r.scoreExempt?r.scoreExemptReason+'（免评分）':'需五项评分',r.salesPerson,r.amount,r.salesScore,r.opportunity,r.position,r.creditDetails?.latestAccountDate,r.creditDetails?.receivableScore,r.creditDetails?.worstOrder?.orderNo,r.creditDetails?.worstOrder?.orderDate,r.creditDetails?.worstOrder?.orderStatus,r.creditDetails?.worstOrder?.planDueDate,r.creditDetails?.worstOrder?.businessDueDate,r.creditDetails?.worstOrder?.deadline,r.creditDetails?.worstOrder?.overdueDays,r.creditDetails?.stockScore,r.credit,r.totalScore,r.currentGrade])];
    const csv = rows.map(row => row.map(v => {let text = String(v ?? ''); if (/^[\s]*[=+@-]/.test(text)) text = "'" + text; return '"' + text.replaceAll('"','""') + '"';}).join(',')).join('\r\n');
    const url = URL.createObjectURL(new Blob(['\uFEFF' + csv], {type:'text/csv;charset=utf-8'}));
    const link = document.createElement('a'); link.href = url; link.download = `客户综合分析_${year}-${String(month).padStart(2,'0')}.csv`; link.click(); setTimeout(() => URL.revokeObjectURL(url),1000);
  }

  async function history(query={}, offset=0) {
    const q={keyword:'',actor:'',customer:'',latest:true,...query},size=20;
    openDialog(`<h2>评分历史版本</h2><p role="status">正在读取评分记录…</p>`);
    const modal=dialog;modal.classList.add('cr-version-dialog');
    try {
      const params=new URLSearchParams({customerId:q.customer,keyword:q.keyword,actor:q.actor,latest:q.latest?'1':'0',offset:String(offset),limit:String(size)});
      const result=await api('/api/customer-ratings/versions?'+params);
      if(dialog!==modal||!modal.open)return;
      const pages=Math.max(1,Math.ceil(result.total/size));
      const stamp=time=>esc(String(time||'').slice(0,19).replace('T',' '));
      const number=v=>v==null?'—':esc(String(v));
      const detail=event=>{
        const r=event.snapshot,previous=event.previousSnapshot;
        const labels=[['cooperationPotential','合作潜力'],['futureOrders','后续订单'],['expansionSpace','拓展空间'],['industryInfluence','行业影响力'],['benchmarkValue','营业额']];
        return `<div class="cv-detail"><h3>${event.scoreMode==='s-exempt-identity'?'本次身份确认（S类免评分）':'本次评分明细'}</h3>${event.scoreMode==='s-exempt-identity'?'<p class="subtle">本次仅确认身份，S类无需五项评分；以下分值保留原记录。</p>':''}<table class="cv-changes"><thead><tr><th>评分项目</th><th>保存前</th><th>本次保存</th></tr></thead><tbody>${labels.map(([k,label])=>`<tr><td>${label}</td><td>${number(event.before?.scoreDetails?.[k])}</td><td><strong>${number(event.after?.scoreDetails?.[k])}</strong></td></tr>`).join('')}<tr><td>客户身份</td><td>${event.before?.newCustomer===true?'新客户':event.before?.newCustomer===false?'非新客户':'待确认'}</td><td>${event.after?.newCustomer===true?'新客户':event.after?.newCustomer===false?'非新客户':'待确认'}</td></tr></tbody></table>
          ${r?`<div class="cv-snapshot"><p>保存时综合分 <strong>${number(r.totalScore)}</strong> · 等级 ${badge(r.currentGrade)}${previous?` · 上一版综合分 ${number(previous.totalScore)}`:''}</p><p>业务机会 ${number(r.opportunity)} · 行业地位 ${number(r.position)} · 销售分 ${number(r.salesScore)} · 信誉分 ${number(r.credit)}</p><p>统计月份 ${esc(event.period||'—')} · 销货净额 ${fmt(r.amount)} 元</p><p>未结清应收日 ${esc(r.creditDetails?.latestAccountDate||'无记录')} · 应收评分 ${number(r.creditDetails?.receivableScore)} · ${['earliest_open_business_due_plus_3_months','earliest_overdue_pickup_business_due_plus_3_months'].includes(event.rules?.orderBasis)?'交期评分':'入库评分'} ${number(r.creditDetails?.stockScore)}</p><details><summary>查看当时计算规则和版本编号</summary><p>销售 ${number(event.rules?.sales)}% · 业务机会 ${number(event.rules?.opportunity)}% · 信誉 ${number(event.rules?.credit)}% · 行业地位 ${number(event.rules?.position)}%</p><p>销售分算法：${event.rules?.salesScoreRule?.mode==='rounded_ten_thousands_capped_at_100'?'≥100万元记100分，其余按万元四舍五入取整':'保存当时的销售额分档规则'}</p><p>订单计分口径：${event.rules?.orderBasis==='earliest_overdue_pickup_business_due_plus_3_months'?'仅最早逾拿货业务交期＋3个月，对比评分日':event.rules?.orderBasis==='earliest_open_business_due_plus_3_months'?'最早未交完业务交期＋3个月，对比评分日':'保存当时的入库评分口径'}</p><p>版本编号：${esc(event.versionId||'早期记录')}</p></details></div>`:'<p class="subtle">早期记录没有保存当时综合分快照，仅展示已留存的修改内容。</p>'}</div>`;
      };
      modal.innerHTML=`<button class="ghost-button cr-close" aria-label="关闭">×</button><header class="cv-heading"><h2>评分历史版本</h2><p class="subtle">${q.customer?'当前客户的全部保存记录，可展开核对每次修改。':'默认每个客户显示最新一版；查看历次记录可追溯每次评分。'}</p></header>
        <form id="version-filter" class="cv-filters"><label>客户编号／名称<input name="keyword" placeholder="输入编号或客户名称" value="${esc(q.keyword)}"></label><label>评分人<select name="actor"><option value="">全部评分人</option>${result.actors.map(a=>`<option value="${esc(a.username)}" ${a.username===q.actor?'selected':''}>${esc(a.name||a.username)}${a.name?`（${esc(a.username)}）`:''}</option>`).join('')}</select></label><label>显示范围<select name="latest"><option value="1" ${q.latest?'selected':''}>每位客户最新一版</option><option value="0" ${!q.latest?'selected':''}>全部历史版本</option></select></label><button class="primary-button">查询</button><button type="button" class="ghost-button" data-version-reset>重置</button></form>
        <div class="cv-meta"><strong>${q.customer?`客户 ${esc(q.customer)}`:q.latest?'客户最新评分':'全部评分记录'}</strong><span>共 ${result.total} ${q.latest?'家客户':'条记录'} · 第 ${Math.floor(offset/size)+1} / ${pages} 页</span>${q.customer?'<button class="ghost-button" data-version-back>返回客户列表</button>':''}</div>
        <div class="cv-table-scroll"><table class="cv-table"><thead><tr><th>客户</th><th>版本</th><th>综合分</th><th>等级</th><th>评分人</th><th>保存时间</th><th>操作</th></tr></thead><tbody>${result.versions.map((event,i)=>{const r=event.snapshot;return `<tr><td><strong>${esc(r?.customerName||'客户 '+event.customerId)}</strong><small>${esc(event.customerId)}</small></td><td>${event.versionNumber?'V'+event.versionNumber:'早期记录'}<small>共 ${event.customerVersionCount} 版</small></td><td class="cv-score">${number(r?.totalScore)}</td><td>${r?badge(r.currentGrade):'—'}</td><td>${esc(event.actorName||event.actor)}<small>${event.actorName?esc(event.actor):''}</small></td><td class="cv-time">${stamp(event.time)}</td><td><button class="ghost-button" data-version-detail="${i}" aria-expanded="false" aria-controls="cv-detail-${i}">展开详情</button>${!q.customer?`<button class="cr-link" data-version-customer="${esc(event.customerId)}">历次记录</button>`:''}</td></tr><tr id="cv-detail-${i}" class="cv-detail-row" hidden><td colspan="7">${detail(event)}</td></tr>`;}).join('')||'<tr><td colspan="7" class="cv-empty">没有符合条件的评分记录，请调整筛选条件。</td></tr>'}</tbody></table></div>
        <footer class="cv-pagination"><span>按保存时间倒序 · 每页 ${size} 条</span><div><button class="ghost-button" data-version-prev ${offset===0?'disabled':''}>上一页</button><button class="ghost-button" data-version-next ${offset+size>=result.total?'disabled':''}>下一页</button></div></footer>`;
      modal.querySelector('.cr-close').onclick=()=>modal.close();
      modal.querySelector('#version-filter').onsubmit=e=>{e.preventDefault();const f=new FormData(e.target);history({...q,keyword:String(f.get('keyword')).trim(),actor:String(f.get('actor')),latest:f.get('latest')==='1'},0);};
      modal.querySelector('[data-version-reset]').onclick=()=>history();
      modal.querySelector('[data-version-back]')?.addEventListener('click',()=>history());
      modal.querySelector('[data-version-prev]').onclick=()=>history(q,Math.max(0,offset-size));
      modal.querySelector('[data-version-next]').onclick=()=>history(q,offset+size);
      modal.querySelectorAll('[data-version-customer]').forEach(button=>button.onclick=()=>history({customer:button.dataset.versionCustomer,latest:false}));
      modal.querySelectorAll('[data-version-detail]').forEach(button=>button.onclick=()=>{const row=modal.querySelector('#cv-detail-'+button.dataset.versionDetail);row.hidden=!row.hidden;button.setAttribute('aria-expanded',String(!row.hidden));button.textContent=row.hidden?'展开详情':'收起详情';});
    }catch(error){if(dialog!==modal||!modal.open)return;modal.innerHTML=`<button class="ghost-button cr-close" aria-label="关闭">×</button><h2>历史版本读取失败</h2><p class="cr-error" role="alert">${esc(error.message)}</p><button class="primary-button" data-retry>重试</button>`;modal.querySelector('.cr-close').onclick=()=>modal.close();modal.querySelector('[data-retry]').onclick=()=>history(q,offset);}
  }

  root.addEventListener('click', event => {
    const button = event.target.closest('button'); if (!button) return;
    if (button.dataset.scoreCustomer) return editScores(button.dataset.scoreCustomer);
    if (button.dataset.customer) return detail(button.dataset.customer);
    switch (button.dataset.action) {
      case 'export': return exportRows(); case 'refresh': return load(); case 'sync': return load(true); case 'history': return history();
      case 'prev': page--; break; case 'next': page++; break;
      case 'reset': filters = {keyword: '', person: '', industry: '', group: '', grade: '', status: ''}; page = 1; break;
      default: return;
    }
    draw();
  });
  root.addEventListener('change', event => {if(event.target.id === 'cr-group-filter'){filters={...filters,...Object.fromEntries(new FormData(root.querySelector('#cr-filters')))};page=1;draw();return;}if (event.target.id === 'cr-period' && event.target.checkValidity()) {[year, month] = event.target.value.split('-').map(Number); page = 1; data = null; load();}});
  root.addEventListener('submit', event => {
    if (event.target.id !== 'cr-filters') return;
    event.preventDefault(); filters = {...filters,...Object.fromEntries(new FormData(event.target))}; page = 1; draw();
  });
  setInterval(() => {if (root.classList.contains('active') && !document.hidden && !dialog && !busy && data) load();}, 60000);
  return {render() {if (!busy) load(); else draw();}, reset() {generation++; busy = false; data = null; dialog?.close(); root.innerHTML = '';}};
}
