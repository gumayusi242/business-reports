"""Customer-level scoring from the latest unsettled valid OMA02, without order joins."""
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
import calendar
import re
import json
from pathlib import Path
from warehouse_sales import LOCAL_TIME


def date_score(value, today):
    """No date is kept distinct from a valid date with zero elapsed days."""
    if value in (None, ''):
        return {'latestAccountDate': '', 'elapsedDays': None, 'score': 50}
    try:
        latest = value.date() if isinstance(value, datetime) else value if isinstance(value, date) else date.fromisoformat(str(value)[:10])
    except (TypeError, ValueError):
        return {'latestAccountDate': '', 'elapsedDays': None, 'score': None}
    days = max(0, (today - latest).days)
    score = 50 if days == 0 else 30 if days <= 30 else 10 if days <= 60 else -10 if days <= 90 else -30 if days <= 180 else -50
    return {'latestAccountDate': latest.isoformat(), 'elapsedDays': days, 'score': score}


def latest_dates(connect, customers):
    """Read valid invoices with positive unpaid balance for the supplied customer scope."""
    customers = sorted(set(customers))
    if not customers:
        return {}, ''
    connection = connect()
    try:
        with connection.cursor() as cursor:
            cursor.execute('SET SESSION MAX_EXECUTION_TIME=60000')
            cursor.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ')
            cursor.execute('START TRANSACTION READ ONLY')
            cursor.execute('''SELECT a.oma03 AS customerId, MAX(a.oma02) AS latestAccountDate,
                MAX(a.ods_insert_time) AS updated
                FROM ods_erp_oma_file a
                WHERE a.omaconf='Y' AND COALESCE(a.omavoid,'N')<>'Y'
                AND a.oma61 > 0 AND a.oma00 LIKE %s AND a.oma03 IN ('''+','.join(['%s']*len(customers))+''')
                GROUP BY a.oma03''', ['1%', *customers])
            rows = cursor.fetchall()
        updated = max((str(row.get('updated') or '') for row in rows), default='')
        return {str(row['customerId']): row.get('latestAccountDate') for row in rows}, updated
    finally:
        try:
            connection.rollback()
        finally:
            connection.close()


def days_score(days):
    return 50 if days <= 0 else 30 if days <= 30 else 10 if days <= 60 else -10 if days <= 90 else -30 if days <= 180 else -50


def three_months(value):
    month = value.month + 3
    year = value.year + (month - 1) // 12
    month = (month - 1) % 12 + 1
    return date(year, month, min(value.day, calendar.monthrange(year, month)[1]))


ORDER_BASIS = 'earliest_overdue_pickup_business_due_plus_3_months'


def order_number(value):
    if isinstance(value, str) and not value.strip():
        return 0.0
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return float('nan')


def plan_due_date(row):
    plan = str(row.get('planDueDate') or '')[:10]
    business = str(row.get('businessDueDate') or '')[:10]
    if re.fullmatch(r'2020-\d{2}-\d{2}', plan) and re.fullmatch(r'2026-\d{2}-\d{2}', business) and plan[5:] == business[5:]:
        return business
    return plan


def is_overdue_pickup(row, today):
    """Match getDerived's default-plan '逾拿货' branch in the order query."""
    if order_number(row.get('unshippedQty')) <= 0:
        return False
    try:
        due = date.fromisoformat(plan_due_date(row))
    except (ValueError, TypeError):
        return False
    if due >= today:
        return False
    progress = str(row.get('productionProgress') or row.get('workOrderStatus') or '').strip()
    if '已入库' in progress or '拿库存' not in progress:
        return False
    work = order_number(row.get('workOrderQty'))
    target = work if work > 0 else order_number(row.get('orderQty'))
    fully_stocked = target > 0 and order_number(row.get('stockInQty')) >= target
    return not fully_stocked


def order_score(row, today=None):
    today = today or datetime.now(LOCAL_TIME).date()
    due = row.get('businessDueDate')
    base = {'orderNo': str(row.get('orderNo') or ''), 'lineNo': str(row.get('lineNo') or ''),
            'orderDate': str(row.get('orderDate') or '')[:10],
            'businessDueDate': str(due or '')[:10], 'planDueDate': plan_due_date(row),
            'orderStatus': '逾拿货',
            'stockInDate': str(row.get('lastStockInDate') or '')[:10],
            'orderBasis': ORDER_BASIS}
    try:
        deadline = three_months(date.fromisoformat(base['businessDueDate']))
    except (ValueError, TypeError):
        return {**base, 'deadline': '', 'overdueDays': None, 'score': None, 'reason': '逾拿货订单的业务交期缺失或异常，待核对'}
    days = max(0, (today - deadline).days)
    return {**base, 'deadline': deadline.isoformat(), 'overdueDays': days,
            'score': days_score(days), 'reason': '按最早逾拿货业务交期加3个自然月，计算截至评分日的逾期天数'}


class CustomerCredit:
    def __init__(self, connect, data_dir):
        self.connect = connect
        self.root = Path(data_dir)

    def evaluate(self, customers):
        today = datetime.now(LOCAL_TIME).date()
        customers = set(customers)
        dates, updated = latest_dates(self.connect, customers)
        path = self.root / 'public-data' / 'orders.json'
        payload = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(payload, dict) or not isinstance(payload.get('records'), list):
            raise ValueError('订单综合查询数据不可用，无法计算信誉分')
        grouped = {customer: [] for customer in customers}
        all_counts = {customer: 0 for customer in customers}
        for row in payload['records']:
            customer = str(row.get('customerId') or '').strip()
            if customer in grouped:
                all_counts[customer] += 1
                if not is_overdue_pickup(row, today):
                    continue
                try:
                    remaining = Decimal(str(row.get('unshippedQty') or 0))
                    if not remaining.is_finite():
                        raise InvalidOperation
                except (InvalidOperation, ValueError):
                    grouped[customer].append({**order_score(row, today), 'score': None,
                                              'overdueDays': None, 'reason': '未交数量异常，待核对'})
                    continue
                if remaining > 0:
                    grouped[customer].append(order_score(row, today))
        records = {}
        for customer in customers:
            ar = date_score(dates.get(customer), today)
            orders = grouped[customer]
            invalid = sum(row['score'] is None for row in orders)
            valid = [row for row in orders if row['score'] is not None]
            worst = min(valid, key=lambda row: (row['businessDueDate'], row['orderDate'], row['orderNo'], row['lineNo'])) if valid else None
            stock_score = None if invalid else worst['score'] if worst else 50
            credit = (ar['score'] + stock_score) if ar['score'] is not None and stock_score is not None else None
            records[customer] = {**ar, 'receivableScore': ar['score'], 'stockScore': stock_score,
                                 'credit': credit, 'worstOrder': worst, 'orderLines': all_counts[customer],
                                 'pickupOrderLines': len(orders), 'openOrderLines': len(orders), 'orderScore': stock_score, 'orderBasis': ORDER_BASIS,
                                 'invalidOrderLines': invalid}
        return {'records': records, 'asOfDate': today.isoformat(), 'warehouseUpdatedAt': updated,
                'ordersAsOfDate': payload.get('asOfDate', ''), 'ordersGeneratedAt': payload.get('generatedAt', ''),
                'orderBasis': ORDER_BASIS, 'queriedAt': datetime.now(LOCAL_TIME).isoformat()}
