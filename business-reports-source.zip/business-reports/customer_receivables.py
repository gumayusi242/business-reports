"""Customer-level receivables and two-component credit scoring."""
import sys
from datetime import datetime
from warehouse_sales import LOCAL_TIME

class CustomerReceivables:
    def __init__(self, warehouse, customer_ratings):
        self.warehouse = warehouse
        self.customer_ratings = customer_ratings

    def connect(self):
        config = self.warehouse.config
        if not config:
            raise ValueError('尚未配置数仓连接')
        dependency_path = str(self.warehouse.root.parent / 'runtime/python-deps')
        if dependency_path not in sys.path:
            sys.path.insert(0, dependency_path)
        import pymysql
        return pymysql.connect(host=config['host'],port=int(config.get('port',3306)),user=config['user'],
                               password=config['password'],database=config['database'],charset='utf8mb4',
                               connect_timeout=10,read_timeout=90,write_timeout=10,local_infile=False,
                               cursorclass=pymysql.cursors.DictCursor)


    def fetch(self, params):
        def value(key, default=''):
            raw = params.get(key, [default])
            return str(raw[0] if isinstance(raw, list) else raw).strip()
        keyword, score = value('keyword'), value('score')
        if len(keyword) > 100 or score not in ('', '100', '80', '60', '40', '20', '0', 'missing'):
            raise ValueError('筛选条件无效')
        try:
            page, size = int(value('page', '1')), int(value('pageSize', '50'))
            if page < 1 or size < 1 or size > 100:
                raise ValueError()
        except ValueError:
            raise ValueError('分页参数无效') from None
        today = datetime.now(LOCAL_TIME).date()
        snapshot = self.customer_ratings.snapshot(today.year, today.month)
        if not snapshot.get('ready'):
            raise ValueError('客户综合等级分析尚未同步，无法确定完整客户名单')
        all_rows = [{k: r.get(k) for k in ['customerId','customerName','salesPerson','creditDetails']} for r in snapshot['records']]
        rows = [{k: v for k, v in r.items() if k != 'creditDetails'} | r['creditDetails'] for r in all_rows]
        rows.sort(key=lambda r: (r['credit'] is None, r['credit'] if r['credit'] is not None else 101, r['customerId']))
        summary = {'customers': len(rows), 'withDate': sum(bool(r['latestAccountDate']) for r in rows),
                   'withoutDate': sum(not r['latestAccountDate'] for r in rows)}
        rows = [r for r in rows if (not keyword or keyword.lower() in (r['customerId']+' '+r['customerName']).lower())
                and (not score or (not r['latestAccountDate'] if score == 'missing' else r['receivableScore'] == int(score)))]
        total = len(rows); pages = max(1, (total+size-1)//size); page = min(page, pages)
        return {'records': rows[(page-1)*size:page*size], 'total': total, 'pages': pages, 'summary': summary,
                'filters': {'keyword': keyword, 'score': score, 'page': page, 'pageSize': size},
                **snapshot['creditSource'], 'customerScope': {'customers': summary['customers'], 'period': snapshot['period']}}
