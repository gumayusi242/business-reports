# Design System

## Color
- Primary: `#7CFF4F` approximate from the reference neon green headline and CTA.
- Secondary / Accent: `#CFE2C7` approximate pale mint used by feature tiles.
- Background: `#DADADA` outer page background; `#071C1B` / `#0A1F1E` dark screen background.
- Surface: `rgba(8, 30, 29, 0.78)` for glass login panels; `rgba(207, 226, 199, 0.92)` for light highlight tiles.
- Border / Divider: `rgba(180, 210, 200, 0.18)` for dark borders; `rgba(7, 28, 27, 0.75)` for grid dividers.
- Text Primary: `#F4FFF1` on dark backgrounds.
- Text Secondary: `#B9C9C2`.
- Text Muted: `#6D837B`.
- Success / Warning / Error, if used: Success `#7CFF4F`; warning `#F7C948`; error `#FF6B6B`.

## Typography
- Font Family: `"Microsoft YaHei", "Segoe UI", Arial, sans-serif`.
- Page Title: `34px`, `700`, line-height `0.95`, color `#7CFF4F`; responsive down to `26px`.
- Section Title: `14px`, `700`, line-height `1.2`, color `#F4FFF1`.
- Body: `13px`, `400`, line-height `1.45`, color `#B9C9C2`.
- Caption / Meta: `9px` to `11px`, `700`, uppercase letter spacing `0.08em`, color `#7CFF4F` or `#6D837B`.
- Button / Control: `12px`, `700`, height `36px`, color contrast on neon green or dark glass fills.

## Spacing
- Page Padding: `44px` desktop, `18px` mobile.
- Section Gap: `24px` between navigation, hero, login area, and galaxy grid.
- Card Padding: `22px` for login panel; `14px` for any feature tiles.
- Element Gap: `12px` within forms; `8px` for compact controls.
- Grid / Column Gap: `1px` galaxy mosaic divider; `16px` login content grid gap.

## Components
- Button: Neon green fill `#7CFF4F`, dark text `#06201E`, radius `3px`, compact uppercase/semibold treatment; hover darkens to `#62E63D`.
- Card: Dark glass surface with thin translucent border, radius `8px`, shadow `0 28px 80px rgba(0,0,0,0.36)`.
- Navigation: Slim top strip inside a dark screen frame; brand left, compact links centered, CTA/search actions right.
- Input / Select: Dark translucent fill, `1px` muted green border, radius `4px`, `36px` height, focused with neon green outline.
- Galaxy Mosaic: Use a dedicated canvas space layer behind a transparent `3 x 8` pane grid. The animation should resemble a galaxy exhibit: starfield twinkle, drifting nebula glow, a rotating spiral galaxy core, subtle comet streaks, and small orbiting planets. The panes must only divide the continuous moving scene, not repeat separate backgrounds per tile.
- Table / List, if used: Existing dashboard tables keep current density; the style applies to login only unless expanded later.
- Modal / Drawer, if used: Use dark glass panel, `8px` radius, `24px` padding, and neon action button.

## Layout
- Page Structure: Centered monitor-like dark frame on neutral gray background; navigation at top, hero title centered, animated galaxy mosaic at bottom, login panel appears as a centered modal.
- Responsive Rules: Below `760px`, frame fills the viewport, hero title and login panel stack, galaxy grid becomes fewer columns, and navigation links collapse into small status pills.
- Density / Alignment: Compact, precise, left-aligned form controls; hero centered; galaxy panes use exact grid alignment and strong divider lines.
