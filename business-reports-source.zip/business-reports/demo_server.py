"""Local synthetic-data preview. Never imports a production connector."""
import json,mimetypes,argparse
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlparse,parse_qs
ROOT=Path(__file__).resolve().parent
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT/'dist' if (ROOT/'dist/index.html').exists() else ROOT),**kwargs)
 def send_json(self,obj,status=200):
  raw=json.dumps(obj,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
 def do_GET(self):
  route=urlparse(self.path).path
  routes=json.loads((ROOT/'demo/routes.json').read_text(encoding='utf-8'))
  if route in routes:return self.send_json(routes[route])
  if route.startswith('/api/'):return self.send_json({'error':'此接口未包含在离线演示中；原始适配器源码保留供二次开发。'},501)
  if route.startswith('/module/') or route.startswith('/injection/') and not route.endswith('overview'):self.path='/static/module.html'
  elif route in ('/overview','/production-analysis','/injection/overview'):self.path='/static/production-overview.html'
  elif route=='/inventory':self.path='/index.html'
  elif route=='/work/orders':self.path='/static/erp-orders.html'
  elif route.startswith('/work/'):self.path='/static/workspace.html'
  elif route=='/' and (ROOT/'static/index.html').exists():self.path='/static/index.html'
  # Only serve browser assets and synthetic fixtures, never source/config/state.
  suffix=Path(urlparse(self.path).path).suffix.lower()
  if suffix not in ('','.html','.js','.css','.svg','.png','.jpg','.jpeg','.webp','.woff','.woff2','.json','.ico'):return self.send_error(403)
  return super().do_GET()
 def do_POST(self):return self.send_json({'error':'离线演示只读，不接受真实业务数据或执行同步。'},405)
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=6812);args=parser.parse_args()
 print(f'Synthetic demo: http://127.0.0.1:{args.port}',flush=True)
 ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
