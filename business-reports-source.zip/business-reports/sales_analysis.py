"""Validated customer sales snapshots, independent of delivery and ERP data."""
import hashlib
import json
import re
import secrets
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path

GRADES = ('V', 'A', 'B', 'C', 'D', 'S')
MAX_ROWS = 50000
MAX_BODY_BYTES = 16 * 1024 * 1024


def read_snapshot(data_dir):
    path = Path(data_dir) / 'sales-analysis.json'
    if not path.exists():
        return {'revision': '', 'records': [], 'periodStart': '', 'periodEnd': ''}
    return json.loads(path.read_text(encoding='utf-8'))


def text(value, field, limit=200):
    if value is None:
        return ''
    if not isinstance(value, (str, int, float)) or isinstance(value, bool):
        raise ValueError(f'{field}格式错误')
    result = str(value).strip()
    if len(result) > limit:
        raise ValueError(f'{field}过长')
    return result


def normalize_snapshot(body):
    if not isinstance(body, dict):
        raise ValueError('导入数据必须为对象')
    periods = []
    for key, label in [('periodStart', '统计开始日期'), ('periodEnd', '统计结束日期')]:
        value = body.get(key)
        if not isinstance(value, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
            raise ValueError(f'{label}格式错误')
        try:
            date.fromisoformat(value)
        except ValueError:
            raise ValueError(f'{label}无效') from None
        periods.append(value)
    if periods[0] > periods[1]:
        raise ValueError('统计开始日期不能晚于结束日期')
    rows = body.get('records')
    if not isinstance(rows, list) or not 1 <= len(rows) <= MAX_ROWS:
        raise ValueError(f'客户明细必须包含 1 至 {MAX_ROWS:,} 行')
    records, seen = [], set()
    for index, row in enumerate(rows, 2):
        if not isinstance(row, dict):
            raise ValueError(f'第{index}行格式错误')
        customer = text(row.get('customerId'), '客户编号', 80)
        if not customer:
            raise ValueError(f'第{index}行缺少客户编号')
        if customer in seen:
            raise ValueError(f'第{index}行客户编号重复：{customer}；请提供每客户一行的汇总表')
        seen.add(customer)
        grade = text(row.get('grade'), '改后等级', 8).upper()
        if grade not in GRADES:
            raise ValueError(f'第{index}行等级无效，仅支持 V/A/B/C/D/S')
        try:
            amount = Decimal(text(row.get('amount'), '销货额', 60))
        except InvalidOperation:
            raise ValueError(f'第{index}行销货额不是有效数字') from None
        if not amount.is_finite() or amount.as_tuple().exponent < -18 or amount.as_tuple().exponent > 14 or abs(amount) > Decimal('100000000000000'):
            raise ValueError(f'第{index}行销货额超出有效范围')
        # Keep the Excel amount precision; presentation rounding happens only in the UI.
        records.append({'customerId': customer, 'customerName': text(row.get('customerName'), '客户简称'),
                        'industry': text(row.get('industry'), '行业'),
                        'salesPerson': text(row.get('salesPerson'), '业务员'),
                        'grade': grade, 'amount': format(amount, 'f')})
    return {'schemaVersion': 1, 'currency': 'CNY', 'periodStart': periods[0], 'periodEnd': periods[1],
            'sourceFile': text(body.get('sourceFile'), '文件名'), 'records': records}


def summarize(snapshot):
    groups = {grade: {'count': 0, 'amount': Decimal(0)} for grade in GRADES}
    for row in snapshot['records']:
        group = groups[row['grade']]
        group['count'] += 1
        group['amount'] += Decimal(row['amount'])
    total = sum((item['amount'] for item in groups.values()), Decimal(0))
    return {'customers': len(snapshot['records']), 'amount': str(total),
            'grades': {grade: {'count': group['count'], 'amount': str(group['amount'])}
                       for grade, group in groups.items()}}


def save_snapshot(data_dir, snapshot, previous, username):
    root = Path(data_dir)
    root.mkdir(parents=True, exist_ok=True)
    if previous.get('revision'):
        history = root / 'sales-analysis-history'
        history.mkdir(exist_ok=True)
        name = datetime.now().strftime('%Y%m%d%H%M%S%f') + '-' + secrets.token_hex(4) + '.json'
        (history / name).write_text(json.dumps(previous, ensure_ascii=False), encoding='utf-8')
    saved = {**snapshot, 'importedAt': datetime.now(timezone.utc).isoformat(), 'importedBy': username}
    saved['revision'] = hashlib.sha256(json.dumps(saved, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    temporary = root / ('sales-analysis-' + secrets.token_hex(8) + '.tmp')
    try:
        temporary.write_text(json.dumps(saved, ensure_ascii=False), encoding='utf-8')
        temporary.replace(root / 'sales-analysis.json')
    finally:
        temporary.unlink(missing_ok=True)
    return saved
