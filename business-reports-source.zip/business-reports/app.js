import {createCustomerScoring} from './customer-scoring.js?v=20261119-linear-sales-1';
import {createCustomerReceivables} from './customer-receivables.js?v=20261103-no-viewer-export-1';
import {createCustomerRatings} from './customer-ratings.js?v=20261119-linear-sales-1';

const DAY = 24 * 60 * 60 * 1000;
const ORDER_ROW_HEIGHT = 34;
const ENABLE_PROCEDURAL_SPACE = false;

const state = {
  records: [],
  filtered: [],
  dailyHistory: [],
  activeTab: "orders",
  status: "all",
  bucket: "all",
  planner: "all",
  salesPerson: "all",
  productionProgress: "all",
  kittingStatus: "all",
  kittingPage: 0,
  kittingOrdersCache: null,
  kittingReference: { orders: {} },
  kittingImportBusy: false,
  kittingImportMessage: "",
  kittingImportError: false,
  columnFilters: {},
  openColumnFilter: "",
  enrichedRecords: [],
  enrichedRecordsSource: null,
  enrichedRecordsDate: "",
  columnFilterOptionCache: new Map(),
  compiledColumnFilterCache: new Map(),
  selectedCustomer: "",
  compareFrom: "",
  compareTo: "",
  delayCycleDays: 30,
  delayMetric: "orders",
  delayBarDate: "",
  delayLineDate: "",
  delayDatasetCache: new Map(),
  delayDatasetLoading: new Set(),
  summaryTopLimit: 5,
  statusTrendMode: "daily",
  statusDueBasis: "plan",
  statusTrendRenderTimer: 0,
  customerOrderPage: 0,
  customerOrderSearch: "",
  stockOccupancy: { metric: "quantity", dimension: "customer", query: "", scope: "all", notice: "all" },
  showOrderPeopleColumns: false,
  sidebarCollapsed: false,
  user: null,
  users: [],
  usersRenderToken: 0,
  loginLogs: [],
  passwordResetUser: "",
  ordersRenderToken: 0,
  asOfDate: todayIso(),
  generatedAt: "",
  sources: {
    formal: 0,
    overdue: 0,
    inventory: 0,
  },
};

const els = {
  loginView: document.querySelector("#loginView"),
  dashboardView: document.querySelector("#dashboardView"),
  loginForm: document.querySelector("#loginForm"),
  loginUser: document.querySelector("#loginUser"),
  loginPass: document.querySelector("#loginPass"),
  loginError: document.querySelector("#loginError"),
  openLoginButton: document.querySelector("#openLoginButton"),
  closeLoginButton: document.querySelector("#closeLoginButton"),
  loginModal: document.querySelector("#loginModal"),
  spaceCanvas: document.querySelector("#spaceCanvas"),
  mosaicSpaceCanvas: document.querySelector("#mosaicSpaceCanvas"),
  asOfDate: document.querySelector("#asOfDate"),
  dataTime: document.querySelector("#dataTime"),
  freshness: document.querySelector("#freshness"),
  status: document.querySelector("#statusFilter"),
  bucket: document.querySelector("#bucketFilter"),
  planner: document.querySelector("#plannerFilter"),
  salesPerson: document.querySelector("#salesPersonFilter"),
  productionProgress: document.querySelector("#productionProgressFilter"),
  shipmentImportButton: document.querySelector("#shipmentImportButton"),
  workbench: document.querySelector(".workbench"),
  sidebarToggle: document.querySelector("#sidebarToggle"),
  currentUser: document.querySelector("#currentUser"),
  logoutButton: document.querySelector("#logoutButton"),
  importDropZone: document.querySelector("#importDropZone"),
  importButton: document.querySelector("#importButton"),
  excelImport: document.querySelector("#excelImport"),
  importStatus: document.querySelector("#importStatus"),
  kpis: document.querySelector("#kpis"),
  orders: document.querySelector("#ordersPanel"),
  customers: document.querySelector("#customersPanel"),
  products: document.querySelector("#productsPanel"),
  alerts: document.querySelector("#alertsPanel"),
  kitting: document.querySelector("#kittingPanel"),
  summary: document.querySelector("#summaryPanel"),
  compare: document.querySelector("#comparePanel"),
  users: document.querySelector("#usersPanel"),
  statusAnalysis: document.querySelector("#statusAnalysisPanel"),
  customerOrders: document.querySelector("#customerOrdersPanel"),
  warehouseCustomerOrders: document.querySelector("#warehouseCustomerOrdersPanel"),
  productionPlanning: document.querySelector("#productionPlanningPanel"),
  stockOccupancy: document.querySelector("#stockOccupancyPanel"),
};

const salesAnalysis = createCustomerReceivables({root: document.querySelector('#salesAnalysisPanel'), api, isAdmin, escapeHtml});
const customerScoring = createCustomerScoring({root: document.querySelector('#customerScoringPanel'), api, isAdmin, canScore: () => Boolean(state.user), escapeHtml});
const customerRatings = createCustomerRatings({root: document.querySelector('#customerRatingsPanel'), api, isAdmin, escapeHtml});

function installFetchFallback() {
  if (typeof window === "undefined" || typeof window.fetch === "function") return;
  window.fetch = (url, options = {}) => new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open(options.method || "GET", url, true);
    xhr.withCredentials = options.credentials === "include" || options.credentials === "same-origin";
    for (const [key, value] of Object.entries(options.headers || {})) {
      xhr.setRequestHeader(key, value);
    }
    xhr.onload = () => {
      const body = xhr.responseText || "";
      resolve({
        ok: xhr.status >= 200 && xhr.status < 300,
        status: xhr.status,
        statusText: xhr.statusText,
        text: async () => body,
        json: async () => JSON.parse(body || "null"),
      });
    };
    xhr.onerror = () => reject(new TypeError("Network request failed"));
    xhr.ontimeout = () => reject(new TypeError("Network request timed out"));
    xhr.send(options.body || null);
  });
}

installFetchFallback();

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, {
      credentials: "same-origin",
      ...options,
      headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    });
  } catch (error) {
    throw new Error("无法连接服务器，请刷新页面后重新登录再导入");
  }
  if (!response.ok) {
    let message = `请求失败 ${response.status}`;
    try {
      const payload = await response.json();
      message = payload.error || message;
    } catch {
      // Keep the default HTTP message.
    }
    if (response.status === 401 && path !== "/api/login") {
      showLogin("登录已过期，请重新登录。");
      message = "登录已过期，请重新登录。";
    }
    throw new Error(message);
  }
  if (response.status === 204) return null;
  return response.json();
}

function isAdmin() {
  return state.user?.role === "admin";
}

function canViewCustomerId() {
  return Boolean(state.user);
}

function openLoginModal(message = "") {
  els.loginError.textContent = message;
  els.loginModal.classList.remove("hidden");
  els.loginModal.setAttribute("aria-hidden", "false");
  window.setTimeout(() => els.loginUser.focus(), 0);
}

function closeLoginModal() {
  els.loginModal.classList.add("hidden");
  els.loginModal.setAttribute("aria-hidden", "true");
  els.loginError.textContent = "";
  els.loginPass.value = "";
}

let spaceFrame = 0;
let backgroundStars = [];
let mosaicStars = [];
let orbitPlanets = [];
let comets = [];

function randomRange(min, max) {
  return min + Math.random() * (max - min);
}

function resizeSpaceCanvas() {
  const canvas = els.spaceCanvas;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const width = Math.max(1, window.innerWidth);
  const height = Math.max(1, window.innerHeight);
  if (canvas) {
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  const mosaic = els.mosaicSpaceCanvas;
  if (mosaic) {
    const rect = mosaic.getBoundingClientRect();
    const mosaicWidth = Math.max(1, Math.floor(rect.width));
    const mosaicHeight = Math.max(1, Math.floor(rect.height));
    mosaic.width = Math.floor(mosaicWidth * dpr);
    mosaic.height = Math.floor(mosaicHeight * dpr);
    mosaic.style.width = `${mosaicWidth}px`;
    mosaic.style.height = `${mosaicHeight}px`;
    const mosaicCtx = mosaic.getContext("2d");
    mosaicCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    mosaicStars = Array.from({ length: Math.min(520, Math.floor((mosaicWidth * mosaicHeight) / 320)) }, () => ({
      x: Math.random() * mosaicWidth,
      y: Math.random() * mosaicHeight,
      r: randomRange(0.35, 1.35),
      alpha: randomRange(0.22, 0.95),
      pulse: randomRange(0.001, 0.004),
      phase: Math.random() * Math.PI * 2,
    }));
    orbitPlanets = [
      { orbit: 0.18, size: 9, color: "#b9a7ff", speed: 0.00016, phase: 0.4 },
      { orbit: 0.31, size: 14, color: "#d6a079", speed: -0.00011, phase: 2.2 },
      { orbit: 0.43, size: 11, color: "#6aa7ff", speed: 0.00009, phase: 4.2 },
      { orbit: 0.56, size: 17, color: "#c8d4df", speed: -0.00007, phase: 5.4 },
    ];
  }
  backgroundStars = Array.from({ length: Math.min(360, Math.floor((width * height) / 3600)) }, () => ({
    x: Math.random() * width,
    y: Math.random() * height,
    r: randomRange(0.3, 1.25),
    alpha: randomRange(0.18, 0.9),
    pulse: randomRange(0.0008, 0.003),
    phase: Math.random() * Math.PI * 2,
    drift: randomRange(0.01, 0.04),
  }));
  comets = Array.from({ length: 3 }, (_, index) => ({
    x: Math.random() * width,
    y: height * (0.12 + index * 0.18),
    speed: randomRange(0.18, 0.42),
    delay: index * 3800,
  }));
}

function drawStars(ctx, stars, width, height, now, driftScale = 1) {
  for (const star of stars) {
    const twinkle = 0.65 + Math.sin(now * star.pulse + star.phase) * 0.35;
    const x = (star.x + now * (star.drift || 0.01) * driftScale) % width;
    ctx.globalAlpha = star.alpha * twinkle;
    ctx.fillStyle = "#f8fbff";
    ctx.beginPath();
    ctx.arc(x, star.y, star.r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}

function drawNebula(ctx, width, height, now) {
  const drift = Math.sin(now / 9000) * width * 0.04;
  const core = ctx.createRadialGradient(width * 0.55 + drift, height * 0.45, 0, width * 0.55 + drift, height * 0.45, width * 0.58);
  core.addColorStop(0, "rgba(206, 211, 255, 0.28)");
  core.addColorStop(0.2, "rgba(109, 119, 190, 0.14)");
  core.addColorStop(0.55, "rgba(44, 35, 73, 0.08)");
  core.addColorStop(1, "rgba(0, 0, 0, 0)");
  ctx.fillStyle = core;
  ctx.fillRect(0, 0, width, height);
}

function drawSpiralGalaxy(ctx, width, height, now) {
  const cx = width * 0.52 + Math.sin(now / 11000) * width * 0.04;
  const cy = height * 0.52 + Math.cos(now / 14000) * height * 0.04;
  const rotation = now / 18000;

  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-0.18 + Math.sin(now / 13000) * 0.025);
  ctx.scale(1.75, 0.58);

  const halo = ctx.createRadialGradient(0, 0, 0, 0, 0, width * 0.33);
  halo.addColorStop(0, "rgba(255, 248, 235, 0.72)");
  halo.addColorStop(0.12, "rgba(197, 202, 255, 0.32)");
  halo.addColorStop(0.36, "rgba(115, 128, 210, 0.16)");
  halo.addColorStop(1, "rgba(7, 10, 18, 0)");
  ctx.fillStyle = halo;
  ctx.beginPath();
  ctx.arc(0, 0, width * 0.34, 0, Math.PI * 2);
  ctx.fill();

  for (let arm = 0; arm < 3; arm += 1) {
    ctx.beginPath();
    for (let i = 0; i < 260; i += 1) {
      const t = i / 260;
      const angle = rotation + arm * ((Math.PI * 2) / 3) + t * Math.PI * 3.2;
      const radius = t * width * 0.34;
      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * radius;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = arm === 1 ? "rgba(200, 216, 255, 0.24)" : "rgba(255, 238, 214, 0.2)";
    ctx.lineWidth = width * 0.024;
    ctx.shadowColor = "rgba(180, 200, 255, 0.32)";
    ctx.shadowBlur = 18;
    ctx.stroke();
  }
  ctx.restore();

  ctx.save();
  ctx.globalCompositeOperation = "screen";
  const nucleus = ctx.createRadialGradient(cx, cy, 0, cx, cy, width * 0.09);
  nucleus.addColorStop(0, "rgba(255,255,245,0.82)");
  nucleus.addColorStop(0.45, "rgba(186,198,255,0.32)");
  nucleus.addColorStop(1, "rgba(255,255,245,0)");
  ctx.fillStyle = nucleus;
  ctx.fillRect(0, 0, width, height);
  ctx.restore();
}

function drawPlanet(ctx, x, y, radius, color, now, ring = false) {
  const shade = ctx.createRadialGradient(x - radius * 0.35, y - radius * 0.35, 0, x, y, radius * 1.35);
  shade.addColorStop(0, "#ffffff");
  shade.addColorStop(0.18, color);
  shade.addColorStop(0.72, "#1f2338");
  shade.addColorStop(1, "#070914");
  ctx.fillStyle = shade;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fill();

  ctx.save();
  ctx.globalAlpha = 0.16;
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 1;
  for (let i = -2; i <= 2; i += 1) {
    ctx.beginPath();
    ctx.ellipse(x, y + i * radius * 0.18, radius * 0.82, radius * 0.12, Math.sin(now / 2500) * 0.2, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();

  if (ring) {
    ctx.save();
    ctx.strokeStyle = "rgba(220, 225, 255, 0.36)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(x, y, radius * 1.65, radius * 0.45, -0.35, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}

function drawMosaicSpace(now) {
  const canvas = els.mosaicSpaceCanvas;
  if (!canvas) return;
  const rect = canvas.getBoundingClientRect();
  const width = Math.max(1, rect.width);
  const height = Math.max(1, rect.height);
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, width, height);

  const bg = ctx.createLinearGradient(0, 0, width, height);
  bg.addColorStop(0, "#03050d");
  bg.addColorStop(0.45, "#0a1020");
  bg.addColorStop(1, "#06030a");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);

  drawStars(ctx, mosaicStars, width, height, now, 0.08);
  drawNebula(ctx, width, height, now);
  drawSpiralGalaxy(ctx, width, height, now);

  const centerX = width * 0.53;
  const centerY = height * 0.86;
  for (const planet of orbitPlanets) {
    const angle = planet.phase + now * planet.speed;
    const orbitX = width * planet.orbit;
    const orbitY = height * planet.orbit * 0.22;
    const x = centerX + Math.cos(angle) * orbitX;
    const y = centerY + Math.sin(angle) * orbitY;
    ctx.save();
    ctx.strokeStyle = "rgba(255,255,255,0.12)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.ellipse(centerX, centerY, orbitX, orbitY, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
    drawPlanet(ctx, x, y, planet.size, planet.color, now, planet.size > 13);
  }

  ctx.fillStyle = "rgba(0,0,0,0.22)";
  ctx.fillRect(0, 0, width, height);
}

function drawSpace() {
  const canvas = els.spaceCanvas;
  if (!canvas || els.loginView.hidden) {
    spaceFrame = 0;
    return;
  }
  const ctx = canvas.getContext("2d");
  const width = window.innerWidth;
  const height = window.innerHeight;
  const now = performance.now();
  ctx.clearRect(0, 0, width, height);

  const bg = ctx.createRadialGradient(width * 0.5, height * 0.42, 0, width * 0.5, height * 0.42, Math.max(width, height));
  bg.addColorStop(0, "rgba(25, 31, 58, 0.28)");
  bg.addColorStop(0.45, "rgba(7, 12, 26, 0.72)");
  bg.addColorStop(1, "rgba(2, 3, 8, 0.9)");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);

  drawStars(ctx, backgroundStars, width, height, now, 0.04);
  for (const comet of comets) {
    const x = (comet.x + (now - comet.delay) * comet.speed) % (width + 260) - 130;
    const y = comet.y + Math.sin(now / 3600 + comet.delay) * 24;
    const tail = ctx.createLinearGradient(x - 120, y - 28, x, y);
    tail.addColorStop(0, "rgba(124,255,79,0)");
    tail.addColorStop(1, "rgba(207,226,199,0.34)");
    ctx.strokeStyle = tail;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x - 120, y - 28);
    ctx.lineTo(x, y);
    ctx.stroke();
  }
  drawMosaicSpace(now);
  spaceFrame = window.requestAnimationFrame(drawSpace);
}

function startSpace() {
  if (!ENABLE_PROCEDURAL_SPACE) return;
  if (!els.spaceCanvas || spaceFrame) return;
  resizeSpaceCanvas();
  spaceFrame = window.requestAnimationFrame(drawSpace);
}

function stopSpace() {
  if (spaceFrame) window.cancelAnimationFrame(spaceFrame);
  spaceFrame = 0;
}

function showLogin(message = "") {
  salesAnalysis.reset();
  customerRatings.reset();
  customerScoring.reset();
  document.querySelector(".kpi-drill-modal")?.remove();
  state.user = null;
  els.loginView.classList.remove("hidden");
  els.loginView.hidden = false;
  els.dashboardView.classList.add("hidden");
  els.dashboardView.hidden = true;
  els.currentUser.textContent = "未登录";
  startSpace();
  if (message) openLoginModal(message);
  else closeLoginModal();
}

function showDashboard() {
  els.loginView.classList.add("hidden");
  els.loginView.hidden = true;
  closeLoginModal();
  stopSpace();
  els.dashboardView.classList.remove("hidden");
  els.dashboardView.hidden = false;
  applyPermissions();
}

function applyPermissions() {
  const admin = isAdmin();
  const showCustomer = canViewCustomerId();
  els.currentUser.textContent = `${state.user?.username || ""}（${admin ? "管理员" : "查看"}）`;
  document.querySelectorAll(".admin-only").forEach((node) => node.classList.toggle("hidden", !admin));
  document.querySelectorAll(".customer-sensitive").forEach((node) => node.classList.toggle("hidden", !showCustomer));
  els.importDropZone.classList.toggle("hidden", !admin);
  els.importButton.classList.toggle("hidden", !admin);
  if (!admin && state.activeTab === "users") showTab("orders");
  if (!showCustomer && ["customers", "customerOrders", "warehouseCustomerOrders", "productionPlanning", "stockOccupancy", "salesAnalysis", "customerRatings"].includes(state.activeTab)) showTab("orders");
}

function todayIso() {
  const d = new Date();
  return dateIso(d);
}

function dateIso(d) {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function localDateTimeText(d = new Date()) {
  const hour = String(d.getHours()).padStart(2, "0");
  const minute = String(d.getMinutes()).padStart(2, "0");
  const second = String(d.getSeconds()).padStart(2, "0");
  return `${dateIso(d)} ${hour}:${minute}:${second}`;
}

function formatGeneratedAt(value) {
  const text = String(value || "").trim();
  if (!text) return "未知";
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(Z|[+-]\d{2}:?\d{2})/.test(text)) {
    const date = new Date(text);
    if (!Number.isNaN(date.getTime())) return localDateTimeText(date);
  }
  return text.replace("T", " ");
}

function generatedAtDate(value) {
  const text = formatGeneratedAt(value);
  const [, date = ""] = text.match(/^(\d{4}-\d{2}-\d{2})/) || [];
  return date;
}

function effectiveAsOfDate(payload) {
  const savedDate = String(payload?.asOfDate || "").slice(0, 10);
  const generatedDate = generatedAtDate(payload?.generatedAt);
  return savedDate || generatedDate || state.asOfDate;
}

function selectedImportDate() {
  const selected = String(els.asOfDate?.value || "").slice(0, 10);
  return /^\d{4}-\d{2}-\d{2}$/.test(selected) ? selected : todayIso();
}

function validIsoDateText(year, month, day) {
  const y = Number(year);
  const m = Number(month);
  const d = Number(day);
  if (!y || !m || !d) return "";
  const date = new Date(y, m - 1, d);
  if (date.getFullYear() !== y || date.getMonth() !== m - 1 || date.getDate() !== d) return "";
  return dateIso(date);
}

function inferDateFromFileName(name) {
  const text = String(name || "");
  const compact = text.match(/(?:^|[^\d])((?:20)\d{2})(\d{2})(\d{2})(?:\d{4,6})?(?=[^\d]|$)/);
  if (compact) return validIsoDateText(compact[1], compact[2], compact[3]);
  const iso = text.match(/(?:^|[^\d])((?:20)\d{2})[-_.\/年](\d{1,2})[-_.\/月](\d{1,2})(?:日)?(?=[^\d]|$)/);
  if (iso) return validIsoDateText(iso[1], iso[2], iso[3]);
  const shortDate = text.match(/(?:^|[^\d])(\d{1,2})[._\/\-月](\d{1,2})(?:日)?(?=[^\d]|$)/);
  if (shortDate) return validIsoDateText(new Date().getFullYear(), shortDate[1], shortDate[2]);
  return "";
}

function inferredImportDate(files) {
  const dates = [...(files || [])]
    .map((file) => inferDateFromFileName(file.name))
    .filter(Boolean)
    .sort();
  return dates[dates.length - 1] || selectedImportDate();
}

function labelForIsoDate(value) {
  const [, month = "", day = ""] = String(value || "").match(/^\d{4}-(\d{2})-(\d{2})$/) || [];
  return month && day ? `${Number(month)}月${Number(day)}日` : String(value || "");
}

function parseDate(value) {
  if (!value) return null;
  const [y, m, d] = String(value).slice(0, 10).split("-").map(Number);
  if (!y || !m || !d) return null;
  return new Date(y, m - 1, d);
}

function normalizedPlanDueDate(record) {
  const plan = String(record?.planDueDate || "").slice(0, 10);
  const business = String(record?.businessDueDate || "").slice(0, 10);
  if (/^2020-\d{2}-\d{2}$/.test(plan) && /^2026-\d{2}-\d{2}$/.test(business) && plan.slice(5) === business.slice(5)) {
    return business;
  }
  return plan;
}

function excelSerialToDate(value) {
  const serial = Number(value);
  if (!Number.isFinite(serial)) return null;
  const millis = Math.round((serial - 25569) * DAY);
  const date = new Date(millis);
  return new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()).toISOString().slice(0, 10);
}

function xmlText(node) {
  return node?.textContent ?? "";
}

function colIndexFromCellRef(ref) {
  const letters = String(ref || "").match(/[A-Z]+/)?.[0] || "";
  let index = 0;
  for (const letter of letters) {
    index = index * 26 + (letter.charCodeAt(0) - 64);
  }
  return index - 1;
}

function parseSharedStrings(xml) {
  const doc = new DOMParser().parseFromString(xml, "application/xml");
  return [...doc.querySelectorAll("si")].map((si) => [...si.querySelectorAll("t")].map((t) => t.textContent || "").join(""));
}

function parseDateStyles(xml) {
  if (!xml) return new Set();
  const doc = new DOMParser().parseFromString(xml, "application/xml");
  const customFormats = new Map();
  doc.querySelectorAll("numFmts numFmt").forEach((fmt) => {
    customFormats.set(fmt.getAttribute("numFmtId"), fmt.getAttribute("formatCode") || "");
  });
  const builtinDateIds = new Set(["14", "15", "16", "17", "18", "19", "20", "21", "22", "27", "30", "36", "45", "46", "47", "50", "57"]);
  const dateStyles = new Set();
  doc.querySelectorAll("cellXfs xf").forEach((xf, index) => {
    const id = xf.getAttribute("numFmtId") || "";
    const code = customFormats.get(id) || "";
    if (builtinDateIds.has(id) || /[ymdhHsS]/.test(code.replace(/\[[^\]]+\]/g, ""))) {
      dateStyles.add(String(index));
    }
  });
  return dateStyles;
}

function parseCell(cell, sharedStrings, dateStyles) {
  const type = cell.getAttribute("t");
  const style = cell.getAttribute("s");
  if (type === "inlineStr") return xmlText(cell.querySelector("is t")).trim();
  const raw = xmlText(cell.querySelector("v"));
  if (!raw) return null;
  if (type === "s") return sharedStrings[Number(raw)] ?? "";
  if (type === "b") return raw === "1";
  if (dateStyles.has(style)) return excelSerialToDate(raw);
  const number = Number(raw);
  return Number.isFinite(number) ? number : raw;
}

function parseWorksheetRows(xml, sharedStrings, dateStyles) {
  const doc = new DOMParser().parseFromString(xml, "application/xml");
  const rows = [];
  doc.querySelectorAll("sheetData row").forEach((rowNode) => {
    const row = [];
    rowNode.querySelectorAll("c").forEach((cell) => {
      row[colIndexFromCellRef(cell.getAttribute("r"))] = parseCell(cell, sharedStrings, dateStyles);
    });
    rows.push(row.map((value) => value ?? null));
  });
  return rows;
}

function normalizeHeader(value) {
  return String(value || "").replace(/\s+/g, "").trim();
}

function rowNumber(value) {
  if (value === null || value === undefined || value === "") return 0;
  const number = Number(String(value).replace(/,/g, ""));
  return Number.isFinite(number) ? number : 0;
}

function readValue(row, headers, name) {
  const idx = headers.indexOf(name);
  return idx >= 0 ? row[idx] : null;
}

function readAnyValue(row, headers, names) {
  for (const name of names) {
    const value = readValue(row, headers, normalizeHeader(name));
    if (value !== null && value !== undefined && value !== "") return value;
  }
  return null;
}

function readAnyValueByAlias(row, headers, aliases) {
  if (!Array.isArray(aliases) || !aliases.length) return null;
  return readAnyValue(row, headers, aliases);
}

function cellOr(value, fallback) {
  return value !== null && value !== undefined && value !== "" ? value : fallback;
}

function hasAnyValue(row) {
  return (row || []).some((value) => value !== null && value !== undefined && value !== "");
}

function findHeaderInfo(rows, required, maxScan = 8) {
  for (let i = 0; i < Math.min(rows.length, maxScan); i += 1) {
    const headers = (rows[i] || []).map(normalizeHeader);
    if (required.every((name) => headers.includes(name))) {
      return { headers, rowIndex: i };
    }
  }
  return null;
}

function orderKey(record) {
  return [record.orderNo, record.lineNo ?? "", record.sku || record.spec || ""].join("|");
}

function compactText(value) {
  return String(value ?? "").trim();
}

function mapRowsToRecords(rows) {
  const required = ["订单号", "订单项次", "品号", "品名", "规格", "订单数量", "订单已出数", "订单未出数", "客户编号", "业务交期"];
  const info = findHeaderInfo(rows, required);
  if (!info) {
    throw new Error(`缺少必要列：${required.join("、")}`);
  }
  const { headers, rowIndex } = info;
  const missing = required.filter((name) => !headers.includes(name));
  if (missing.length) {
    throw new Error(`缺少必要列：${missing.join("、")}`);
  }
  const records = [];
  let currentBase = {};
  for (let i = rowIndex + 1; i < rows.length; i += 1) {
    const row = rows[i] || [];
    if (!hasAnyValue(row)) continue;
    const directOrderNo = readValue(row, headers, "订单号");
    const rowLineNo = readValue(row, headers, "订单项次");
    const rowSku = readValue(row, headers, "品号");
    const rowName = readValue(row, headers, "品名");
    const rowSpec = readValue(row, headers, "规格");
    const rowOrderQty = readValue(row, headers, "订单数量");
    const rowShippedQty = readValue(row, headers, "订单已出数");
    const rowUnshippedQty = readValue(row, headers, "订单未出数");
    const startsOrderLine = [directOrderNo, rowLineNo, rowSku, rowName, rowSpec, rowOrderQty, rowShippedQty, rowUnshippedQty].some(
      (value) => value !== null && value !== undefined && value !== "",
    );
    const orderNo = directOrderNo || currentBase.orderNo;
    if (!orderNo) continue;
    if (startsOrderLine) {
      currentBase = {
        orderNo,
        lineNo: cellOr(rowLineNo, currentBase.lineNo),
        sku: rowSku || currentBase.sku,
        name: rowName || currentBase.name,
        spec: rowSpec || currentBase.spec,
        category1: readValue(row, headers, "产品分类一") || currentBase.category1,
        category2: readValue(row, headers, "产品分类二") || currentBase.category2,
        category3: readValue(row, headers, "产品分类三") || currentBase.category3,
        category4: readValue(row, headers, "产品分类四") || currentBase.category4,
        orderQty: cellOr(rowOrderQty, currentBase.orderQty),
        shippedQty: cellOr(rowShippedQty, currentBase.shippedQty),
        unshippedQty: cellOr(rowUnshippedQty, currentBase.unshippedQty),
        salesPerson: readValue(row, headers, "业务员") || currentBase.salesPerson,
        followerNo: readValue(row, headers, "跟单员编号") || currentBase.followerNo,
        followerName: readValue(row, headers, "跟单员姓名") || readValue(row, headers, "跟踪员") || currentBase.followerName,
        customerId: readValue(row, headers, "客户编号") || currentBase.customerId,
        customerShortName: readAnyValue(row, headers, ["客户简称", "客户名称", "客户名"]) || currentBase.customerShortName,
        orderDate: readValue(row, headers, "订单日期") || currentBase.orderDate,
        businessDueDate: readValue(row, headers, "业务交期") || currentBase.businessDueDate,
        planDueDate: readValue(row, headers, "计划交期") || currentBase.planDueDate,
        lockedStock: readValue(row, headers, "是否锁库存") || currentBase.lockedStock,
        sourceOverdue: readValue(row, headers, "是否逾期") || readValue(row, headers, "逾期") || currentBase.sourceOverdue,
        planner: readValue(row, headers, "计划员") || readValue(row, headers, "PIaner") || currentBase.planner,
        orderAttribute: readValue(row, headers, "属性") || currentBase.orderAttribute,
      };
    }
    records.push({
      row: i + 1,
      orderNo: String(orderNo),
      lineNo: cellOr(rowLineNo, currentBase.lineNo),
      sku: String(rowSku || currentBase.sku || ""),
      name: String(rowName || currentBase.name || ""),
      spec: String(rowSpec || currentBase.spec || ""),
      category1: String(readValue(row, headers, "产品分类一") || currentBase.category1 || ""),
      category2: String(readValue(row, headers, "产品分类二") || currentBase.category2 || ""),
      category3: String(readValue(row, headers, "产品分类三") || currentBase.category3 || ""),
      category4: String(readValue(row, headers, "产品分类四") || currentBase.category4 || "未分类"),
      orderQty: rowNumber(cellOr(rowOrderQty, currentBase.orderQty)),
      shippedQty: rowNumber(cellOr(rowShippedQty, currentBase.shippedQty)),
      unshippedQty: rowNumber(cellOr(rowUnshippedQty, currentBase.unshippedQty)),
      salesPerson: String(readValue(row, headers, "业务员") || currentBase.salesPerson || ""),
      followerNo: String(readValue(row, headers, "跟单员编号") || currentBase.followerNo || ""),
      followerName: String(readValue(row, headers, "跟单员姓名") || readValue(row, headers, "跟踪员") || currentBase.followerName || ""),
      customerId: String(readValue(row, headers, "客户编号") || currentBase.customerId || ""),
      customerShortName: String(readAnyValue(row, headers, ["客户简称", "客户名称", "客户名"]) || currentBase.customerShortName || ""),
      orderDate: readValue(row, headers, "订单日期") || currentBase.orderDate,
      businessDueDate: readValue(row, headers, "业务交期") || currentBase.businessDueDate,
      planDueDate: readValue(row, headers, "计划交期") || currentBase.planDueDate,
      lockedStock: String(readValue(row, headers, "是否锁库存") || currentBase.lockedStock || ""),
      sourceOverdue: String(readValue(row, headers, "是否逾期") || readValue(row, headers, "逾期") || currentBase.sourceOverdue || ""),
      planner: String(readValue(row, headers, "计划员") || readValue(row, headers, "PIaner") || currentBase.planner || ""),
      orderAttribute: String(readValue(row, headers, "属性") || currentBase.orderAttribute || ""),
      workOrderNo: String(readValue(row, headers, "工单号") || ""),
      workOrderStatus: String(readValue(row, headers, "工单系统状态") || ""),
      productionProgress: String(readValue(row, headers, "工单生产进度") || ""),
      workOrderQty: rowNumber(readValue(row, headers, "工单数量")),
      reportedQty: rowNumber(readValue(row, headers, "工单报工数")),
      lastReportedDate: readAnyValueByAlias(
        row,
        headers,
        ["最近报工日期", "报工时间", "报工日期", "最后报工时间", "报工最后时间", "工单报工时间", "工单报工日期", "工单报工明细日期"],
      ),
      inspectionQty: rowNumber(readValue(row, headers, "检验数")),
      lastInspectionDate: readAnyValueByAlias(
        row,
        headers,
        ["最近检验日期", "检验时间", "检验日期", "最后检验时间", "检验最后时间", "工单检验时间", "工单检验日期", "检验明细日期"],
      ),
      stockInQty: rowNumber(readValue(row, headers, "入库数")),
      lastStockInDate: readAnyValueByAlias(
        row,
        headers,
        ["最近入库日期", "入库时间", "入库日期", "最后入库时间", "入库最后时间", "工单入库时间", "工单入库日期", "入库明细日期"],
      ),
      inventoryQty: 0,
      availableStock: 0,
      customerStock: 0,
      inventoryRows: 0,
      warehouses: "",
      sourceTables: [],
    });
  }
  return records;
}

function mapInventoryRows(rows) {
  const info = findHeaderInfo(rows, ["仓库", "品号", "规格", "库存数量", "库存可用量"], 12);
  if (!info) throw new Error("库存表缺少必要列：仓库、品号、规格、库存数量、库存可用量");
  const { headers, rowIndex } = info;
  const bySku = new Map();
  const bySpec = new Map();

  for (let i = rowIndex + 1; i < rows.length; i += 1) {
    const row = rows[i] || [];
    const sku = compactText(readValue(row, headers, "品号"));
    const spec = compactText(readValue(row, headers, "规格"));
    if (!sku && !spec) continue;
    const item = {
      warehouse: compactText(readValue(row, headers, "仓库")),
      sku,
      name: compactText(readValue(row, headers, "品名")),
      spec,
      inventoryQty: rowNumber(readValue(row, headers, "库存数量")),
      availableStock: rowNumber(readValue(row, headers, "库存数量")),
      customerStock: rowNumber(readValue(row, headers, "库存可用量")),
      orderNo: compactText(readValue(row, headers, "订单号")),
      lineNo: compactText(readValue(row, headers, "项次")),
      customerId: compactText(readValue(row, headers, "客户编号")),
      dueDate: readValue(row, headers, "预交期"),
      stockInDate: readAnyValueByAlias(row, headers, ["入库日期", "入库时间"]),
    };
    addInventoryAgg(bySku, sku, item);
    addInventoryAgg(bySpec, spec, item);
  }

  return { bySku, bySpec };
}

function addInventoryAgg(map, key, item) {
  if (!key || key === "-") return;
  if (!map.has(key)) {
    map.set(key, {
      inventoryQty: 0,
      availableStock: 0,
      customerStock: 0,
      rows: 0,
      warehouses: new Set(),
    });
  }
  const agg = map.get(key);
  agg.inventoryQty += item.inventoryQty;
  agg.availableStock += item.availableStock;
  agg.customerStock += item.customerStock;
  agg.rows += 1;
  if (item.warehouse) agg.warehouses.add(item.warehouse);
}

function classifyRows(rows, fileName = "") {
  const normalizedFileName = normalizeHeader(String(fileName).replace(/\.xlsx$/i, ""));
  const headerCandidates = rows.slice(0, 12).map((row) => (row || []).map(normalizeHeader).join("|")).join("\n");
  if (/(库存|成品条码)/.test(normalizedFileName)) return "inventory";
  if (/(未出正式订单|正式订单明细)/.test(normalizedFileName)) return "formal";
  if (/(逾期|路径)/.test(normalizedFileName)) return "overdue";
  if (headerCandidates.includes("库存可用量") && headerCandidates.includes("仓库")) return "inventory";
  if (headerCandidates.includes("订单额") || headerCandidates.includes("PIaner")) return "overdue";
  if (headerCandidates.includes("订单号") && headerCandidates.includes("订单未出数")) return "formal";
  if (headerCandidates.includes("订单号") && headerCandidates.includes("工单号")) return "overdue";
  return "unknown";
}

function mergeSources(parts) {
  const base = parts.formal.length ? parts.formal : parts.overdue;
  const map = new Map();
  for (const record of base) {
    map.set(orderKey(record), { ...record, sourceTables: record.sourceTables?.length ? [...record.sourceTables] : [parts.formal.length ? "未出正式订单明细表" : "订单逾期未发"] });
  }

  for (const record of parts.overdue) {
    const key = orderKey(record);
    const existing = map.get(key);
    if (existing) {
      const seenWorkOrders = new Set(existing.workOrderTotalKeys || splitUniqueText(existing.workOrderNo));
      mergeOrderTextFields(existing, record);
      addWorkOrderTotals(existing, record, seenWorkOrders);
      if (!existing.sourceTables.includes("订单逾期未发")) existing.sourceTables.push("订单逾期未发");
    } else if (!parts.formal.length) {
      map.set(key, { ...record, sourceTables: ["订单逾期未发"] });
    }
  }

  for (const record of map.values()) {
    const stock = parts.inventory.bySku.get(record.sku) || parts.inventory.bySpec.get(record.spec);
    if (stock) {
      record.inventoryQty = stock.inventoryQty;
      record.availableStock = stock.availableStock;
      record.customerStock = stock.customerStock;
      record.inventoryRows = stock.rows;
      record.warehouses = [...stock.warehouses].join("、");
      record.sourceTables.push("成品条码库存查询表");
    }
  }
  return [...map.values()].map((record) => {
    const cleanRecord = { ...record };
    delete cleanRecord.workOrderTotalKeys;
    delete cleanRecord.workOrderTotals;
    delete cleanRecord.unkeyedWorkTotals;
    return cleanRecord;
  });
}

function preservePeopleFields(records, previousRecords = state.records) {
  const previousByKey = new Map((previousRecords || []).map((record) => [orderKey(record), record]));
  const fields = ["salesPerson", "followerNo", "followerName", "customerShortName"];
  for (const record of records) {
    const previous = previousByKey.get(orderKey(record));
    if (!previous) continue;
    for (const field of fields) {
      if (compactText(record[field])) continue;
      const value = compactText(previous[field]);
      if (value) record[field] = value;
    }
  }
  return records;
}

function appendUniqueText(existing, next) {
  const values = splitUniqueText(existing);
  for (const text of splitUniqueText(next)) {
    if (!values.includes(text)) values.push(text);
  }
  return values.join("、");
}

const WORK_TOTAL_FIELDS = ["workOrderQty", "reportedQty", "inspectionQty", "stockInQty"];

function splitUniqueText(value) {
  return String(value || "")
    .split("、")
    .map((item) => compactText(item))
    .filter(Boolean)
    .filter((item, index, arr) => arr.indexOf(item) === index);
}

function maxDateText(existing, next) {
  const existingText = compactText(existing);
  const nextText = compactText(next);
  if (!nextText) return existingText;
  if (!existingText) return nextText;
  return nextText > existingText ? nextText : existingText;
}

function workTotalValues(record) {
  const totals = {};
  for (const field of WORK_TOTAL_FIELDS) totals[field] = Number(record?.[field] || 0);
  return totals;
}

function addWorkTotals(base, values) {
  const totals = workTotalValues(base);
  for (const field of WORK_TOTAL_FIELDS) totals[field] += Number(values?.[field] || 0);
  return totals;
}

function sumKeyedWorkTotals(target) {
  const totals = workTotalValues(null);
  const stored = target.workOrderTotals && typeof target.workOrderTotals === "object" ? target.workOrderTotals : {};
  for (const values of Object.values(stored)) {
    for (const field of WORK_TOTAL_FIELDS) totals[field] += Number(values?.[field] || 0);
  }
  return totals;
}

function refreshWorkTotals(target) {
  const keyedTotals = sumKeyedWorkTotals(target);
  const unkeyedTotals = workTotalValues(target.unkeyedWorkTotals);
  for (const field of WORK_TOTAL_FIELDS) {
    target[field] = Math.max(keyedTotals[field], unkeyedTotals[field]);
  }
}

function workOrderTotalEntries(source) {
  const stored = source.workOrderTotals && typeof source.workOrderTotals === "object" ? source.workOrderTotals : null;
  if (stored) {
    const keys = splitUniqueText(source.workOrderNo);
    const workOrders = keys.length ? keys : Object.keys(stored);
    return workOrders
      .filter((workOrder) => stored[workOrder])
      .map((workOrder) => [workOrder, workTotalValues(stored[workOrder])]);
  }
  const workOrders = splitUniqueText(source.workOrderNo);
  return workOrders.length === 1 ? [[workOrders[0], workTotalValues(source)]] : [];
}

function addUnkeyedWorkTotals(target, source) {
  target.unkeyedWorkTotals = addWorkTotals(target.unkeyedWorkTotals, source);
  refreshWorkTotals(target);
}

function applyWorkOrderTotal(target, workOrder, values) {
  if (!target.workOrderTotals || typeof target.workOrderTotals !== "object") {
    target.workOrderTotals = {};
  }
  const existing = target.workOrderTotals[workOrder];
  if (!existing) {
    target.workOrderTotals[workOrder] = workTotalValues(values);
    refreshWorkTotals(target);
    return;
  }
  for (const field of WORK_TOTAL_FIELDS) {
    const current = Number(existing[field] || 0);
    const next = Math.max(current, Number(values[field] || 0));
    existing[field] = next;
  }
  refreshWorkTotals(target);
}

function addWorkOrderTotals(target, source, seenWorkOrders) {
  const workOrders = splitUniqueText(source.workOrderNo);
  const entries = workOrderTotalEntries(source);
  if (entries.length) {
    for (const [workOrder, totals] of entries) {
      applyWorkOrderTotal(target, workOrder, totals);
      seenWorkOrders.add(workOrder);
    }
    target.workOrderTotalKeys = [...seenWorkOrders];
    return;
  }
  if (!workOrders.length) return addUnkeyedWorkTotals(target, source);
  const newWorkOrders = workOrders.filter((workOrder) => !seenWorkOrders.has(workOrder));
  if (newWorkOrders.length || !seenWorkOrders.size) addUnkeyedWorkTotals(target, source);
  for (const workOrder of workOrders) seenWorkOrders.add(workOrder);
  target.workOrderTotalKeys = [...seenWorkOrders];
}

function mergeOrderTextFields(target, source) {
  target.workOrderNo = appendUniqueText(target.workOrderNo, source.workOrderNo);
  target.workOrderStatus = appendUniqueText(target.workOrderStatus, source.workOrderStatus);
  target.productionProgress = appendUniqueText(target.productionProgress, source.productionProgress);
  target.orderAttribute = appendUniqueText(target.orderAttribute, source.orderAttribute);
  target.salesPerson = appendUniqueText(target.salesPerson, source.salesPerson);
  target.followerNo = appendUniqueText(target.followerNo, source.followerNo);
  target.followerName = appendUniqueText(target.followerName, source.followerName);
  target.customerShortName = appendUniqueText(target.customerShortName, source.customerShortName);
  target.lastReportedDate = maxDateText(target.lastReportedDate, source.lastReportedDate);
  target.lastInspectionDate = maxDateText(target.lastInspectionDate, source.lastInspectionDate);
  target.lastStockInDate = maxDateText(target.lastStockInDate, source.lastStockInDate);
}

function aggregateOrderRecords(records, sourceName) {
  const map = new Map();
  const trackers = new Map();
  for (const record of records) {
    const key = orderKey(record);
    if (!map.has(key)) {
      const item = { ...record, sourceTables: [sourceName], workOrderTotalKeys: [], workOrderTotals: {}, unkeyedWorkTotals: workTotalValues(null) };
      for (const field of WORK_TOTAL_FIELDS) item[field] = 0;
      map.set(key, item);
      trackers.set(key, new Set());
    }
    const existing = map.get(key);
    const tracker = trackers.get(key);
    mergeOrderTextFields(existing, record);
    addWorkOrderTotals(existing, record, tracker);
  }
  return [...map.values()];
}

async function parseXlsxRows(file) {
  if (!window.JSZip) throw new Error("Excel 解析模块未加载");
  const zip = await window.JSZip.loadAsync(await file.arrayBuffer());
  const workbookXml = await zip.file("xl/workbook.xml")?.async("string");
  const relsXml = await zip.file("xl/_rels/workbook.xml.rels")?.async("string");
  let sheetPath = "xl/worksheets/sheet1.xml";
  if (workbookXml && relsXml) {
    const workbookDoc = new DOMParser().parseFromString(workbookXml, "application/xml");
    const firstSheetRel = workbookDoc.querySelector("sheets sheet")?.getAttribute("r:id");
    const relsDoc = new DOMParser().parseFromString(relsXml, "application/xml");
    const rel = [...relsDoc.querySelectorAll("Relationship")].find((item) => item.getAttribute("Id") === firstSheetRel);
    const target = rel?.getAttribute("Target");
    if (target) sheetPath = `xl/${target.replace(/^\/?xl\//, "")}`;
  }
  const sheetXml = await zip.file(sheetPath)?.async("string");
  if (!sheetXml) throw new Error("找不到第一个工作表");
  const sharedXml = await zip.file("xl/sharedStrings.xml")?.async("string");
  const stylesXml = await zip.file("xl/styles.xml")?.async("string");
  const sharedStrings = sharedXml ? parseSharedStrings(sharedXml) : [];
  const dateStyles = parseDateStyles(stylesXml);
  return parseWorksheetRows(sheetXml, sharedStrings, dateStyles);
}

async function importDailyFiles(files) {
  if (files.length !== 3) {
    throw new Error("请一次拖入 3 张 Excel：未出正式订单、逾期表、库存表");
  }
  const parts = {
    formal: [],
    overdue: [],
    inventory: { bySku: new Map(), bySpec: new Map() },
  };
  const counts = { formal: 0, overdue: 0, inventory: 0, unknown: 0 };
  const names = [];

  for (const file of files) {
    const rows = await parseXlsxRows(file);
    const kind = classifyRows(rows, file.name);
    names.push(`${file.name}：${kind}`);
    if (kind === "inventory") {
      parts.inventory = mapInventoryRows(rows);
      counts.inventory = [...parts.inventory.bySku.values()].reduce((sum, item) => sum + item.rows, 0);
    } else if (kind === "overdue") {
      parts.overdue = aggregateOrderRecords(mapRowsToRecords(rows), "订单逾期未发");
      counts.overdue = parts.overdue.length;
    } else if (kind === "formal") {
      parts.formal = aggregateOrderRecords(mapRowsToRecords(rows), "未出正式订单明细表");
      counts.formal = parts.formal.length;
    } else {
      counts.unknown += 1;
    }
  }

  const missing = [];
  if (!parts.formal.length) missing.push("未出正式订单明细表");
  if (!parts.overdue.length) missing.push("逾期表");
  if (!counts.inventory) missing.push("成品条码库存表");
  if (missing.length) {
    const kindLabels = { formal: "未出正式订单", overdue: "逾期表", inventory: "库存表", unknown: "未识别" };
    throw new Error(`三表未识别完整，缺少：${missing.join("、")}；识别结果：${names.map((item) => {
      const [fileName, kind] = item.split("：");
      return `${fileName}→${kindLabels[kind] || kind}`;
    }).join("；")}`);
  }

  return { records: preservePeopleFields(mergeSources(parts)), counts, names };
}

const quantityFormatter = new Intl.NumberFormat("zh-CN", { maximumFractionDigits: 0 });
const columnValueCollator = new Intl.Collator("zh-Hans-CN", { numeric: true, sensitivity: "base" });

function fmtNumber(value) {
  return quantityFormatter.format(Number(value || 0));
}

function fmtDelta(value) {
  const number = Number(value || 0);
  if (!number) return "0";
  return `${number > 0 ? "+" : ""}${fmtNumber(number)}`;
}

function fmtDate(value) {
  return value ? String(value).slice(0, 10) : "";
}

function progressNotOverdueLabel(record) {
  const text = compactText(record.productionProgress || record.workOrderStatus);
  if (text.includes("已入库")) return "已入库";
  if (text.includes("拿库存")) return "拿库存";
  return "";
}

function isFullyStockedIn(record) {
  const stockInQty = Number(record.stockInQty || 0);
  const workOrderQty = Number(record.workOrderQty || 0);
  const orderQty = Number(record.orderQty || 0);
  const targetQty = workOrderQty > 0 ? workOrderQty : orderQty;
  return targetQty > 0 && stockInQty >= targetQty;
}

function getDerived(record, asOf = parseDate(state.asOfDate), dueBasis = "plan") {
  const due = parseDate(dueBasis === "business" ? record.businessDueDate : normalizedPlanDueDate(record));
  const missingDue = !due;
  const completed = Number(record.unshippedQty || 0) <= 0;
  const progressDone = progressNotOverdueLabel(record);
  let overdueDays = 0;
  let status = "normal";
  let statusText = "未逾期";
  let bucket = "normal";
  let bucketText = "未逾期";
  let warningLevel = "";

  if (completed) {
    status = "done";
    statusText = "已交完";
    bucket = "done";
    bucketText = "已交完";
  } else if (missingDue) {
    status = "missing";
    statusText = "交期缺失";
    bucket = "missing";
    bucketText = "交期缺失";
  } else if (due < asOf) {
    status = "overdue";
    overdueDays = Math.floor((asOf - due) / DAY);
    if (overdueDays <= 3) {
      bucket = "1-3";
      bucketText = "1～3天";
      warningLevel = "关注";
    } else if (overdueDays <= 7) {
      bucket = "4-7";
      bucketText = "4～7天";
      warningLevel = "催促";
    } else if (overdueDays <= 15) {
      bucket = "8-15";
      bucketText = "8～15天";
      warningLevel = "升级";
    } else if (overdueDays <= 23) {
      bucket = "16-23";
      bucketText = "16～23天";
      warningLevel = "重点";
    } else {
      bucket = "24+";
      bucketText = "24天以上";
      warningLevel = "严重";
    }
    if (progressDone === "已入库" || isFullyStockedIn(record)) {
      statusText = "逾已入";
    } else if (progressDone === "拿库存") {
      statusText = "逾拿货";
    } else if (Number(record.stockInQty || 0) > 0) {
      statusText = "逾部分入";
    } else {
      statusText = "逾未入";
    }
  }

  const canShipFromStock = Number(record.unshippedQty || 0) > 0 && Number(record.availableStock || 0) >= Number(record.unshippedQty || 0);
  return { status, statusText, bucket, bucketText, warningLevel, overdueDays, canShipFromStock };
}

function enrich(record) {
  return { ...record, ...getDerived(record) };
}

function getEnrichedRecords() {
  if (state.enrichedRecordsSource !== state.records || state.enrichedRecordsDate !== state.asOfDate) {
    state.enrichedRecords = state.records.map(enrich);
    state.enrichedRecordsSource = state.records;
    state.enrichedRecordsDate = state.asOfDate;
    state.columnFilterOptionCache.clear();
    state.compiledColumnFilterCache.clear();
  }
  return state.enrichedRecords;
}

function resetDerivedCaches() {
  state.enrichedRecords = [];
  state.enrichedRecordsSource = null;
  state.enrichedRecordsDate = "";
  state.columnFilterOptionCache.clear();
  state.compiledColumnFilterCache.clear();
  state.kittingOrdersCache = null;
}

function enrichForDate(record, asOfDate) {
  const previousDate = state.asOfDate;
  state.asOfDate = asOfDate;
  const result = { ...record, ...getDerived(record) };
  state.asOfDate = previousDate;
  return result;
}

function metricsFromRecords(records, asOfDate) {
  const enriched = records.map((record) => enrichForDate(record, asOfDate));
  const overdue = enriched.filter((record) => record.status === "overdue");
  return {
    orders: enriched.length,
    overdueLines: overdue.length,
    overdueQty: overdue.reduce((sum, record) => sum + Number(record.unshippedQty || 0), 0),
    customers: new Set(overdue.map((record) => record.customerId).filter(Boolean)).size,
    severeLines: overdue.filter((record) => record.bucket === "24+").length,
    stockReadyLines: overdue.filter((record) => record.canShipFromStock).length,
    missingDueLines: enriched.filter((record) => record.status === "missing").length,
  };
}

function rememberCurrentHistoryEntry() {
  const date = state.asOfDate;
  const [, month = "", day = ""] = date.match(/^\d{4}-(\d{2})-(\d{2})$/) || [];
  const entry = {
    date,
    label: month && day ? `${Number(month)}月${Number(day)}日` : date,
    file: "",
    generatedAt: state.generatedAt,
    records: state.records.length,
    sources: state.sources,
    metrics: metricsFromRecords(state.records, date),
  };
  state.dailyHistory = [...state.dailyHistory.filter((item) => item.date !== date), entry].sort((a, b) => a.date.localeCompare(b.date));
}

function applyFilters() {
  const records = getEnrichedRecords();
  const filters = activeColumnFilters();
  state.filtered = records.filter((record) => matchesGlobalFilters(record) && matchesColumnFilters(record, "", filters));
}

function matchesGlobalFilters(record, derived = record) {
  if (state.status !== "all" && !matchesStatusFilter(derived, state.status)) return false;
  if (state.bucket !== "all" && derived.bucket !== state.bucket) return false;
  if (state.planner !== "all" && record.planner !== state.planner) return false;
  if (state.salesPerson !== "all" && record.salesPerson !== state.salesPerson) return false;
  if (state.productionProgress !== "all" && (record.productionProgress || record.workOrderStatus || "未标明") !== state.productionProgress) return false;
  return true;
}

function matchesStatusFilter(record, statusValue) {
  const statusText = record.statusText || "";
  if (statusValue === "overdue") return record.status === "overdue";
  if (statusValue === "overdueUnstocked") return statusText === "逾未入";
  if (statusValue === "overduePartiallyStocked") return statusText === "逾部分入";
  if (statusValue === "overdueStocked") return statusText === "逾已入";
  if (statusValue === "overdueTakeStock") return statusText === "逾拿货";
  if (statusValue === "normal") return record.status === "normal";
  return record.status === statusValue;
}

function badge(record) {
  const statusText = record.statusText || "";
  const isOverdue = record.status === "overdue" || statusText.startsWith("逾");
  const classMap = {
    normal: "b-normal",
    missing: "b-missing",
    done: "b-done",
    "1-3": "b-1-3",
    "4-7": "b-4-7",
    "8-15": "b-8-15",
    "16-23": "b-16-23",
    "24+": "b-24",
  };
  const cls = isOverdue ? (classMap[record.bucket] || "b-overdue") : classMap[record.status];
  return `<span class="badge ${cls}${isOverdue ? " is-overdue" : ""}">${escapeHtml(statusText)}</span>`;
}

function aggregate(records, keyFn) {
  const map = new Map();
  for (const record of records) {
    const key = keyFn(record);
    if (!map.has(key)) {
      map.set(key, {
        key,
        lines: 0,
        skus: new Set(),
        customers: new Set(),
        customerShortNames: new Set(),
        qty: 0,
        maxDays: 0,
      });
    }
    const item = map.get(key);
    item.lines += 1;
    item.skus.add(record.sku);
    item.customers.add(record.customerId);
    if (record.customerShortName) item.customerShortNames.add(record.customerShortName);
    item.qty += Number(record.unshippedQty || 0);
    item.maxDays = Math.max(item.maxDays, record.overdueDays || 0);
  }
  return [...map.values()].map((item) => ({
    ...item,
    skuCount: item.skus.size,
    customerCount: item.customers.size,
    customerShortName: [...item.customerShortNames].join("、"),
  }));
}

function barList(items, valueKey, labelKey, limit = 10) {
  const top = [...items].sort((a, b) => b[valueKey] - a[valueKey]).slice(0, limit);
  const max = Math.max(1, ...top.map((item) => item[valueKey]));
  if (!top.length) return `<div class="empty">当前筛选下暂无数据</div>`;
  return top
    .map((item) => {
      const width = Math.max(3, (item[valueKey] / max) * 100);
      return `
        <div class="bar-row">
          <div class="bar-label" title="${item[labelKey]}">${item[labelKey]}</div>
          <div class="bar-track"><div class="bar-fill" style="width:${width}%"></div></div>
          <div class="bar-value">${fmtNumber(item[valueKey])}</div>
        </div>`;
    })
    .join("");
}

function kpiDrillRecords(kind, records = getEnrichedRecords()) {
  if (kind === "orders") return records;
  return records.filter((record) => record.status === "overdue"
    && (!["noNoticeReady", "noticeReady"].includes(kind) || ["逾已入", "逾拿货"].includes(record.statusText))
    && (kind !== "noNoticeReady" || (!String(record.shipmentNoticeNo || "").trim() && orderKittingStatus(record.orderNo) === "ready"))
    && (kind !== "noticeReady" || (String(record.shipmentNoticeNo || "").trim() && orderKittingStatus(record.orderNo) === "ready"))
    && (kind !== "customers" || Boolean(record.customerId)));
}

function renderKpis() {
  const all = getEnrichedRecords();
  const overdue = kpiDrillRecords("overdue", all);
  const missing = all.filter((r) => r.status === "missing");
  const noNoticeReady = kpiDrillRecords("noNoticeReady", overdue);
  const noticeReady = kpiDrillRecords("noticeReady", overdue);
  const qty = overdue.reduce((sum, r) => sum + Number(r.unshippedQty || 0), 0);
  const customers = new Set(overdue.map((r) => r.customerId).filter(Boolean)).size;

  const rows = [
    ["订单行数 / 动态逾期行数", `${fmtNumber(all.length)} / ${fmtNumber(overdue.length)}`, "", "查看全部订单行或逾期订单行明细", "orders"],
    ["逾期未交数量", fmtNumber(qty), "", "逾期订单明细的未出数量合计", "overdue"],
    ["无出通单且齐套（订单行）", fmtNumber(noNoticeReady.length), "", "仅统计逾已入、逾拿货中，该行出通单号为空且订单齐套状态为齐套的未交完明细行；同一订单多行分别计数，未齐套和未确定不计入。", "noNoticeReady"],
    ["有出通单且齐套（订单行）", fmtNumber(noticeReady.length), "", "仅统计逾已入、逾拿货中，该行出通单号非空且订单齐套状态为齐套的未交完明细行；同一订单多行分别计数，未齐套和未确定不计入。", "noticeReady"],
  ];
  if (canViewCustomerId()) rows.splice(2, 0, ["涉及客户（家）", fmtNumber(customers), "", "存在逾期未交完订单的客户数，按客户编号去重，同一客户只计一次。", "customers"]);
  els.kpis.innerHTML = rows
    .map(([label, value, note, tooltip, key]) => `<article class="kpi kpi-clickable" data-kpi-drill="${key}" role="button" tabindex="0" aria-haspopup="dialog" aria-label="${label} ${value}，查看明细"${tooltip ? ` title="${escapeHtml(tooltip)}"` : ""}><span>${label}</span><strong>${value}</strong>${note ? `<em>${note}</em>` : ""}</article>`)
    .join("");
  els.kpis.querySelectorAll("[data-kpi-drill]").forEach((node) => {
    const open = () => openKpiDrill(node.dataset.kpiDrill);
    node.addEventListener("click", open);
    node.addEventListener("keydown", (event) => {
      if (["Enter", " "].includes(event.key)) { event.preventDefault(); open(); }
    });
  });
}

function openKpiDrill(kind) {
  const titles = { orders: "订单行数 / 动态逾期行数", overdue: "逾期未交数量", customers: "涉及客户", noNoticeReady: "无出通单且齐套（逾已入、逾拿货订单行）", noticeReady: "有出通单且齐套（逾已入、逾拿货订单行）" };
  if (!titles[kind] || !state.user || (kind === "customers" && !canViewCustomerId())) return;
  const snapshot = getEnrichedRecords(), date = state.asOfDate, showCustomer = canViewCustomerId();
  const previousFocus = document.activeElement;
  document.querySelector(".kpi-drill-modal")?.remove();
  const modal = document.createElement("div");
  modal.className = "delay-drill-modal kpi-drill-modal";
  let mode = kind, page = 0, query = "", selectedCustomer = null, customerListState = null;
  const close = () => { modal.remove(); if (previousFocus?.isConnected) previousFocus.focus(); };
  const draw = () => {
    const source = kpiDrillRecords(mode, snapshot);
    const needle = query.trim().toLocaleLowerCase();
    const customerMode = kind === "customers" && !selectedCustomer;
    let entries, rows;
    if (customerMode) {
      entries = summarizeDelayCustomers(source).filter((customer) => !needle
        || `${customer.customerId} ${customer.customerShortName}`.toLocaleLowerCase().includes(needle));
      rows = entries.flatMap((customer) => customer.rows);
    } else {
      rows = (selectedCustomer ? selectedCustomer.rows : source).filter((record) => !needle || [
        record.orderNo, record.lineNo, record.sku, record.spec, record.name, record.workOrderNo,
        ...(showCustomer ? [record.customerId, record.customerShortName] : []),
      ].some((value) => String(value ?? "").toLocaleLowerCase().includes(needle)))
        .slice().sort((a, b) => b.overdueDays - a.overdueDays || String(a.orderNo).localeCompare(String(b.orderNo)));
      entries = rows;
    }
    const pageSize = 100, pages = Math.max(1, Math.ceil(entries.length / pageSize));
    page = Math.min(page, pages - 1);
    const visible = entries.slice(page * pageSize, (page + 1) * pageSize);
    const quantity = rows.reduce((sum, record) => sum + Number(record.unshippedQty || 0), 0);
    const table = customerMode ? delayDrillCustomerTableHtml(visible) : delayDrillOrderTableHtml(visible, showCustomer);
    modal.innerHTML = `<div class="delay-drill-backdrop" data-kpi-close></div><section class="delay-drill-page" role="dialog" aria-modal="true" aria-label="指标明细下钻"><header class="delay-drill-head"><div><span>${date} · 全量数据${selectedCustomer ? ` · ${escapeHtml(selectedCustomer.label)}` : ""}</span><h2>${titles[kind]}</h2></div><div class="delay-drill-head-actions">${selectedCustomer ? '<button type="button" class="delay-drill-back-button" data-kpi-back>返回客户列表</button>' : ""}<button type="button" data-kpi-close title="关闭" aria-label="关闭">×</button></div></header><div class="kpi-drill-toolbar">${kind === "orders" ? `<div class="customer-metric-toggle" role="group" aria-label="订单范围"><button type="button" data-kpi-mode="orders" class="${mode === "orders" ? "active" : ""}" aria-pressed="${mode === "orders"}">全部订单行</button><button type="button" data-kpi-mode="overdue" class="${mode === "overdue" ? "active" : ""}" aria-pressed="${mode === "overdue"}">逾期订单行</button></div>` : ""}<form class="customer-order-search"><input type="search" aria-label="明细搜索" placeholder="${customerMode ? "客户编号 / 简称" : showCustomer ? "订单号 / 客户 / SKU" : "订单号 / SKU"}" value="${escapeHtml(query)}"/><button type="submit">查询</button></form><div class="kpi-drill-counts">${customerMode ? `<span><strong data-kpi-customer-count>${fmtNumber(entries.length)}</strong> 家客户</span>` : ""}<span><strong data-kpi-row-count>${fmtNumber(rows.length)}</strong> 条订单行</span><span>未出数量 <strong data-kpi-quantity>${fmtNumber(quantity)}</strong></span></div></div>${table}<footer class="customer-orders-pagination"><span>${page + 1} / ${pages} 页 · ${fmtNumber(entries.length)} ${customerMode ? "家客户" : "条订单行"}</span><button type="button" data-kpi-prev title="上一页" aria-label="上一页" ${page === 0 ? "disabled" : ""}>‹</button><button type="button" data-kpi-next title="下一页" aria-label="下一页" ${page + 1 === pages ? "disabled" : ""}>›</button></footer></section>`;
    if (!customerMode) {
      const widths = [...(showCustomer ? [105, 120] : []), 160, 60, 110, 160, 180, 100, 100, 90, 85, 110, 110, 150, 120, 65];
      const tableNode = modal.querySelector("table");
      tableNode.style.minWidth = `${widths.reduce((sum, width) => sum + width, 0)}px`;
      tableNode.insertAdjacentHTML("afterbegin", `<colgroup>${widths.map((width) => `<col style="width:${width}px">`).join("")}</colgroup>`);
    }
    modal.querySelectorAll("tbody td").forEach((cell) => { if (!cell.title) cell.title = cell.textContent; });
    if (!entries.length) {
      const tbody = modal.querySelector("tbody");
      tbody.innerHTML = `<tr><td colspan="${modal.querySelectorAll("thead th").length}" class="empty-cell">没有符合条件的${customerMode ? "客户" : "订单明细"}</td></tr>`;
    }
    modal.querySelectorAll("[data-kpi-close]").forEach((node) => node.addEventListener("click", close));
    modal.querySelectorAll("[data-kpi-mode]").forEach((button) => button.addEventListener("click", () => { mode = button.dataset.kpiMode; page = 0; draw(); }));
    modal.querySelector("[data-kpi-prev]").addEventListener("click", () => { page -= 1; draw(); });
    modal.querySelector("[data-kpi-next]").addEventListener("click", () => { page += 1; draw(); });
    modal.querySelector("form").addEventListener("submit", (event) => {
      event.preventDefault(); query = modal.querySelector("input").value; page = 0; draw();
      modal.querySelector("input").focus();
    });
    modal.querySelectorAll("[data-delay-customer]").forEach((button) => button.addEventListener("click", () => {
      customerListState = { query, page };
      selectedCustomer = entries.find((entry) => entry.key === button.dataset.delayCustomer);
      query = ""; page = 0; draw();
    }));
    modal.querySelector("[data-kpi-back]")?.addEventListener("click", () => {
      selectedCustomer = null; query = customerListState.query; page = customerListState.page; draw();
    });
    modal.querySelector("button[data-kpi-close]").focus();
  };
  modal.addEventListener("keydown", (event) => {
    if (event.key === "Escape") close();
    if (event.key === "Tab") {
      const controls = [...modal.querySelectorAll("button:not([disabled]), input")];
      const first = controls[0], last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  document.body.appendChild(modal);
  draw();
}

const ORDER_COLUMN_FILTERS = {
  customerId: { label: "客户", placeholder: "输入客户编号", value: (record) => record.customerId },
  customerShortName: { label: "客户简称", placeholder: "输入客户简称", value: (record) => record.customerShortName },
  orderNo: { label: "订单号", placeholder: "输入订单号", value: (record) => record.orderNo },
  orderDate: { label: "订单日期", placeholder: "输入订单日期", value: (record) => fmtDate(record.orderDate) },
  lineNo: { label: "项次", placeholder: "输入项次", value: (record) => record.lineNo },
  sku: { label: "SKU", placeholder: "输入SKU", value: (record) => record.sku },
  spec: { label: "规格", placeholder: "输入规格", value: (record) => record.spec },
  name: { label: "品名", placeholder: "输入品名", value: (record) => record.name },
  orderQty: { label: "订单数量", placeholder: "输入订单数量", value: (record) => record.orderQty, numeric: true },
  shippedQty: { label: "已出", placeholder: "输入已出数量", value: (record) => record.shippedQty, numeric: true },
  unshippedQty: { label: "未出", placeholder: "输入未出数量", value: (record) => record.unshippedQty, numeric: true },
  availableStock: { label: "可用库存", placeholder: "输入可用库存", value: (record) => record.availableStock, numeric: true },
  customerStock: { label: "客户库存", placeholder: "输入客户库存", value: (record) => record.customerStock, numeric: true },
  statusText: { label: "状态", placeholder: "输入状态", value: (record) => record.statusText },
  overdueDays: { label: "逾期天数", placeholder: "输入逾期天数", value: (record) => record.overdueDays, numeric: true },
  businessDueDate: { label: "业务交期", placeholder: "输入业务交期", value: (record) => fmtDate(record.businessDueDate) },
  planDueDate: { label: "承诺交期", placeholder: "输入承诺交期", value: (record) => fmtDate(normalizedPlanDueDate(record)) },
  workOrderNo: { label: "工单号", placeholder: "输入工单号", value: (record) => record.workOrderNo },
  productionProgress: { label: "生产进度", placeholder: "输入生产进度", value: (record) => record.productionProgress || record.workOrderStatus },
  orderAttribute: { label: "属性", placeholder: "输入属性", value: (record) => record.orderAttribute },
  workOrderQty: { label: "工单数量", placeholder: "输入工单数量", value: (record) => record.workOrderQty, numeric: true },
  reportedQty: { label: "报工", placeholder: "输入报工数", value: (record) => record.reportedQty, numeric: true },
  lastReportedDate: { label: "报工时间", placeholder: "输入报工时间", value: (record) => record.lastReportedDate || "" },
  inspectionQty: { label: "检验", placeholder: "输入检验数", value: (record) => record.inspectionQty, numeric: true },
  lastInspectionDate: { label: "检验时间", placeholder: "输入检验时间", value: (record) => record.lastInspectionDate || "" },
  stockInQty: { label: "入库", placeholder: "输入入库数", value: (record) => record.stockInQty, numeric: true },
  lastStockInDate: { label: "入库时间", placeholder: "输入入库时间", value: (record) => record.lastStockInDate || "" },
  shipmentNoticeNo: { label: "出通单号", placeholder: "输入出通单号", value: (record) => record.shipmentNoticeNo },
  shipmentNoticeDate: { label: "出通单时间", placeholder: "输入出通单时间", value: (record) => record.shipmentNoticeDate },
  kittingStatusText: { label: "齐套状态", placeholder: "输入齐套状态", value: (record) => kittingStatusLabel(orderKittingStatus(record.orderNo)) },
  salesPerson: { label: "业务员", placeholder: "输入业务员", value: (record) => record.salesPerson },
  followerNo: { label: "跟单员编号", placeholder: "输入跟单员编号", value: (record) => record.followerNo },
  followerName: { label: "跟单员", placeholder: "输入跟单员", value: (record) => record.followerName },
  planner: { label: "计划员", placeholder: "输入计划员", value: (record) => record.planner },
};

const EMPTY_COLUMN_FILTER_VALUE = "__EMPTY__";

function getColumnFilter(key) {
  return state.columnFilters[key] || { values: null, mode: "contains", value: "" };
}

function columnFilterHead(key, options = {}) {
  const config = ORDER_COLUMN_FILTERS[key];
  const filter = getColumnFilter(key);
  const isOpen = state.openColumnFilter === key;
  const filterOptions = isOpen ? columnFilterOptions(key) : [];
  const selectedValues = Array.isArray(filter.values) ? filter.values.map(String) : null;
  const selectedSet = new Set(selectedValues || (isOpen ? filterOptions.map((item) => item.key) : []));
  const filterValue = filter.value || "";
  const terms = columnFilterTerms(filterValue);
  const isEmptyMode = filter.mode === "isEmpty" || filter.mode === "notEmpty";
  const hasValueFilter = Boolean(selectedValues);
  const hasConditionFilter = Boolean(terms.length) || isEmptyMode;
  const isFiltered = hasValueFilter || hasConditionFilter;
  const modeLabels = {
    contains: "包含",
    notContains: "不包含",
    isEmpty: "为空",
    notEmpty: "不为空",
  };
  const modeText = modeLabels[filter.mode] || modeLabels.contains;
  const selectedCount = selectedValues ? selectedValues.length : filterOptions.length;
  const filterNotes = [];
  if (hasValueFilter) filterNotes.push(isOpen ? `已选择 ${selectedCount}/${filterOptions.length}` : `已选择 ${selectedCount} 项`);
  if (hasConditionFilter) filterNotes.push(`${modeText}${terms.length ? ` ${terms.join(" / ")}` : ""}`);
  const title = filterNotes.length ? `${config.label}筛选：${filterNotes.join("；")}` : `筛选${config.label}`;
  const total = options.total;
  const totalClass = total !== undefined ? " order-total-head" : "";
  const alignClass = key === "lineNo" || key === "overdueDays" ? " is-centered" : config.numeric ? " is-numeric" : "";
  return `
    <th class="order-filter-head${totalClass}${alignClass} ${isFiltered ? "is-filtered" : ""}" data-column-key="${key}">
      <button class="column-filter-button" type="button" data-column-filter="${key}" aria-expanded="${isOpen ? "true" : "false"}" title="${escapeHtml(title)}">
        <span>${escapeHtml(config.label)}</span><i aria-hidden="true"></i>
      </button>
      ${total !== undefined ? `<strong>${fmtNumber(total)}</strong>` : ""}
      ${isOpen ? `
        <div class="column-filter-popover excel-filter-popover" data-column-filter-panel="${key}">
          <input class="excel-filter-search" data-column-filter-search="${key}" type="search" placeholder="${escapeHtml(`搜索${config.label}`)}" />
          <div class="excel-filter-tools">
            <button data-column-filter-select-all="${key}" type="button">全选</button>
            <button data-column-filter-select-none="${key}" type="button">清空</button>
          </div>
          <div class="excel-filter-list" data-column-filter-list="${key}">
            ${filterOptions.length ? filterOptions
              .map((item) => `
                <label class="excel-filter-option" data-column-filter-option-row="${key}" data-search-text="${escapeHtml(item.label.toLowerCase())}">
                  <input data-column-filter-option="${key}" type="checkbox" value="${escapeHtml(item.key)}" ${selectedSet.has(item.key) ? "checked" : ""} />
                  <span title="${escapeHtml(item.label)}">${escapeHtml(item.label)}</span>
                  <em>${fmtNumber(item.count)}</em>
                </label>`)
              .join("") : `<div class="excel-filter-empty">无可筛选值</div>`}
          </div>
          <div class="excel-condition-filter">
            <label>
              条件
              <select data-column-filter-mode="${key}">
                <option value="contains" ${filter.mode === "contains" ? "selected" : ""}>包含</option>
                <option value="notContains" ${filter.mode === "notContains" ? "selected" : ""}>不包含</option>
                <option value="isEmpty" ${filter.mode === "isEmpty" ? "selected" : ""}>为空</option>
                <option value="notEmpty" ${filter.mode === "notEmpty" ? "selected" : ""}>不为空</option>
              </select>
            </label>
            <label>
              内容
              <input data-column-filter-value="${key}" type="search" value="${escapeHtml(filterValue)}" placeholder="${escapeHtml(`${config.placeholder}，空格/逗号分隔`)}" />
            </label>
          </div>
          <div class="column-filter-actions">
            <button data-column-filter-apply="${key}" type="button">确定</button>
            <button data-column-filter-clear="${key}" type="button">清除筛选</button>
          </div>
        </div>` : ""}
    </th>`;
}

function columnFilterTerms(value) {
  return String(value || "")
    .split(/[\s,，、;；]+/)
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean);
}

function columnFilterText(record, key) {
  const config = ORDER_COLUMN_FILTERS[key];
  const value = config?.value(record);
  if (config?.numeric) {
    return [String(value ?? ""), fmtNumber(value)].join(" ").toLowerCase();
  }
  return String(value ?? "").toLowerCase();
}

function columnFilterDisplayValue(record, key) {
  const config = ORDER_COLUMN_FILTERS[key];
  const value = config?.value(record);
  if (config?.numeric) return fmtNumber(value);
  return compactText(value);
}

function columnFilterValueKey(value) {
  return compactText(value) || EMPTY_COLUMN_FILTER_VALUE;
}

function columnFilterValueLabel(value) {
  return value === EMPTY_COLUMN_FILTER_VALUE ? "(空白)" : value;
}

function columnFilterOptions(key) {
  const records = getEnrichedRecords();
  const cacheKey = `${key}|${globalFilterSignature()}|${filterStateSignature(key)}|${state.asOfDate}`;
  const cached = state.columnFilterOptionCache.get(cacheKey);
  if (cached) return cached;
  const values = new Map();
  const filters = activeColumnFilters(key);
  for (const record of records) {
    if (!matchesGlobalFilters(record) || !matchesColumnFilters(record, key, filters)) continue;
    const displayValue = columnFilterDisplayValue(record, key);
    const valueKey = columnFilterValueKey(displayValue);
    if (!values.has(valueKey)) {
      values.set(valueKey, { key: valueKey, label: columnFilterValueLabel(valueKey), count: 0 });
    }
    values.get(valueKey).count += 1;
  }
  const result = [...values.values()].sort((a, b) => columnValueCollator.compare(a.label, b.label));
  if (state.columnFilterOptionCache.size > 40) state.columnFilterOptionCache.clear();
  state.columnFilterOptionCache.set(cacheKey, result);
  return result;
}

function globalFilterSignature() {
  return [
    state.status,
    state.bucket,
    state.planner,
    state.salesPerson,
    state.productionProgress,
  ].join("\u0001");
}

function filterStateSignature(ignoreKey = "") {
  const entries = Object.entries(state.columnFilters)
    .filter(([key]) => key !== ignoreKey)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, filter]) => [
      key,
      filter.mode || "",
      filter.value || "",
      Array.isArray(filter.values) ? filter.values.map(String) : null,
    ]);
  return JSON.stringify(entries);
}

function activeColumnFilters(ignoreKey = "") {
  const signature = filterStateSignature(ignoreKey);
  const cached = state.compiledColumnFilterCache.get(signature);
  if (cached) return cached;
  const compiled = Object.entries(state.columnFilters)
    .filter(([key]) => key !== ignoreKey)
    .map(([key, filter]) => ({
      key,
      mode: filter.mode || "contains",
      terms: columnFilterTerms(filter.value),
      values: Array.isArray(filter.values) ? new Set(filter.values.map(String)) : null,
    }));
  if (state.compiledColumnFilterCache.size > 40) state.compiledColumnFilterCache.clear();
  state.compiledColumnFilterCache.set(signature, compiled);
  return compiled;
}

function matchesColumnFilters(record, ignoreKey = "", filters = activeColumnFilters(ignoreKey)) {
  for (const filter of filters) {
    if (filter.values) {
      const valueKey = columnFilterValueKey(columnFilterDisplayValue(record, filter.key));
      if (!filter.values.has(valueKey)) return false;
    }
    const text = columnFilterText(record, filter.key);
    const hasText = Boolean(text.trim());
    if (filter.mode === "isEmpty") {
      if (hasText) return false;
      continue;
    }
    if (filter.mode === "notEmpty") {
      if (!hasText) return false;
      continue;
    }
    if (!filter.terms.length) continue;
    const matched = filter.terms.some((term) => text.includes(term));
    if (filter.mode === "notContains" ? matched : !matched) return false;
  }
  return true;
}

function sortedOrderRows() {
  return [...state.filtered].sort((a, b) => {
    if (a.status === "overdue" && b.status !== "overdue") return -1;
    if (b.status === "overdue" && a.status !== "overdue") return 1;
    return (b.overdueDays || 0) - (a.overdueDays || 0) || Number(b.unshippedQty || 0) - Number(a.unshippedQty || 0);
  });
}

function orderExportColumns(includePeople = state.showOrderPeopleColumns) {
  const columns = [];
  if (canViewCustomerId()) {
    columns.push(
      { label: "客户", value: (record) => record.customerId },
      { label: "客户简称", value: (record) => record.customerShortName || "" },
    );
  }
  columns.push(
    { label: "订单号", value: (record) => record.orderNo },
    { label: "订单日期", value: (record) => fmtDate(record.orderDate) },
    { label: "项次", value: (record) => record.lineNo ?? "" },
    { label: "状态", value: (record) => record.statusText },
    { label: "逾期天数", value: (record) => (record.status === "overdue" ? Number(record.overdueDays || 0) : ""), numeric: true },
    { label: "业务交期", value: (record) => fmtDate(record.businessDueDate) },
    { label: "承诺交期", value: (record) => fmtDate(normalizedPlanDueDate(record)) },
    { label: "SKU", value: (record) => record.sku },
    { label: "规格", value: (record) => record.spec },
    { label: "品名", value: (record) => record.name },
    { label: "订单数量", value: (record) => Number(record.orderQty || 0), numeric: true },
    { label: "已出", value: (record) => Number(record.shippedQty || 0), numeric: true },
    { label: "未出", value: (record) => Number(record.unshippedQty || 0), numeric: true },
    { label: "可用库存", value: (record) => Number(record.availableStock || 0), numeric: true },
    { label: "客户库存", value: (record) => Number(record.customerStock || 0), numeric: true },
    { label: "工单号", value: (record) => record.workOrderNo || "" },
    { label: "生产进度", value: (record) => record.productionProgress || record.workOrderStatus || "" },
    { label: "属性", value: (record) => record.orderAttribute || "" },
    { label: "工单数量", value: (record) => Number(record.workOrderQty || 0), numeric: true },
    { label: "报工", value: (record) => Number(record.reportedQty || 0), numeric: true },
    { label: "报工时间", value: (record) => record.lastReportedDate || "" },
    { label: "检验", value: (record) => Number(record.inspectionQty || 0), numeric: true },
    { label: "检验时间", value: (record) => record.lastInspectionDate || "" },
    { label: "入库", value: (record) => Number(record.stockInQty || 0), numeric: true },
    { label: "入库时间", value: (record) => record.lastStockInDate || "" },
    { label: "出通单号", value: (record) => record.shipmentNoticeNo || "" },
    { label: "出通单时间", value: (record) => record.shipmentNoticeDate || "" },
    { label: "齐套状态", value: (record) => kittingStatusLabel(orderKittingStatus(record.orderNo)) },
  );
  if (includePeople) {
    columns.push(
      { label: "业务员", value: (record) => record.salesPerson || "" },
      { label: "跟单员编号", value: (record) => record.followerNo || "" },
      { label: "跟单员", value: (record) => record.followerName || "" },
      { label: "计划员", value: (record) => record.planner || "" },
    );
  }
  return columns;
}

function xmlEscape(value) {
  return String(value ?? "")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function xlsxColumnName(index) {
  let name = "";
  let current = index + 1;
  while (current > 0) {
    const modulo = (current - 1) % 26;
    name = String.fromCharCode(65 + modulo) + name;
    current = Math.floor((current - modulo) / 26);
  }
  return name;
}

function xlsxCell(value, rowIndex, columnIndex, numeric = false) {
  const ref = `${xlsxColumnName(columnIndex)}${rowIndex + 1}`;
  if (numeric && value !== "" && Number.isFinite(Number(value))) {
    return `<c r="${ref}"><v>${Number(value)}</v></c>`;
  }
  const text = xmlEscape(value);
  return `<c r="${ref}" t="inlineStr"><is><t>${text}</t></is></c>`;
}

function waitForPaint() {
  return new Promise((resolve) => window.requestAnimationFrame(() => resolve()));
}

async function xlsxSheetXml(headers, rows, columns, onProgress) {
  const headerXml = `<row r="1">${headers.map((header, index) => xlsxCell(header, 0, index)).join("")}</row>`;
  const rowChunks = [];
  for (let rowOffset = 0; rowOffset < rows.length; rowOffset += 1) {
    const record = rows[rowOffset];
    const rowIndex = rowOffset + 1;
    const cells = columns
      .map((column, columnIndex) => xlsxCell(column.value(record), rowIndex, columnIndex, column.numeric))
      .join("");
    rowChunks.push(`<row r="${rowIndex + 1}">${cells}</row>`);
    if (rowOffset > 0 && rowOffset % 250 === 0) {
      onProgress?.(rowOffset, rows.length);
      await waitForPaint();
    }
  }
  onProgress?.(rows.length, rows.length);
  const rowsXml = rowChunks.join("");
  const dimensionRef = `A1:${xlsxColumnName(Math.max(0, headers.length - 1))}${Math.max(1, rows.length + 1)}`;
  const columnWidths = headers
    .map((header, index) => `<col min="${index + 1}" max="${index + 1}" width="${Math.min(36, Math.max(10, String(header).length + 6))}" customWidth="1"/>`)
    .join("");
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <dimension ref="${dimensionRef}"/>
  <sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
  <cols>${columnWidths}</cols>
  <sheetData>${headerXml}${rowsXml}</sheetData>
  <autoFilter ref="${dimensionRef}"/>
</worksheet>`;
}

async function exportOrdersExcel(onProgress) {
  if (!isAdmin()) return;
  if (!window.JSZip) {
    window.alert("Excel 导出模块未加载，请刷新页面后重试。");
    return;
  }
  const rows = sortedOrderRows();
  if (!rows.length) {
    window.alert("当前筛选没有可导出的订单。");
    return;
  }
  const columns = orderExportColumns();
  const headers = columns.map((column) => column.label);
  const zip = new window.JSZip();
  zip.file("[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>`);
  zip.folder("_rels").file(".rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`);
  zip.folder("xl").file("workbook.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets><sheet name="订单综合查询" sheetId="1" r:id="rId1"/></sheets>
</workbook>`);
  zip.folder("xl").folder("_rels").file("workbook.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
    </Relationships>`);
  const sheetXml = await xlsxSheetXml(headers, rows, columns, onProgress);
  zip.folder("xl").folder("worksheets").file("sheet1.xml", sheetXml);
  onProgress?.(rows.length, rows.length, "打包中");
  const blob = await zip.generateAsync({
    type: "blob",
    compression: "STORE",
    mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  link.href = url;
  link.download = `订单综合查询_${state.asOfDate}_${rows.length}行.xlsx`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function renderOrders() {
  const token = ++state.ordersRenderToken;
  const showCustomer = canViewCustomerId();
  const showPeople = state.showOrderPeopleColumns;
  const orderCols = showCustomer
    ? '<col style="width:92px"><col style="width:136px"><col style="width:150px"><col style="width:110px"><col style="width:62px">'
    : '<col style="width:150px"><col style="width:110px"><col style="width:62px">';
  const orderHead = showCustomer
    ? `${columnFilterHead("customerId")}${columnFilterHead("customerShortName")}${columnFilterHead("orderNo")}${columnFilterHead("orderDate")}${columnFilterHead("lineNo")}`
    : `${columnFilterHead("orderNo")}${columnFilterHead("orderDate")}${columnFilterHead("lineNo")}`;
  const statusCols = '<col style="width:78px"><col style="width:76px"><col style="width:110px"><col style="width:92px">';
  const statusHead = `${columnFilterHead("statusText")}${columnFilterHead("overdueDays")}${columnFilterHead("businessDueDate")}${columnFilterHead("planDueDate")}`;
  const productCols = '<col style="width:110px"><col style="width:162px"><col style="width:120px">';
  const productHead = `${columnFilterHead("sku")}${columnFilterHead("spec")}${columnFilterHead("name")}`;
  const detailCols = [
    '<col style="width:88px">',
    '<col style="width:82px">',
    '<col style="width:82px">',
    '<col style="width:100px">',
    '<col style="width:100px">',
    '<col style="width:130px">',
    '<col style="width:82px">',
    '<col style="width:130px">',
    '<col style="width:82px">',
    '<col style="width:84px">',
    '<col style="width:120px">',
    '<col style="width:84px">',
    '<col style="width:120px">',
    '<col style="width:84px">',
    '<col style="width:120px">',
  ].join("");
  const shipmentCols = '<col style="width:136px"><col style="width:104px"><col style="width:100px">';
  const shipmentHead = `${columnFilterHead("shipmentNoticeNo")}${columnFilterHead("shipmentNoticeDate")}${columnFilterHead("kittingStatusText")}`;
  const peopleCols = showPeople ? '<col style="width:86px"><col style="width:92px"><col style="width:86px"><col style="width:90px">' : "";
  const peopleHead = showPeople ? `${columnFilterHead("salesPerson")}${columnFilterHead("followerNo")}${columnFilterHead("followerName")}${columnFilterHead("planner")}` : "";
  const peopleToggleLabel = showPeople ? "-" : "+";
  const peopleToggleTitle = showPeople ? "隐藏人员列" : "显示人员列";
  const rows = sortedOrderRows();
  const orderTotals = rows.reduce(
    (totals, record) => ({
      orderQty: totals.orderQty + Number(record.orderQty || 0),
      shippedQty: totals.shippedQty + Number(record.shippedQty || 0),
      unshippedQty: totals.unshippedQty + Number(record.unshippedQty || 0),
      availableStock: totals.availableStock + Number(record.availableStock || 0),
      customerStock: totals.customerStock + Number(record.customerStock || 0),
    }),
    { orderQty: 0, shippedQty: 0, unshippedQty: 0, availableStock: 0, customerStock: 0 },
  );

  els.orders.innerHTML = `
    <div class="section-head">
      <div>
        <h2>订单综合查询</h2>
        <span class="hint" id="orderRenderHint">准备显示全部 ${fmtNumber(rows.length)} 行；排序优先逾期天数和未交数量</span>
      </div>
      ${isAdmin() ? '<button id="exportOrdersButton" class="export-orders-button" type="button">导出Excel</button>' : ''}
    </div>
    <div class="table-wrap orders-scroll" id="ordersScroll">
      <table class="orders-table ${showPeople ? "people-open" : "people-collapsed"}">
        <colgroup>
          ${orderCols}${statusCols}${productCols}
          ${detailCols}${shipmentCols}${peopleCols}<col style="width:44px">
        </colgroup>
        <thead>
          <tr>
            ${orderHead}${statusHead}${productHead}
            ${columnFilterHead("orderQty", { total: orderTotals.orderQty })}${columnFilterHead("shippedQty", { total: orderTotals.shippedQty })}${columnFilterHead("unshippedQty", { total: orderTotals.unshippedQty })}${columnFilterHead("availableStock", { total: orderTotals.availableStock })}${columnFilterHead("customerStock", { total: orderTotals.customerStock })}
            ${columnFilterHead("workOrderNo")}${columnFilterHead("productionProgress")}${columnFilterHead("orderAttribute")}${columnFilterHead("workOrderQty")}${columnFilterHead("reportedQty")}${columnFilterHead("lastReportedDate")}${columnFilterHead("inspectionQty")}${columnFilterHead("lastInspectionDate")}${columnFilterHead("stockInQty")}${columnFilterHead("lastStockInDate")}${shipmentHead}${peopleHead}
            <th class="orders-people-toggle-head"><button id="ordersPeopleToggle" class="orders-people-toggle" type="button" aria-expanded="${showPeople ? "true" : "false"}" title="${peopleToggleTitle}">${peopleToggleLabel}</button></th>
          </tr>
        </thead>
        <tbody id="ordersBody"></tbody>
      </table>
    </div>`;
  renderVirtualOrderRows(rows, token);
  const renderOrdersWithScroll = (callback) => {
    const previousScroll = els.orders.querySelector("#ordersScroll");
    const previousScrollLeft = previousScroll?.scrollLeft || 0;
    const previousScrollTop = previousScroll?.scrollTop || 0;
    callback();
    renderOrders();
    const nextScroll = els.orders.querySelector("#ordersScroll");
    if (!nextScroll) return;
    nextScroll.scrollLeft = previousScrollLeft;
    nextScroll.scrollTop = previousScrollTop;
    requestAnimationFrame(() => {
      nextScroll.scrollLeft = previousScrollLeft;
      nextScroll.scrollTop = previousScrollTop;
    });
  };
  els.orders.querySelectorAll("[data-column-filter]").forEach((button) => {
    button.addEventListener("click", () => {
      const key = button.dataset.columnFilter;
      renderOrdersWithScroll(() => {
        state.openColumnFilter = state.openColumnFilter === key ? "" : key;
      });
      els.orders.querySelector(`[data-column-filter-search="${key}"]`)?.focus();
    });
  });
  els.orders.querySelectorAll("[data-column-filter-apply]").forEach((button) => {
    button.addEventListener("click", () => {
      const key = button.dataset.columnFilterApply;
      const options = [...els.orders.querySelectorAll(`[data-column-filter-option="${key}"]`)];
      const search = els.orders.querySelector(`[data-column-filter-search="${key}"]`)?.value.trim() || "";
      const selected = options.filter((option) => option.checked
        && (!search || !option.closest("[data-column-filter-option-row]")?.hidden)).map((option) => option.value);
      const mode = els.orders.querySelector(`[data-column-filter-mode="${key}"]`)?.value || "contains";
      const value = els.orders.querySelector(`[data-column-filter-value="${key}"]`)?.value || "";
      const hasCondition = value.trim() || mode === "isEmpty" || mode === "notEmpty";
      const nextFilter = {};
      if (selected.length !== options.length || (search && !selected.length)) {
        nextFilter.values = selected;
      }
      if (hasCondition) {
        nextFilter.mode = mode;
        nextFilter.value = value;
      }
      if (nextFilter.values || hasCondition) {
        state.columnFilters[key] = nextFilter;
      } else {
        delete state.columnFilters[key];
      }
      state.openColumnFilter = "";
      state.selectedCustomer = "";
      render();
    });
  });
  els.orders.querySelectorAll("[data-column-filter-clear]").forEach((button) => {
    button.addEventListener("click", () => {
      const key = button.dataset.columnFilterClear;
      delete state.columnFilters[key];
      state.openColumnFilter = "";
      state.selectedCustomer = "";
      render();
    });
  });
  els.orders.querySelectorAll("[data-column-filter-select-all], [data-column-filter-select-none]").forEach((button) => {
    button.addEventListener("click", () => {
      const key = button.dataset.columnFilterSelectAll || button.dataset.columnFilterSelectNone;
      const checked = Boolean(button.dataset.columnFilterSelectAll);
      els.orders.querySelectorAll(`[data-column-filter-option-row="${key}"]`).forEach((row) => {
        if (row.hidden) return;
        const checkbox = row.querySelector(`[data-column-filter-option="${key}"]`);
        if (checkbox) checkbox.checked = checked;
      });
    });
  });
  els.orders.querySelectorAll("[data-column-filter-search]").forEach((input) => {
    let selectionBeforeSearch = null;
    input.addEventListener("input", () => {
      const key = input.dataset.columnFilterSearch;
      const term = input.value.trim().toLowerCase();
      const options = [...els.orders.querySelectorAll(`[data-column-filter-option="${key}"]`)];
      if (term && !selectionBeforeSearch) {
        selectionBeforeSearch = new Map(options.map((option) => [option.value, option.checked]));
      }
      els.orders.querySelectorAll(`[data-column-filter-option-row="${key}"]`).forEach((row) => {
        row.hidden = Boolean(term) && !row.dataset.searchText.includes(term);
        const checkbox = row.querySelector(`[data-column-filter-option="${key}"]`);
        if (checkbox && term) checkbox.checked = !row.hidden;
        else if (checkbox && selectionBeforeSearch) checkbox.checked = selectionBeforeSearch.get(checkbox.value) || false;
      });
      if (!term) selectionBeforeSearch = null;
    });
    input.addEventListener("keydown", (event) => {
      if (event.key !== "Enter") return;
      event.preventDefault();
      const key = input.dataset.columnFilterSearch;
      els.orders.querySelector(`[data-column-filter-apply="${key}"]`)?.click();
    });
  });
  els.orders.querySelectorAll("[data-column-filter-value]").forEach((input) => {
    input.addEventListener("keydown", (event) => {
      if (event.key !== "Enter") return;
      event.preventDefault();
      const key = input.dataset.columnFilterValue;
      els.orders.querySelector(`[data-column-filter-apply="${key}"]`)?.click();
    });
  });
  els.orders.querySelector("#exportOrdersButton")?.addEventListener("click", async () => {
    const button = els.orders.querySelector("#exportOrdersButton");
    button.disabled = true;
    button.textContent = "准备导出...";
    try {
      await exportOrdersExcel((done, total, stage = "生成中") => {
        const percent = total ? Math.min(100, Math.round((done / total) * 100)) : 0;
        button.textContent = `${stage}${percent}%`;
      });
      button.textContent = "已下载";
      window.setTimeout(() => {
        if (button.isConnected && !button.disabled) button.textContent = "导出Excel";
      }, 1200);
    } catch (error) {
      window.alert(error.message || "导出失败");
      button.textContent = "导出Excel";
    } finally {
      button.disabled = false;
    }
  });
  els.orders.querySelector("#ordersPeopleToggle")?.addEventListener("click", () => {
    renderOrdersWithScroll(() => {
      state.showOrderPeopleColumns = !state.showOrderPeopleColumns;
      if (!state.showOrderPeopleColumns) {
        ["salesPerson", "followerNo", "followerName", "planner"].forEach((key) => delete state.columnFilters[key]);
        if (["salesPerson", "followerNo", "followerName", "planner"].includes(state.openColumnFilter)) state.openColumnFilter = "";
      }
    });
  });
}

function orderRowHtml(r) {
  const kittingStatus = orderKittingStatus(r.orderNo);
  const orderCells = canViewCustomerId()
    ? `<td>${r.customerId}</td><td>${r.customerShortName || ""}</td><td>${r.orderNo}</td><td>${escapeHtml(fmtDate(r.orderDate))}</td><td class="line-cell">${r.lineNo ?? ""}</td>`
    : `<td>${r.orderNo}</td><td>${escapeHtml(fmtDate(r.orderDate))}</td><td class="line-cell">${r.lineNo ?? ""}</td>`;
  const peopleCells = state.showOrderPeopleColumns
    ? `<td>${r.salesPerson || ""}</td><td>${r.followerNo || ""}</td><td>${r.followerName || ""}</td><td>${r.planner}</td>`
    : "";
  return `
    <tr>
      ${orderCells}
      <td class="status-cell">${badge(r)}</td>
      <td class="center-cell">${r.status === "overdue" ? fmtNumber(r.overdueDays) : ""}</td>
      <td>${fmtDate(r.businessDueDate)}</td>
      <td>${fmtDate(normalizedPlanDueDate(r))}</td>
      <td>${r.sku}</td>
      <td title="${escapeHtml(r.spec)}">${r.spec}</td>
      <td class="name" title="${escapeHtml(r.name)}">${r.name}</td>
      <td class="num">${fmtNumber(r.orderQty)}</td>
      <td class="num">${fmtNumber(r.shippedQty)}</td>
      <td class="num">${fmtNumber(r.unshippedQty)}</td>
      <td class="num">${r.availableStock ? fmtNumber(r.availableStock) : ""}</td>
      <td class="num">${r.customerStock ? fmtNumber(r.customerStock) : ""}</td>
      <td>${r.workOrderNo || ""}</td>
      <td>${r.productionProgress || r.workOrderStatus}</td>
      <td>${r.orderAttribute || ""}</td>
      <td class="num">${fmtNumber(r.workOrderQty)}</td>
      <td class="num production-metric-start">${fmtNumber(r.reportedQty)}</td>
      <td class="production-date-cell">${r.lastReportedDate || ""}</td>
      <td class="num production-metric-start">${fmtNumber(r.inspectionQty)}</td>
      <td class="production-date-cell">${r.lastInspectionDate || ""}</td>
      <td class="num production-metric-start">${fmtNumber(r.stockInQty)}</td>
      <td class="production-date-cell">${r.lastStockInDate || ""}</td>
      <td>${escapeHtml(r.shipmentNoticeNo || "")}</td>
      <td>${escapeHtml(r.shipmentNoticeDate || "")}</td>
      <td class="center-cell"><span class="kitting-badge ${kittingBadgeClass(kittingStatus)}">${kittingStatusLabel(kittingStatus)}</span></td>
      ${peopleCells}
      <td class="orders-people-toggle-cell"></td>
    </tr>`;
}

function renderVirtualOrderRows(rows, token) {
  const scroll = els.orders.querySelector("#ordersScroll");
  const body = els.orders.querySelector("#ordersBody");
  const hint = els.orders.querySelector("#orderRenderHint");
  const headerCellCount = els.orders.querySelector("table thead tr")?.children?.length;
  const colSpan = Number.isInteger(headerCellCount) ? headerCellCount : (canViewCustomerId() ? 31 : 29) + (state.showOrderPeopleColumns ? 4 : 0);
  const buffer = 10;
  let ticking = false;
  let previousStart = -1, previousEnd = -1;

  function spacer(height) {
    return height > 0 ? `<tr class="virtual-spacer"><td colspan="${colSpan}" style="height:${height}px"></td></tr>` : "";
  }

  function paint() {
    if (token !== state.ordersRenderToken || !body || !scroll) return;
    const viewport = scroll.clientHeight || 620;
    const start = Math.max(0, Math.floor(scroll.scrollTop / ORDER_ROW_HEIGHT) - buffer);
    const count = Math.ceil(viewport / ORDER_ROW_HEIGHT) + buffer * 2;
    const end = Math.min(rows.length, start + count);
    if (start === previousStart && end === previousEnd) return;
    previousStart = start;
    previousEnd = end;
    const visibleRows = rows.slice(start, end).map(orderRowHtml).join("");
    body.innerHTML = `${spacer(start * ORDER_ROW_HEIGHT)}${visibleRows}${spacer((rows.length - end) * ORDER_ROW_HEIGHT)}`;
    if (hint) {
      hint.textContent = rows.length
        ? `显示全部 ${fmtNumber(rows.length)} 行；当前渲染 ${fmtNumber(start + 1)}-${fmtNumber(end)} 行`
        : "当前筛选无订单";
    }
  }

  function requestPaint() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(() => {
      ticking = false;
      paint();
    });
  }

  scroll?.addEventListener("scroll", requestPaint, { passive: true });
  paint();
}

function renderCustomers() {
  if (!canViewCustomerId()) {
    els.customers.innerHTML = `<div class="empty">当前账号无客户编号查看权限。</div>`;
    return;
  }
  const overdue = state.filtered.filter((r) => r.status === "overdue");
  const rows = aggregate(overdue, (r) => r.customerId || "客户缺失").sort((a, b) => b.qty - a.qty);
  const selectedAgg = rows.find((r) => r.key === state.selectedCustomer);
  if (state.selectedCustomer && !selectedAgg) state.selectedCustomer = "";

  if (!state.selectedCustomer) {
    els.customers.innerHTML = `
      <div class="section-head">
        <h2>客户逾期分析</h2>
        <span class="hint">点击客户编号进入下一级延期订单明细</span>
      </div>
      ${bucketStrip(overdue)}
      <div class="customer-page">
        <div class="block">
          <div class="customer-block-head">
            <h3>客户逾期汇总</h3>
            <span>按客户编号汇总，点击任一客户进入下一级订单明细</span>
          </div>
          ${customerList(rows)}
        </div>
      </div>`;

    bindCustomerPanelEvents();
    return;
  }

  const selectedRows = overdue
    .filter((r) => (r.customerId || "客户缺失") === state.selectedCustomer)
    .sort((a, b) => (b.overdueDays || 0) - (a.overdueDays || 0) || Number(b.unshippedQty || 0) - Number(a.unshippedQty || 0));
  els.customers.innerHTML = `
    <div class="section-head">
      <div>
        <h2>客户逾期明细</h2>
        <span class="hint">上一级：客户逾期汇总 / 当前客户：${state.selectedCustomer}${selectedAgg.customerShortName ? ` / ${selectedAgg.customerShortName}` : ""}</span>
      </div>
      <button class="back-button" type="button" data-back-customer>返回上一级</button>
    </div>
    <div class="drill-page">
      <div class="drill-summary">
        <span><strong>${fmtNumber(selectedAgg.lines)}</strong><em>逾期订单行数</em></span>
        <span><strong>${fmtNumber(selectedAgg.skuCount)}</strong><em>逾期SKU数</em></span>
        <span><strong>${fmtNumber(selectedAgg.qty)}</strong><em>逾期未交数量</em></span>
        <span><strong>${fmtNumber(selectedAgg.maxDays)}天</strong><em>最长逾期天数</em></span>
        <span><strong>${fmtNumber(selectedAgg.customerCount)}</strong><em>逾期客户数</em></span>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th style="width:19%">订单号</th><th style="width:7%">项次</th><th style="width:14%">SKU</th><th style="width:16%">规格</th><th class="num" style="width:10%">未交</th><th style="width:11%">业务交期</th><th class="num" style="width:9%">逾期</th><th style="width:14%">进度/库存</th></tr></thead>
          <tbody>
            ${selectedRows
              .map((r) => `<tr><td>${r.orderNo}</td><td>${r.lineNo ?? ""}</td><td>${r.sku}</td><td class="name">${r.spec}</td><td class="num">${fmtNumber(r.unshippedQty)}</td><td>${fmtDate(r.businessDueDate)}</td><td class="num">${fmtNumber(r.overdueDays)}天</td><td class="name">${r.canShipFromStock ? `可用库存 ${fmtNumber(r.availableStock)}` : (r.productionProgress || r.workOrderStatus || "")}</td></tr>`)
              .join("")}
          </tbody>
        </table>
      </div>
    </div>`;

  bindCustomerPanelEvents();
}

function bindCustomerPanelEvents() {
  els.customers.querySelectorAll("[data-customer]").forEach((button) => {
    button.addEventListener("click", () => {
      state.selectedCustomer = button.dataset.customer;
      renderCustomers();
    });
  });
  els.customers.querySelector("[data-back-customer]")?.addEventListener("click", () => {
    state.selectedCustomer = "";
    renderCustomers();
  });
  els.customers.querySelectorAll("[data-bucket-pick]").forEach((button) => {
    button.addEventListener("click", () => {
      state.bucket = button.dataset.bucketPick;
      state.status = "overdue";
      state.selectedCustomer = "";
      els.bucket.value = state.bucket;
      els.status.value = "overdue";
      render();
    });
  });
}

function bucketStrip(records) {
  const buckets = [
    ["1-3", "1～3天", "绿色", "关注"],
    ["4-7", "4～7天", "黄色", "催促"],
    ["8-15", "8～15天", "橙色", "升级"],
    ["16-23", "16～23天", "红色", "重点"],
    ["24+", "24天以上", "深红", "严重"],
  ];
  return `
    <div class="bucket-strip">
      ${buckets
        .map(([key, range, colorName, level]) => {
          const items = records.filter((record) => record.bucket === key);
          const qty = items.reduce((sum, record) => sum + Number(record.unshippedQty || 0), 0);
          return `
            <button class="bucket-card bline-${key.replace("+", "plus")}" type="button" data-bucket-pick="${key}">
              <span>${range}</span>
              <strong>${level}</strong>
              <em>${colorName}标注</em>
              <b>${fmtNumber(items.length)} 行 / ${fmtNumber(qty)}</b>
            </button>`;
        })
        .join("")}
    </div>`;
}

function customerList(rows) {
  const max = Math.max(1, ...rows.map((item) => item.qty));
  if (!rows.length) return `<div class="empty">当前筛选下暂无逾期客户</div>`;
  return `
    <div class="customer-list">
      <div class="customer-list-head">
        <span>客户编号 / 简称</span>
        <span>未交占比</span>
        <span>逾期未交数量</span>
        <span>下钻</span>
      </div>
      ${rows
    .map((item) => {
      const width = Math.max(3, (item.qty / max) * 100);
      return `
        <button class="customer-row" data-customer="${item.key}" type="button">
          <span class="customer-main">
            <strong title="${item.customerShortName || item.key}">${item.key}${item.customerShortName ? ` · ${item.customerShortName}` : ""}</strong>
            <em>${fmtNumber(item.lines)} 行 / ${fmtNumber(item.skuCount)} SKU / 最长 ${fmtNumber(item.maxDays)} 天</em>
          </span>
          <span class="customer-bar"><i style="width:${width}%"></i></span>
          <span class="customer-qty">${fmtNumber(item.qty)}</span>
          <span class="customer-enter">进入明细</span>
        </button>`;
    })
    .join("")}
    </div>`;
}

function renderProducts() {
  const overdue = state.filtered.filter((r) => r.status === "overdue");
  const showCustomer = canViewCustomerId();
  const rows = aggregate(overdue, (r) => `${r.category4 || "未分类"} / ${r.spec || "无规格"} / ${r.sku || "无SKU"}`)
    .sort((a, b) => b.qty - a.qty)
    .slice(0, 80);
  const totalQty = overdue.reduce((sum, r) => sum + Number(r.unshippedQty || 0), 0) || 1;
  els.products.innerHTML = `
    <div class="section-head">
      <h2>产品逾期分析</h2>
      <span class="hint">按产品分类四 / 规格 / SKU 下钻雏形，默认按逾期未交数量降序</span>
    </div>
    <div class="analysis-grid">
      <div class="block">
        <h3>产品逾期数量 TOP10</h3>
        ${barList(rows, "qty", "key")}
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th style="width:${showCustomer ? "42" : "50"}%">产品维度</th><th class="num" style="width:11%">订单行</th>${showCustomer ? '<th class="num" style="width:11%">客户数</th>' : ""}<th class="num" style="width:15%">未交数量</th><th class="num" style="width:11%">占比</th><th class="num" style="width:10%">最长</th></tr></thead>
          <tbody>
            ${rows
              .map((r) => `<tr><td class="name">${r.key}</td><td class="num">${fmtNumber(r.lines)}</td>${showCustomer ? `<td class="num">${fmtNumber(r.customerCount)}</td>` : ""}<td class="num">${fmtNumber(r.qty)}</td><td class="num">${((r.qty / totalQty) * 100).toFixed(1)}%</td><td class="num">${fmtNumber(r.maxDays)}天</td></tr>`)
              .join("")}
          </tbody>
        </table>
      </div>
    </div>`;
}

function renderAlerts() {
  const all = getEnrichedRecords();
  const missingDue = all.filter((r) => r.status === "missing");
  const missingKey = all.filter((r) => !r.sku || !r.spec || (canViewCustomerId() && !r.customerId));
  const severe = all.filter((r) => r.bucket === "24+");
  const unableLinked = all.filter((r) => !r.productionProgress && !r.workOrderStatus && r.status === "overdue");
  const stockReady = all.filter((r) => r.status === "overdue" && r.canShipFromStock);
  const stockHint = all.filter((r) => r.productionProgress.includes("拿库存") && r.status === "overdue");
  els.alerts.innerHTML = `
    <div class="section-head">
      <h2>异常提醒</h2>
      <span class="hint">先实现 Word 中的数据缺失、关联异常和库存线索类提醒</span>
    </div>
    <div class="alert-list">
      ${alertItem("三表整合状态", `主表 ${fmtNumber(state.sources.formal)} 行，逾期/路径表 ${fmtNumber(state.sources.overdue)} 行，库存条码 ${fmtNumber(state.sources.inventory)} 行。`, "info", "每日导入三表")}
      ${alertItem("数据更新时间", `当前数据生成于 ${state.generatedAt || "未知"}，页面按 ${state.asOfDate} 重新计算逾期。`, "info", "每日8:00/9:00规则待确认")}
      ${alertItem("交期缺失", `${fmtNumber(missingDue.length)} 行缺少业务交期，暂不进入逾期/未逾期正常判断。`, missingDue.length ? "critical" : "info", "需要补齐 O 列")}
      ${alertItem("关键字段缺失", `${fmtNumber(missingKey.length)} 行缺${canViewCustomerId() ? "客户、" : ""}SKU或规格。`, missingKey.length ? "critical" : "info", "影响汇总维度")}
      ${alertItem("关联异常", `${fmtNumber(unableLinked.length)} 行逾期订单没有生产进度或工单状态。`, unableLinked.length ? "critical" : "info", "建议人工排查")}
      ${alertItem("有库存未交付", `${fmtNumber(stockReady.length)} 行逾期订单满足“可用库存 ≥ 未交数量”。`, stockReady.length ? "critical" : "info", "优先出库")}
      ${alertItem("拿库存线索", `${fmtNumber(stockHint.length)} 行逾期订单生产进度为“拿库存”。`, stockHint.length ? "critical" : "info", "可优先核查库存/出库")}
      ${alertItem("严重逾期", `${fmtNumber(severe.length)} 行逾期 24 天以上。`, severe.length ? "critical" : "info", "深红预警")}
    </div>`;
}

function kittingSkuKey(record) {
  return record.sku || record.spec || record.name || orderKey(record);
}

const kittingStatusMeta = {
  ready: { label: "齐套", className: "is-ready" },
  short: { label: "未齐套", className: "is-short" },
  unknown: { label: "未确定", className: "is-unknown" },
};

function kittingStatusLabel(status) {
  return kittingStatusMeta[status]?.label || kittingStatusMeta.unknown.label;
}

function kittingBadgeClass(status) {
  return kittingStatusMeta[status]?.className || kittingStatusMeta.unknown.className;
}

function kittingStatusRank(status) {
  return { short: 0, unknown: 1, ready: 2 }[status] ?? 1;
}

async function parseShipmentFile(file) {
  if (/\.xlsx$/i.test(file.name)) return parseXlsxRows(file);
  if (!/\.xls$/i.test(file.name)) throw new Error("请选择.xls或.xlsx出通单文件");
  const bytes = new Uint8Array(await file.arrayBuffer());
  if (bytes[0] === 0xd0 && bytes[1] === 0xcf) throw new Error("此文件为二进制旧版Excel，请另存为.xlsx后导入");
  let text = new TextDecoder("utf-8").decode(bytes);
  const charset = text.slice(0, 4096).match(/charset\s*=\s*["']?([\w-]+)/i)?.[1];
  if (charset && /^(gb2312|gbk|gb18030)$/i.test(charset)) text = new TextDecoder("gb18030").decode(bytes);
  // A detached template keeps exported HTML scripts and external resources inert.
  const template = document.createElement("template");
  template.innerHTML = text;
  const table = template.content.querySelector("table");
  if (!table) throw new Error("无法读取.xls表格，文件可能受文档加密保护；请使用已解密且可读取的Excel，或另存为.xlsx");
  return [...table.rows].map((row) => {
    const values = [];
    for (const cell of row.cells) {
      if (cell.rowSpan > 1 || cell.colSpan > 200) throw new Error("出通单包含跨行合并单元格，请取消合并后导入");
      values.push(cell.textContent || "");
      for (let i = 1; i < cell.colSpan; i += 1) values.push("");
    }
    return values;
  });
}

function mapShipmentNoticeRows(rows) {
  const aliases = {
    orderNo: ["订单单号", "订单号"], sku: ["产品编号", "品号", "SKU"],
    shipmentNoticeNo: ["出通单号", "出货通知单号"], shipmentNoticeDate: ["录入日期", "出通单时间", "出通单日期"],
  };
  let headerIndex = -1, columns;
  for (let i = 0; i < Math.min(rows.length, 20); i += 1) {
    const headers = (rows[i] || []).map(normalizeHeader);
    const candidate = Object.fromEntries(Object.entries(aliases).map(([field, names]) => [field, headers.findIndex((name) => names.map(normalizeHeader).includes(name))]));
    if (["orderNo", "sku", "shipmentNoticeNo"].every((field) => candidate[field] >= 0)) { headerIndex = i; columns = candidate; break; }
  }
  if (headerIndex < 0) throw new Error("缺少必要列：订单单号、产品编号、出通单号；时间列可用录入日期");
  const records = [];
  let footer = false;
  for (let i = headerIndex + 1; i < rows.length; i += 1) {
    const row = rows[i] || [];
    if (!hasAnyValue(row)) continue;
    const record = Object.fromEntries(Object.entries(columns).map(([field, col]) => [field, col >= 0 ? compactText(row[col]) : ""]));
    if (!record.orderNo && !record.sku && !record.shipmentNoticeNo) {
      if (row.some((value) => /^(合计|总计|小计)[:：]?$/.test(compactText(value)))) footer = true;
      if (footer) continue;
    }
    if (!record.sku && ["合计", "总计", "小计"].includes(record.orderNo)) continue;
    if (!record.orderNo || !record.sku || !record.shipmentNoticeNo) throw new Error(`第${i + 1}行缺少订单号、产品编号或出通单号`);
    const shortDate = record.shipmentNoticeDate.match(/^(\d{2})\/(\d{1,2})\/(\d{1,2})$/);
    if (shortDate) {
      const date = validIsoDateText(2000 + Number(shortDate[1]), shortDate[2], shortDate[3]);
      if (!date) throw new Error(`第${i + 1}行录入日期无效`);
      record.shipmentNoticeDate = date;
    }
    records.push(record);
  }
  if (!records.length || records.length > 150000) throw new Error("明细不能为空且不能超过150000行");
  return records;
}

function openShipmentImport() {
  if (!isAdmin() || document.querySelector(".shipment-import-modal")) return;
  const previousFocus = document.activeElement;
  const modal = document.createElement("div");
  modal.className = "delay-drill-modal shipment-import-modal";
  modal.tabIndex = -1;
  modal.innerHTML = `<div class="delay-drill-backdrop"></div><section class="shipment-import-dialog" role="dialog" aria-modal="true" aria-label="出通单导入"><header class="delay-drill-head"><h2>出通单导入</h2><button type="button" data-shipment-close aria-label="关闭">×</button></header><form><label>出通单 Excel（.xls / .xlsx）<input type="file" name="file" accept=".xls,.xlsx" required/></label><label>导入方式<select name="mode" required><option value="">请选择</option><option value="append">追加：保留旧关联</option><option value="replace">完整清单替换：清除清单外关联</option></select></label><p>匹配键：订单单号 + 产品编号；同一订单同一产品的多个项次同时匹配。只更新出通单号和时间。</p><div class="shipment-import-status" role="status" aria-live="polite">等待选择文件</div><footer><button type="submit" class="ghost-button">预览匹配</button><button type="button" class="primary-button" data-shipment-save disabled>确认导入</button></footer></form></section>`;
  let busy = false, prepared = null;
  const status = modal.querySelector('[role="status"]'), save = modal.querySelector("[data-shipment-save]");
  const form = modal.querySelector("form");
  const previewButton = form.querySelector('button[type="submit"]');
  const syncActions = () => {
    save.hidden = !prepared;
    save.disabled = busy || !prepared;
    previewButton.className = prepared ? "ghost-button" : "primary-button";
  };
  const setBusy = (value) => {
    busy = value;
    modal.querySelectorAll("input, select, button").forEach((node) => { node.disabled = value; });
    syncActions();
    if (modal.isConnected) {
      if (value) modal.focus();
      else if (document.activeElement === modal || !modal.contains(document.activeElement)) modal.querySelector('button[type="submit"]').focus();
    }
  };
  const close = () => { if (!busy) { modal.remove(); if (previousFocus?.isConnected) previousFocus.focus(); } };
  modal.querySelector("[data-shipment-close]").addEventListener("click", close);
  modal.querySelector(".delay-drill-backdrop").addEventListener("click", close);
  modal.addEventListener("keydown", (event) => {
    if (event.key === "Escape") close();
    if (event.key === "Tab") {
      const controls = [...modal.querySelectorAll("button:not(:disabled), input:not(:disabled), select:not(:disabled)")];
      const first = controls[0], last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  form.addEventListener("change", () => { prepared = null; syncActions(); status.textContent = "待预览匹配"; });
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (busy || !isAdmin()) return;
    const file = form.elements.file.files[0], mode = form.elements.mode.value;
    prepared = null; setBusy(true); status.textContent = "正在读取并核对匹配…";
    try {
      if (!file || !/\.xlsx?$/i.test(file.name)) throw new Error("请选择.xls或.xlsx出通单文件");
      if (file.size > 20 * 1024 * 1024) throw new Error("文件不能超过20MB");
      const rows = mapShipmentNoticeRows(await parseShipmentFile(file));
      const payload = { rows, mode, sourceFile: file.name };
      const result = await api("/api/import-shipment-notices", { method: "POST", body: JSON.stringify(payload) });
      prepared = { ...payload, revision: result.revision, commit: true };
      const preview = result.preview;
      status.textContent = `${preview.effectiveDate} 当前订单：文件${fmtNumber(preview.rowCount)}条明细，${fmtNumber(preview.keyCount)}个订单产品组合；匹配${fmtNumber(preview.matchedRows)}个订单行，未匹配${fmtNumber(preview.unmatchedKeys)}个组合。${mode === "replace" ? `将清除${fmtNumber(preview.clearedRows)}行原有关联。` : "保留原有关联。"}历史日期不回写，后续三表导入继续沿用。`;
    } catch (error) { status.textContent = `预览失败：${error.message}`; }
    finally { setBusy(false); }
  });
  save.addEventListener("click", async () => {
    if (busy || !prepared || !isAdmin()) return;
    setBusy(true); status.textContent = "正在保存出通单关联…";
    try {
      const result = await api("/api/import-shipment-notices", { method: "POST", body: JSON.stringify(prepared) });
      prepared = null;
      state.delayDatasetCache.clear();
      try { await loadData(); }
      catch { status.textContent = "出通单已保存，但页面刷新失败，请刷新页面查看。"; return; }
      els.importStatus.textContent = `出通单导入成功：匹配${fmtNumber(result.summary.matchedRows)}行，未匹配${fmtNumber(result.summary.unmatchedKeys)}个组合`;
      setBusy(false); close();
    } catch (error) { prepared = null; status.textContent = `导入未确认完成：${error.message}，请重新预览核对。`; }
    finally { setBusy(false); }
  });
  syncActions();
  document.body.appendChild(modal);
  modal.querySelector('input[type="file"]').focus();
}

function mapKittingReferenceRows(rows) {
  const aliases = {
    orderNo: ["订单单号", "订单号"],
    sku: ["品号", "SKU"],
    unshippedQty: ["未发数量", "未出数量", "订单未出数", "未交数量"],
    status: ["是否齐套", "齐套状态", "齐套"],
  };
  let headerIndex = -1;
  let columns;
  for (let index = 0; index < Math.min(rows.length, 20); index += 1) {
    const headers = (rows[index] || []).map(normalizeHeader);
    const candidate = Object.fromEntries(Object.entries(aliases).map(([key, names]) =>
      [key, headers.findIndex((header) => names.includes(header))]));
    if (Object.values(candidate).every((column) => column >= 0)) {
      headerIndex = index;
      columns = candidate;
      break;
    }
  }
  if (headerIndex < 0) throw new Error("缺少必要列：订单单号、品号、未发数量、是否齐套");
  const records = [];
  for (let index = headerIndex + 1; index < rows.length; index += 1) {
    const row = rows[index] || [];
    if (!hasAnyValue(row)) continue;
    const orderNo = compactText(row[columns.orderNo]);
    const sku = compactText(row[columns.sku]);
    if (!sku && ["合计", "总计", "小计"].includes(orderNo)) continue;
    if (!orderNo || !sku) throw new Error(`第 ${index + 1} 行缺少订单号或品号`);
    const rawQuantity = compactText(row[columns.unshippedQty]).replace(/,/g, "");
    const unshippedQty = Number(rawQuantity);
    if (!rawQuantity || !Number.isFinite(unshippedQty)) throw new Error(`第 ${index + 1} 行未发数量无效`);
    const status = compactText(row[columns.status]);
    if (unshippedQty > 0 && !["齐套", "未齐套"].includes(status)) {
      throw new Error(`第 ${index + 1} 行“是否齐套”必须为齐套或未齐套`);
    }
    records.push({ orderNo, sku, unshippedQty, status });
  }
  if (!records.some((record) => record.unshippedQty > 0)) throw new Error("没有未发数量大于 0 的订单，旧数据未替换");
  if (records.length > 150000) throw new Error("最多支持 150000 行明细");
  return records;
}

async function importKittingReference(file) {
  if (!file || state.kittingImportBusy) return;
  state.kittingImportBusy = true;
  state.kittingImportError = false;
  state.kittingImportMessage = "正在读取 Excel…";
  renderKitting();
  try {
    if (!/\.xlsx$/i.test(file.name)) throw new Error("请选择 .xlsx 格式的齐套明细表");
    if (file.size > 20 * 1024 * 1024) throw new Error("Excel 文件不能超过 20MB");
    await waitForPaint();
    let sheetRows;
    try {
      sheetRows = await parseXlsxRows(file);
    } catch {
      throw new Error("无法读取 Excel，请使用未加密且可正常打开的 .xlsx 文件");
    }
    const rows = mapKittingReferenceRows(sheetRows);
    const orderCount = new Set(rows.filter((row) => row.unshippedQty > 0).map((row) => row.orderNo)).size;
    if (!window.confirm(`将用“${file.name}”中的 ${fmtNumber(orderCount)} 个订单整体替换当前 Excel 齐套对照数据，是否继续？`)) {
      state.kittingImportMessage = "已取消导入，原数据保持不变";
      return;
    }
    state.kittingImportMessage = "正在保存…";
    renderKitting();
    const dateMatch = file.name.match(/_(20\d{2})(\d{2})(\d{2})\d{0,6}\.xlsx$/i);
    const result = await api("/api/import-kitting-reference", {
      method: "POST",
      body: JSON.stringify({ sourceFile: file.name, rows,
        asOfDate: dateMatch ? `${dateMatch[1]}-${dateMatch[2]}-${dateMatch[3]}` : "" }),
    });
    state.kittingReference = result.reference;
    state.columnFilterOptionCache.clear();
    closeKittingDetailModal();
    state.kittingImportMessage = `导入成功：${fmtNumber(result.reference.orderCount)} 个订单，${fmtNumber(result.reference.rowCount)} 条明细`;
  } catch (error) {
    state.kittingImportError = true;
    state.kittingImportMessage = `${error.message}。未完成导入，请重试。`;
  } finally {
    state.kittingImportBusy = false;
    render();
  }
}

function kittingReferenceFor(orderNo) {
  const item = state.kittingReference?.orders?.[orderNo];
  return item && typeof item.kitted === "boolean" ? item : null;
}

function kittingReferenceStatusText(reference) {
  if (!reference) return "未确定";
  return reference.kitted ? "齐套" : "未齐套";
}

function orderKittingStatus(orderNo) {
  const reference = kittingReferenceFor(orderNo);
  return reference ? (reference.kitted ? "ready" : "short") : "unknown";
}

function buildKittingOrders(records) {
  const map = new Map();
  for (const record of records) {
    const unshippedQty = Number(record.unshippedQty || 0);
    if (unshippedQty <= 0) continue;
    const orderNo = record.orderNo || "订单号缺失";
    if (!map.has(orderNo)) {
      map.set(orderNo, {
        orderNo,
        rows: [],
        customers: new Set(),
        customerShortNames: new Set(),
        skus: new Map(),
      });
    }
    const order = map.get(orderNo);
    order.rows.push(record);
    if (record.customerId) order.customers.add(record.customerId);
    if (record.customerShortName) order.customerShortNames.add(record.customerShortName);

    const skuKey = kittingSkuKey(record);
    if (!order.skus.has(skuKey)) {
      order.skus.set(skuKey, {
        key: skuKey,
        sku: record.sku || "",
        name: record.name || "",
        spec: record.spec || "",
        unshippedQty: 0,
        availableStock: 0,
        lines: 0,
      });
    }
    const sku = order.skus.get(skuKey);
    sku.unshippedQty += unshippedQty;
    sku.availableStock = Math.max(sku.availableStock, Number(record.availableStock || 0));
    sku.lines += 1;
  }

  return [...map.values()].map((order) => {
    const skuRows = [...order.skus.values()];
    const failedSkus = skuRows.filter((sku) => !(sku.unshippedQty <= sku.availableStock));
    const totalUnshipped = skuRows.reduce((sum, sku) => sum + sku.unshippedQty, 0);
    const totalAvailable = skuRows.reduce((sum, sku) => sum + sku.availableStock, 0);
    const shortageQty = failedSkus.reduce((sum, sku) => sum + Math.max(0, sku.unshippedQty - sku.availableStock), 0);
    const reference = kittingReferenceFor(order.orderNo);
    const kittingStatus = orderKittingStatus(order.orderNo);
    return {
      ...order,
      skuRows,
      failedSkus,
      isKitted: kittingStatus === "ready",
      referenceKitted: reference ? reference.kitted : null,
      kittingStatus,
      kittingStatusText: kittingStatusLabel(kittingStatus),
      referenceStatusText: kittingReferenceStatusText(reference),
      lineCount: order.rows.length,
      skuCount: skuRows.length,
      totalUnshipped,
      totalAvailable,
      shortageQty,
      customerText: [...order.customers].join("、"),
      customerShortNameText: [...order.customerShortNames].join("、"),
    };
  }).sort((a, b) => kittingStatusRank(a.kittingStatus) - kittingStatusRank(b.kittingStatus)
    || b.failedSkus.length - a.failedSkus.length
    || b.shortageQty - a.shortageQty
    || b.totalUnshipped - a.totalUnshipped);
}

function cachedKittingOrders() {
  const cached = state.kittingOrdersCache;
  if (cached?.source === state.filtered && cached.reference === state.kittingReference) return cached.rows;
  const rows = buildKittingOrders(state.filtered);
  state.kittingOrdersCache = { source: state.filtered, reference: state.kittingReference, rows };
  state.kittingPage = 0;
  return rows;
}

function renderKitting() {
  const allRows = cachedKittingOrders();
  const rows = allRows.filter((item) => {
    if (state.kittingStatus !== "all") return item.kittingStatus === state.kittingStatus;
    return true;
  });
  const kitted = allRows.filter((item) => item.kittingStatus === "ready");
  const notKitted = allRows.filter((item) => item.kittingStatus === "short");
  const unknown = allRows.filter((item) => item.kittingStatus === "unknown");
  const totalUnshipped = allRows.reduce((sum, item) => sum + item.totalUnshipped, 0);
  const totalAvailable = allRows.reduce((sum, item) => sum + item.totalAvailable, 0);
  const failedSkuCount = allRows.reduce((sum, item) => sum + item.failedSkus.length, 0);
  const showCustomer = canViewCustomerId();
  const pageSize = 100, pages = Math.max(1, Math.ceil(rows.length / pageSize));
  state.kittingPage = Math.max(0, Math.min(state.kittingPage, pages - 1));
  const visible = rows.slice(state.kittingPage * pageSize, (state.kittingPage + 1) * pageSize);
  els.kitting.innerHTML = `
    <div class="section-head">
      <div>
        <h2>齐套分析</h2>
        <span class="hint kitting-reference-meta">${state.kittingReference.sourceFile ? `数仓文件：${escapeHtml(String(state.kittingReference.sourceFile).split(/[\\/]/).pop())} · 更新于 ${escapeHtml(state.kittingReference.generatedAt || "")}` : "尚未导入数仓齐套数据"}</span>
      </div>
      ${isAdmin() ? `<button id="importKittingButton" class="export-orders-button" type="button" ${state.kittingImportBusy ? "disabled" : ""}>${state.kittingImportBusy ? "导入中…" : "导入Excel"}</button><input id="kittingFileInput" class="file-input" type="file" accept=".xlsx" aria-label="选择齐套明细Excel" ${state.kittingImportBusy ? "disabled" : ""}>` : ""}
    </div>
    <div class="kitting-import-message ${state.kittingImportError ? "is-error" : ""}" role="status" aria-live="polite" ${state.kittingImportMessage ? "" : "hidden"}>${escapeHtml(state.kittingImportMessage)}</div>
    <div class="drill-page kitting-page">
      <div class="drill-summary kitting-summary">
        <span><strong>${fmtNumber(allRows.length)}</strong><em>有未出订单</em></span>
        <span><strong>${fmtNumber(kitted.length)}</strong><em>齐套订单</em></span>
        <span><strong>${fmtNumber(notKitted.length)}</strong><em>未齐套订单</em></span>
        <span><strong>${fmtNumber(unknown.length)}</strong><em>未确定订单</em></span>
        <span><strong>${allRows.length ? ((kitted.length / allRows.length) * 100).toFixed(1) : "0.0"}%</strong><em>齐套率</em></span>
        <span><strong>${fmtNumber(failedSkuCount)}</strong><em>库存不足SKU</em></span>
        <span><strong>${fmtNumber(totalUnshipped)}</strong><em>未出数量</em></span>
        <span><strong>${fmtNumber(totalAvailable)}</strong><em>库存数量</em></span>
      </div>
      <div class="table-wrap">
        <table class="kitting-table">
          <thead>
            <tr>
              <th style="width:10%">
                <label class="kitting-status-filter">
                  <span>齐套状态</span>
                  <select id="kittingStatusFilter" aria-label="筛选齐套状态">
                    <option value="all" ${state.kittingStatus === "all" ? "selected" : ""}>全部</option>
                    <option value="ready" ${state.kittingStatus === "ready" ? "selected" : ""}>齐套</option>
                    <option value="short" ${state.kittingStatus === "short" ? "selected" : ""}>未齐套</option>
                    <option value="unknown" ${state.kittingStatus === "unknown" ? "selected" : ""}>未确定</option>
                  </select>
                </label>
              </th>
              ${showCustomer ? '<th style="width:9%">客户</th><th style="width:12%">客户简称</th>' : ""}
              <th style="width:14%">订单号</th>
              <th class="num" style="width:7%">SKU数</th>
              <th class="num" style="width:7%">订单行</th>
              <th class="num" style="width:9%">未出数量</th>
              <th class="num" style="width:9%">库存数量</th>
              <th class="num" style="width:8%">库存不足SKU</th>
              <th style="width:8%">下钻</th>
            </tr>
          </thead>
          <tbody>
            ${rows.length ? visible.map((order) => `
                <tr>
                  <td><span class="kitting-badge ${kittingBadgeClass(order.kittingStatus)}">${order.kittingStatusText}</span></td>
                  ${showCustomer ? `<td>${escapeHtml(order.customerText)}</td><td class="name" title="${escapeHtml(order.customerShortNameText)}">${escapeHtml(order.customerShortNameText)}</td>` : ""}
                  <td>${escapeHtml(order.orderNo)}</td>
                  <td class="num">${fmtNumber(order.skuCount)}</td>
                  <td class="num">${fmtNumber(order.lineCount)}</td>
                  <td class="num">${fmtNumber(order.totalUnshipped)}</td>
                  <td class="num">${fmtNumber(order.totalAvailable)}</td>
                  <td class="num">${order.failedSkus.length ? fmtNumber(order.failedSkus.length) : ""}</td>
                  <td><button class="kitting-drill-button" type="button" data-kitting-detail="${escapeHtml(order.orderNo)}">明细</button></td>
                </tr>`).join("") : `<tr><td colspan="${showCustomer ? 10 : 8}" class="empty-cell">当前筛选下没有未出订单行</td></tr>`}
          </tbody>
        </table>
      </div>
      <footer class="customer-orders-pagination"><span>${state.kittingPage + 1} / ${pages} 页 · 共 ${fmtNumber(rows.length)} 单 · 每页 ${pageSize} 单</span><button type="button" data-kitting-prev title="上一页" aria-label="上一页" ${state.kittingPage === 0 ? "disabled" : ""}>‹</button><button type="button" data-kitting-next title="下一页" aria-label="下一页" ${state.kittingPage + 1 === pages ? "disabled" : ""}>›</button></footer>
    </div>`;
  els.kitting.querySelector("[data-kitting-prev]").addEventListener("click", () => { state.kittingPage -= 1; renderKitting(); });
  els.kitting.querySelector("[data-kitting-next]").addEventListener("click", () => { state.kittingPage += 1; renderKitting(); });
  els.kitting.querySelectorAll("[data-kitting-detail]").forEach((button) => {
    button.addEventListener("click", () => openKittingDetailModal(button.dataset.kittingDetail));
  });
  els.kitting.querySelector("#importKittingButton")?.addEventListener("click", () => {
    els.kitting.querySelector("#kittingFileInput")?.click();
  });
  els.kitting.querySelector("#kittingFileInput")?.addEventListener("change", (event) => {
    importKittingReference(event.target.files?.[0]);
  });
  els.kitting.querySelector("#kittingStatusFilter")?.addEventListener("change", (event) => {
    state.kittingStatus = event.target.value;
    state.kittingPage = 0;
    renderKitting();
  });
}

function closeKittingDetailModal() {
  document.querySelector(".kitting-detail-modal")?.remove();
}

function openKittingDetailModal(orderNo) {
  const order = cachedKittingOrders().find((item) => item.orderNo === orderNo);
  if (!order) return;
  const showCustomer = canViewCustomerId();
  const modal = document.createElement("div");
  modal.className = "delay-drill-modal kitting-detail-modal";
  modal.tabIndex = -1;
  const rows = [...order.skuRows].sort((a, b) => Number(a.unshippedQty <= a.availableStock) - Number(b.unshippedQty <= b.availableStock)
    || b.unshippedQty - a.unshippedQty);
  modal.innerHTML = `
    <div class="delay-drill-backdrop" data-close-kitting-detail></div>
    <section class="delay-drill-page" role="dialog" aria-modal="true" aria-label="齐套明细下钻">
      <header class="delay-drill-head">
        <div>
          <span>${showCustomer ? `${escapeHtml(order.customerText)} / ${escapeHtml(order.customerShortNameText)}` : "订单齐套明细"}</span>
          <h2>${escapeHtml(order.orderNo)} / ${order.kittingStatusText}</h2>
        </div>
        <div class="delay-drill-head-actions">
          <button type="button" data-close-kitting-detail title="关闭">×</button>
        </div>
      </header>
      <div class="delay-drill-stats kitting-detail-stats">
        <span><strong>${order.referenceStatusText}</strong><em>导入表状态</em></span>
        <span><strong>${fmtNumber(order.skuCount)}</strong><em>SKU数</em></span>
        <span><strong>${fmtNumber(order.lineCount)}</strong><em>订单行</em></span>
        <span><strong>${fmtNumber(order.failedSkus.length)}</strong><em>库存不足SKU</em></span>
        <span><strong>${fmtNumber(order.totalUnshipped)}</strong><em>未出数量</em></span>
        <span><strong>${fmtNumber(order.totalAvailable)}</strong><em>库存数量</em></span>
        <span><strong>${fmtNumber(order.shortageQty)}</strong><em>缺口数量</em></span>
      </div>
      <div class="table-wrap delay-drill-table-wrap">
        <table class="delay-drill-table kitting-detail-table">
          <thead>
            <tr>
              <th style="width:11%">库存对比</th>
              <th style="width:15%">SKU</th>
              <th style="width:20%">品名</th>
              <th style="width:22%">规格</th>
              <th class="num" style="width:8%">订单行</th>
              <th class="num" style="width:9%">未出数量</th>
              <th class="num" style="width:9%">库存数量</th>
              <th class="num" style="width:8%">差额</th>
            </tr>
          </thead>
          <tbody>
            ${rows.map((sku) => {
              const ready = sku.unshippedQty <= sku.availableStock;
              return `
                <tr>
                  <td><span class="kitting-badge ${ready ? "is-ready" : "is-short"}">${ready ? "满足" : "不满足"}</span></td>
                  <td>${escapeHtml(sku.sku || sku.key)}</td>
                  <td class="name" title="${escapeHtml(sku.name)}">${escapeHtml(sku.name)}</td>
                  <td class="name" title="${escapeHtml(sku.spec)}">${escapeHtml(sku.spec)}</td>
                  <td class="num">${fmtNumber(sku.lines)}</td>
                  <td class="num">${fmtNumber(sku.unshippedQty)}</td>
                  <td class="num">${fmtNumber(sku.availableStock)}</td>
                  <td class="num">${fmtNumber(sku.availableStock - sku.unshippedQty)}</td>
                </tr>`;
            }).join("")}
          </tbody>
        </table>
      </div>
    </section>`;
  closeKittingDetailModal();
  document.body.appendChild(modal);
  modal.querySelectorAll("[data-close-kitting-detail]").forEach((node) => node.addEventListener("click", closeKittingDetailModal));
  modal.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeKittingDetailModal();
  });
  modal.querySelector("[data-close-kitting-detail]")?.focus();
}

function alertItem(title, body, tone, action) {
  return `<div class="alert ${tone}"><strong>${title}</strong><span>${body}</span><em>${action}</em></div>`;
}

function delayOrderKey(record) {
  return `${record.customerId || "客户缺失"}|${record.orderNo || ""}`;
}

const delayMetricDefs = {
  orders: { label: "订单张数", unit: "张", axis: "订单张数" },
  lines: { label: "订单行数", unit: "行", axis: "订单行数" },
  products: { label: "产品数", unit: "个", axis: "产品数量" },
  skus: { label: "SKU数", unit: "个", axis: "SKU数" },
  customers: { label: "客户数", unit: "个", axis: "客户数" },
};

function delayMetricLabel() {
  return delayMetricDefs[state.delayMetric]?.label || delayMetricDefs.orders.label;
}

function delayMetricUnit() {
  return delayMetricDefs[state.delayMetric]?.unit || delayMetricDefs.orders.unit;
}

function delayMetricAxis() {
  return delayMetricDefs[state.delayMetric]?.axis || delayMetricDefs.orders.axis;
}

function delayMetricKey(record, metric) {
  if (metric === "customers") return delayCustomerKey(record);
  if (metric === "lines") return `${record.customerId || ""}|${record.orderNo || ""}|${record.lineNo ?? ""}|${record.sku || record.spec || ""}|${record.businessDueDate || ""}`;
  if (metric === "products") return delayProductKey(record);
  if (metric === "skus") return record.sku || record.spec || record.name || delayMetricKey(record, "lines");
  return delayOrderKey(record);
}

function delayProductKey(record) {
  return record.category4 || record.name || record.spec || record.sku || delayMetricKey(record, "lines");
}

function delayCustomerKey(record) {
  return record.customerId || record.customerShortName || "客户缺失";
}

function delayCustomerLabel(record) {
  const id = record.customerId || "客户缺失";
  const name = record.customerShortName || "";
  return name && name !== id ? `${id} / ${name}` : id;
}

function delayBucketForDays(days) {
  if (days <= 14) {
    return {
      key: `D${days}`,
      sort: days,
      label: [1, 7, 14].includes(days) ? `${days}天` : "",
      title: `延期 ${days} 天`,
    };
  }
  if (days <= 21) return { key: "W3", sort: 21, label: "W3", title: "延期 15-21 天" };
  if (days <= 28) return { key: "W4", sort: 28, label: "W4", title: "延期 22-28 天" };
  const month = Math.max(2, Math.ceil(days / 30));
  const start = month === 2 ? 29 : (month - 1) * 30 + 1;
  const end = month * 30;
  return { key: `M${month}`, sort: end, label: `M${month}`, title: `延期 ${start}-${end} 天` };
}

function clampDelayBucketTitle(bucket, maxDay) {
  if (!Number.isFinite(maxDay)) return bucket;
  if (bucket.key === "W3") {
    const end = Math.min(21, maxDay);
    return { ...bucket, title: end === 15 ? "延期 15 天" : `延期 15-${end} 天` };
  }
  if (bucket.key === "W4") {
    const end = Math.min(28, maxDay);
    return { ...bucket, title: end === 22 ? "延期 22 天" : `延期 22-${end} 天` };
  }
  if (bucket.key.startsWith("M")) {
    const month = Number(bucket.key.slice(1));
    const start = month === 2 ? 29 : (month - 1) * 30 + 1;
    const end = Math.min(month * 30, maxDay);
    return { ...bucket, title: end === start ? `延期 ${start} 天` : `延期 ${start}-${end} 天` };
  }
  return bucket;
}

function delayW4PlusBucket(maxDay) {
  const end = Number.isFinite(maxDay) ? Math.max(29, Math.floor(maxDay)) : Infinity;
  const title = Number.isFinite(end)
    ? (end === 29 ? "延期 29 天以上累计" : `延期 29-${end} 天累计`)
    : "延期 29 天以上累计";
  return { key: "W4PLUS", sort: 29, label: "W4+", title, maxDay: end };
}

function shouldUseW4PlusBucket(cycleDays) {
  return cycleDays !== "all" && Number(cycleDays || 30) <= 30;
}

function delayBucketsForCycle(cycleDays, points) {
  const maxPointDay = Math.max(0, ...points.map((point) => point.maxDay || point.sort || 0));
  const maxDay = cycleDays === "all" ? maxPointDay : Number(cycleDays || 30);
  const useW4Plus = shouldUseW4PlusBucket(cycleDays);
  const buckets = new Map();
  const addBucket = (days) => {
    const bucket = clampDelayBucketTitle(delayBucketForDays(days), maxDay);
    if (!buckets.has(bucket.key)) buckets.set(bucket.key, bucket);
  };
  for (let day = 1; day <= Math.min(14, maxDay); day += 1) addBucket(day);
  if (maxDay >= 15) addBucket(21);
  if (maxDay >= 22) addBucket(28);
  if (maxDay >= 29 && useW4Plus) {
    buckets.set("W4PLUS", delayW4PlusBucket(maxDay));
  } else {
    for (let month = 2; month <= Math.ceil(maxDay / 30); month += 1) addBucket(month * 30);
  }
  return [...buckets.values()].sort((a, b) => a.sort - b.sort);
}

function buildDelayPattern(overdue, cycleDays, metric = state.delayMetric) {
  const observedMaxDay = Math.max(0, ...overdue.map((record) => Math.floor(Number(record.overdueDays || 0))));
  const maxDay = cycleDays === "all" ? observedMaxDay : Number(cycleDays || 30);
  const useW4Plus = shouldUseW4PlusBucket(cycleDays);
  const byBucket = new Map();
  for (const record of overdue) {
    const days = Math.max(0, Math.floor(Number(record.overdueDays || 0)));
    if (days <= 0 || days > maxDay) continue;
    const bucket = days >= 29 && useW4Plus ? delayW4PlusBucket(maxDay) : delayBucketForDays(days);
    if (!byBucket.has(bucket.key)) byBucket.set(bucket.key, { ...bucket, values: new Set() });
    byBucket.get(bucket.key).values.add(delayMetricKey(record, metric));
  }
  return [...byBucket.values()]
    .map(({ values, ...bucket }) => ({ ...bucket, count: values.size }))
    .sort((a, b) => a.sort - b.sort);
}

function delayBucketMatches(bucketKey, days, cycleDays = "all") {
  if (!bucketKey || !Number.isFinite(days)) return false;
  if (bucketKey.startsWith("D")) return days === Number(bucketKey.slice(1));
  if (bucketKey === "W3") return days >= 15 && days <= 21;
  if (bucketKey === "W4") return days >= 22 && days <= 28;
  if (bucketKey === "W4PLUS") {
    const maxDay = cycleDays === "all" ? Infinity : Number(cycleDays || 30);
    return days >= 29 && days <= maxDay;
  }
  if (bucketKey.startsWith("M")) {
    const month = Number(bucketKey.slice(1));
    const start = month === 2 ? 29 : (month - 1) * 30 + 1;
    const end = month * 30;
    return days >= start && days <= end;
  }
  return false;
}

function delayPayloadForDate(date) {
  if (date === state.asOfDate) {
    return {
      asOfDate: state.asOfDate,
      label: labelForIsoDate(state.asOfDate),
      records: state.records,
    };
  }
  return state.delayDatasetCache.get(date) || null;
}

function delayDrillRows(seriesKind, bucketKey) {
  const date = seriesKind === "line" ? state.delayLineDate : state.delayBarDate;
  const payload = delayPayloadForDate(date);
  const asOfDate = payload?.asOfDate || date;
  const rows = (payload?.records || [])
    .map((record) => enrichForDate(record, asOfDate))
    .filter((record) => record.status === "overdue" && delayBucketMatches(bucketKey, Math.floor(Number(record.overdueDays || 0)), state.delayCycleDays))
    .sort((a, b) => (b.overdueDays || 0) - (a.overdueDays || 0) || Number(b.unshippedQty || 0) - Number(a.unshippedQty || 0));
  const metricValues = new Set(rows.map((record) => delayMetricKey(record, state.delayMetric)).filter(Boolean));
  const maxRowDay = Math.max(0, ...rows.map((record) => Math.floor(Number(record.overdueDays || 0))));
  const bucket = bucketKey === "W4PLUS"
    ? delayW4PlusBucket(state.delayCycleDays === "all" ? maxRowDay : Number(state.delayCycleDays || 30))
    : delayBucketsForCycle("all", rows.map((record) => delayBucketForDays(Math.floor(Number(record.overdueDays || 0))))).find((item) => item.key === bucketKey)
      || delayBucketForDays(Math.max(1, Number(bucketKey.slice(1)) || 1));
  return {
    date,
    label: payload?.label || labelForIsoDate(date),
    seriesName: seriesKind === "line" ? "折线图" : "柱形图",
    bucketTitle: bucket.title,
    metricCount: metricValues.size,
    rows,
  };
}

function summarizeDelayCustomers(rows) {
  const map = new Map();
  for (const record of rows) {
    const key = delayCustomerKey(record);
    if (!map.has(key)) {
      map.set(key, {
        key,
        label: delayCustomerLabel(record),
        customerId: record.customerId || "",
        customerShortName: record.customerShortName || "",
        rows: [],
        orderKeys: new Set(),
        productKeys: new Set(),
        skuKeys: new Set(),
        qty: 0,
        maxDays: 0,
      });
    }
    const item = map.get(key);
    item.rows.push(record);
    item.orderKeys.add(delayOrderKey(record));
    item.productKeys.add(delayProductKey(record));
    item.skuKeys.add(record.sku || record.spec || record.name || orderKey(record));
    item.qty += Number(record.unshippedQty || 0);
    item.maxDays = Math.max(item.maxDays, Number(record.overdueDays || 0));
  }
  return [...map.values()]
    .map((item) => ({
      ...item,
      lines: item.rows.length,
      orders: item.orderKeys.size,
      products: item.productKeys.size,
      skus: item.skuKeys.size,
    }))
    .sort((a, b) => b.maxDays - a.maxDays || b.qty - a.qty || b.lines - a.lines);
}

function delayDatasets() {
  const byDate = new Map();
  for (const item of state.dailyHistory || []) {
    if (item.date) byDate.set(item.date, item);
  }
  if (state.asOfDate) {
    byDate.set(state.asOfDate, {
      ...(byDate.get(state.asOfDate) || {}),
      date: state.asOfDate,
      label: byDate.get(state.asOfDate)?.label || labelForIsoDate(state.asOfDate),
      file: byDate.get(state.asOfDate)?.file || "orders.json",
    });
  }
  return [...byDate.values()].sort((a, b) => a.date.localeCompare(b.date));
}

function ensureDelayCompareDates(datasets) {
  if (!datasets.length) return;
  const dates = new Set(datasets.map((item) => item.date));
  if (!state.delayBarDate || !dates.has(state.delayBarDate)) {
    state.delayBarDate = dates.has(state.asOfDate) ? state.asOfDate : datasets[datasets.length - 1].date;
  }
  if (!state.delayLineDate || !dates.has(state.delayLineDate)) {
    const previous = [...datasets].reverse().find((item) => item.date !== state.delayBarDate && (item.file || item.date === state.asOfDate));
    state.delayLineDate = previous?.date || state.delayBarDate;
  }
}

function delayDateOptions(datasets, selected) {
  return datasets
    .map((item) => {
      const disabled = !item.file && item.date !== state.asOfDate ? "disabled" : "";
      return `<option value="${item.date}" ${item.date === selected ? "selected" : ""} ${disabled}>${item.label || item.date}</option>`;
    })
    .join("");
}

function requestDelayDataset(date) {
  if (!date || date === state.asOfDate || state.delayDatasetCache.has(date) || state.delayDatasetLoading.has(date)) return;
  const item = delayDatasets().find((dataset) => dataset.date === date);
  if (!item?.file) return;
  state.delayDatasetLoading.add(date);
  fetch(`./public/data/${item.file}`)
    .then((response) => {
      if (!response.ok) throw new Error(`历史数据加载失败 ${response.status}`);
      return response.json();
    })
    .then((payload) => {
      state.delayDatasetCache.set(date, payload);
    })
    .catch((error) => {
      state.delayDatasetCache.set(date, { error: error.message, records: [] });
    })
    .finally(() => {
      state.delayDatasetLoading.delete(date);
      if (state.activeTab === "summary") renderSummary();
      if (state.activeTab === "orderStatusOverview") {
        clearTimeout(state.statusTrendRenderTimer);
        state.statusTrendRenderTimer = setTimeout(() => {
          state.statusTrendRenderTimer = 0;
          if (state.activeTab === "orderStatusOverview") renderStatusAnalysis();
        }, 60);
      }
    });
}

function delaySeriesForDate(date) {
  const item = delayDatasets().find((dataset) => dataset.date === date);
  let payload = null;
  if (date === state.asOfDate) {
    payload = {
      asOfDate: state.asOfDate,
      label: item?.label || labelForIsoDate(state.asOfDate),
      records: state.records,
    };
  } else if (state.delayDatasetCache.has(date)) {
    payload = state.delayDatasetCache.get(date);
  } else if (item?.file) {
    requestDelayDataset(date);
    return { date, label: item.label || date, points: [], total: 0, status: "loading" };
  } else {
    return { date, label: item?.label || date, points: [], total: 0, status: "unavailable" };
  }
  if (payload.error) {
    return { date, label: item?.label || date, points: [], total: 0, status: "error", message: payload.error };
  }
  const asOfDate = payload.asOfDate || date;
  const overdue = (payload.records || []).map((record) => enrichForDate(record, asOfDate)).filter((record) => record.status === "overdue");
  const points = buildDelayPattern(overdue, state.delayCycleDays);
  return {
    date,
    label: payload.label || item?.label || labelForIsoDate(date),
    points,
    total: points.reduce((sum, point) => sum + point.count, 0),
    status: "ready",
  };
}

function delayChartSize() {
  const viewportHeight = window.innerHeight || 900;
  if (viewportHeight < 650) return { height: 164, top: 28, bottom: 30, left: 46, slot: 24, width: 680 };
  if (viewportHeight < 740) return { height: 188, top: 30, bottom: 32, left: 48, slot: 25, width: 700 };
  if (viewportHeight < 820) return { height: 212, top: 32, bottom: 35, left: 48, slot: 26, width: 710 };
  return { height: 238, top: 34, bottom: 38, left: 50, slot: 27, width: 720 };
}

function renderDelayPatternChart(barSeries, lineSeries, cycleDays) {
  const seriesPoints = [...barSeries.points, ...lineSeries.points];
  if (!seriesPoints.length) {
    const note = [barSeries, lineSeries].some((series) => series.status === "loading") ? "正在加载所选日期的数据。" : "当前周期内没有延期订单。";
    return `<div class="empty delay-empty">${note}</div>`;
  }
  const buckets = delayBucketsForCycle(cycleDays, seriesPoints);
  const size = delayChartSize();
  const height = size.height;
  const top = size.top;
  const right = 18;
  const bottom = size.bottom;
  const left = size.left;
  const slot = size.slot;
  const width = Math.max(size.width, left + right + buckets.length * slot);
  const chartHeight = height - top - bottom;
  const chartWidth = width - left - right;
  const barByBucket = new Map(barSeries.points.map((item) => [item.key, item.count]));
  const lineByBucket = new Map(lineSeries.points.map((item) => [item.key, item.count]));
  const maxCount = Math.max(...barSeries.points.map((item) => item.count), ...lineSeries.points.map((item) => item.count), 1);
  const yTicks = [0, Math.ceil(maxCount / 2), maxCount].filter((value, index, arr) => arr.indexOf(value) === index);
  const cycleText = cycleDays === "all" ? "全部延期天数" : `近 ${cycleDays} 天延期`;
  const metricLabel = delayMetricLabel();
  const metricUnit = delayMetricUnit();
  const metricAxis = delayMetricAxis();
  const labelBoxes = [];
  const labelBox = (x, y, text) => {
    const width = String(text).length * 7 + 8;
    return { x1: x - width / 2, x2: x + width / 2, y1: y - 11, y2: y + 3 };
  };
  const hasOverlap = (box) => labelBoxes.some((item) => !(box.x2 < item.x1 || box.x1 > item.x2 || box.y2 < item.y1 || box.y1 > item.y2));
  const placeLabel = (x, preferredY, text, candidates = []) => {
    for (const y of [preferredY, ...candidates]) {
      const clamped = Math.max(20, Math.min(top + chartHeight - 8, y));
      const box = labelBox(x, clamped, text);
      if (!hasOverlap(box)) {
        labelBoxes.push(box);
        return clamped;
      }
    }
    return null;
  };
  const xTicks = buckets.map((bucket, index) => {
    const x = left + index * slot + 15;
    return `<line class="delay-x-tick" x1="${x}" y1="${top + chartHeight}" x2="${x}" y2="${top + chartHeight + 5}"></line>`;
  }).join("");
  const bars = buckets.map((bucket, index) => {
    const count = barByBucket.get(bucket.key) || 0;
    const x = left + index * slot + 6;
    const barHeight = count ? Math.max(2, (count / maxCount) * chartHeight) : 0;
    const y = top + chartHeight - barHeight;
    const valueY = count ? placeLabel(x + 9, y - 8, count, [y - 20, y + 18]) : null;
    const barValue = count && valueY !== null ? `<text class="delay-bar-value" x="${x + 9}" y="${valueY}">${count}</text>` : "";
    return `
      <g class="${count ? "delay-drill-point" : ""}" data-delay-drill="bar" data-delay-bucket="${bucket.key}" tabindex="${count ? "0" : "-1"}" role="${count ? "button" : "presentation"}" aria-label="${escapeHtml(`${barSeries.label} ${bucket.title} ${count} ${metricUnit}`)}">
        ${count ? `<rect class="delay-hit-area" x="${x - 3}" y="${top}" width="${slot}" height="${chartHeight}"></rect>` : ""}
        ${count ? `<rect class="delay-bar" x="${x}" y="${y}" width="18" height="${barHeight}" rx="3"></rect>${barValue}` : ""}
        <title>${barSeries.label}，${bucket.title}：${count} ${metricUnit}</title>
        ${bucket.label ? `<text class="delay-x-label" x="${x + 9}" y="${height - 18}">${bucket.label}</text>` : ""}
      </g>`;
  }).join("");
  const linePoints = buckets.map((bucket, index) => {
    const count = lineByBucket.get(bucket.key) || 0;
    const x = left + index * slot + 15;
    const y = top + chartHeight - (count / maxCount) * chartHeight;
    return { ...bucket, count, x, y };
  });
  const linePath = linePoints.length
    ? linePoints.map((point, index) => `${index ? "L" : "M"} ${point.x} ${point.y}`).join(" ")
    : "";
  const lineMarkers = linePoints.map((point, index) => {
    const showLabel = point.count > 0 && (linePoints.length <= 32 || index % Math.ceil(linePoints.length / 32) === 0);
    const labelY = showLabel ? placeLabel(point.x, point.y - 10, point.count, [point.y + 18, point.y - 24, point.y + 32]) : null;
    const labelClass = labelY !== null && labelY > point.y ? "delay-line-value is-below" : "delay-line-value";
    return `
      <g class="${point.count ? "delay-drill-point" : ""}" data-delay-drill="line" data-delay-bucket="${point.key}" tabindex="${point.count ? "0" : "-1"}" role="${point.count ? "button" : "presentation"}" aria-label="${escapeHtml(`${lineSeries.label} ${point.title} ${point.count} ${metricUnit}`)}">
        ${point.count ? `<circle class="delay-line-hit" cx="${point.x}" cy="${point.y}" r="11"></circle>` : ""}
        <circle class="delay-line-dot" cx="${point.x}" cy="${point.y}" r="4"></circle>
        ${labelY !== null ? `<text class="${labelClass}" x="${point.x}" y="${labelY}">${point.count}</text>` : ""}
        <title>${lineSeries.label}，${point.title}：${point.count} ${metricUnit}</title>
      </g>`;
  }).join("");
  const grid = yTicks.map((tick) => {
    const y = top + chartHeight - (tick / maxCount) * chartHeight;
    return `
      <line class="delay-grid-line" x1="${left}" y1="${y}" x2="${left + chartWidth}" y2="${y}"></line>
      <text class="delay-y-label" x="${left - 10}" y="${y + 4}">${tick}</text>`;
  }).join("");
  const statusNotes = [barSeries, lineSeries]
    .filter((series) => series.status !== "ready")
    .map((series) => `${series.label}：${series.status === "loading" ? "加载中" : series.message || "没有可用明细"}`);
  return `
    <div class="delay-chart-scroll">
      <svg class="delay-chart" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}" role="img" aria-label="延期规律，横轴延误天数，纵轴${metricLabel}">
        <text class="delay-axis-title" x="${left}" y="15">${cycleText} / ${metricLabel}</text>
        ${grid}
        <line class="delay-axis" x1="${left}" y1="${top + chartHeight}" x2="${left + chartWidth}" y2="${top + chartHeight}"></line>
        <line class="delay-axis" x1="${left}" y1="${top}" x2="${left}" y2="${top + chartHeight}"></line>
        ${xTicks}
        ${bars}
        ${linePath ? `<path class="delay-line" d="${linePath}"></path>${lineMarkers}` : ""}
        <text class="delay-axis-name" x="${left + chartWidth / 2}" y="${height - 2}">延误区间</text>
        <text class="delay-axis-name" transform="translate(14 ${top + chartHeight / 2}) rotate(-90)">${metricAxis}</text>
      </svg>
    </div>
    ${statusNotes.length ? `<div class="delay-chart-note">${statusNotes.join("；")}</div>` : ""}`;
}

function closeDelayDrillModal() {
  document.querySelector(".delay-drill-modal")?.remove();
}

function delayDrillOrderRowsHtml(rows, showCustomer) {
  return rows.map((record) => `
    <tr>
      ${showCustomer ? `<td>${escapeHtml(record.customerId || "")}</td><td>${escapeHtml(record.customerShortName || "")}</td>` : ""}
      <td>${escapeHtml(record.orderNo || "")}</td>
      <td class="center-cell">${escapeHtml(record.lineNo ?? "")}</td>
      <td>${escapeHtml(record.sku || "")}</td>
      <td title="${escapeHtml(record.spec || "")}">${escapeHtml(record.spec || "")}</td>
      <td class="name" title="${escapeHtml(record.name || "")}">${escapeHtml(record.name || "")}</td>
      <td class="num">${fmtNumber(record.unshippedQty)}</td>
      <td class="num">${record.availableStock ? fmtNumber(record.availableStock) : ""}</td>
      <td>${badge(record)}</td>
      <td class="center-cell">${fmtNumber(record.overdueDays)}</td>
      <td>${fmtDate(record.businessDueDate)}</td>
      <td>${fmtDate(normalizedPlanDueDate(record))}</td>
      <td>${escapeHtml(record.workOrderNo || "")}</td>
      <td class="name" title="${escapeHtml(record.productionProgress || record.workOrderStatus || "")}">${escapeHtml(record.productionProgress || record.workOrderStatus || "")}</td>
      <td>${escapeHtml(record.orderAttribute || "")}</td>
    </tr>
  `).join("");
}

function delayDrillOrderTableHtml(rows, showCustomer) {
  return `
    <div class="table-wrap delay-drill-table-wrap">
      <table class="delay-drill-table">
        <thead>
          <tr>
            ${showCustomer ? "<th>客户</th><th>客户简称</th>" : ""}
            <th>订单号</th><th>项次</th><th>SKU</th><th>规格</th><th>品名</th><th class="num">未出</th><th class="num">可用库存</th><th>状态</th><th>逾期天数</th><th>业务交期</th><th>承诺交期</th><th>工单号</th><th>生产进度</th><th>属性</th>
          </tr>
        </thead>
        <tbody>${delayDrillOrderRowsHtml(rows, showCustomer)}</tbody>
      </table>
    </div>`;
}

function delayDrillCustomerTableHtml(customers) {
  return `
    <div class="table-wrap delay-drill-table-wrap">
      <table class="delay-drill-table delay-customer-table">
        <thead>
          <tr>
            <th>客户</th><th>客户简称</th><th class="num">未交数量</th><th class="num">订单行</th><th class="num">订单张数</th><th class="num">产品数</th><th class="num">SKU数</th><th class="num">最长逾期</th><th>下钻</th>
          </tr>
        </thead>
        <tbody>
          ${customers.map((item) => `
            <tr>
              <td>${escapeHtml(item.customerId || "客户缺失")}</td>
              <td>${escapeHtml(item.customerShortName || "")}</td>
              <td class="num">${fmtNumber(item.qty)}</td>
              <td class="num">${fmtNumber(item.lines)}</td>
              <td class="num">${fmtNumber(item.orders)}</td>
              <td class="num">${fmtNumber(item.products)}</td>
              <td class="num">${fmtNumber(item.skus)}</td>
              <td class="num">${fmtNumber(item.maxDays)}天</td>
              <td><button class="delay-customer-drill-button" type="button" data-delay-customer="${escapeHtml(item.key)}">订单行</button></td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    </div>`;
}

function openDelayDrillModal(seriesKind, bucketKey, customerKey = "") {
  const drill = delayDrillRows(seriesKind, bucketKey);
  if (!drill.rows.length) {
    window.alert("当前图形点没有可下钻的订单明细。");
    return;
  }
  const showCustomer = canViewCustomerId();
  const allRows = drill.rows;
  const customerSummaries = summarizeDelayCustomers(allRows);
  const selectedCustomer = customerKey ? customerSummaries.find((item) => item.key === customerKey) : null;
  const rows = selectedCustomer ? selectedCustomer.rows : allRows;
  const totalUnshipped = rows.reduce((sum, record) => sum + Number(record.unshippedQty || 0), 0);
  const orderCount = new Set(rows.map((record) => `${record.customerId || ""}|${record.orderNo || ""}`).filter(Boolean)).size;
  const productCount = new Set(rows.map((record) => delayProductKey(record)).filter(Boolean)).size;
  const skuCount = new Set(rows.map((record) => record.sku || record.spec || record.name).filter(Boolean)).size;
  const customerMode = state.delayMetric === "customers" && !selectedCustomer;
  const modalTitle = selectedCustomer ? `${selectedCustomer.label}订单行明细` : `${drill.bucketTitle}明细`;
  const tableHtml = customerMode
    ? delayDrillCustomerTableHtml(customerSummaries)
    : delayDrillOrderTableHtml(rows, showCustomer);
  const metricDisplayCount = selectedCustomer && state.delayMetric === "customers"
    ? 1
    : customerMode ? customerSummaries.length : drill.metricCount;
  const backButton = selectedCustomer && state.delayMetric === "customers"
    ? `<button class="delay-drill-back-button" type="button" data-delay-customer-back>返回客户列表</button>`
    : "";
  const modal = document.createElement("div");
  modal.className = "delay-drill-modal";
  modal.tabIndex = -1;
  modal.innerHTML = `
    <div class="delay-drill-backdrop" data-close-delay-drill></div>
    <section class="delay-drill-page" role="dialog" aria-modal="true" aria-label="延期明细下钻">
      <header class="delay-drill-head">
        <div>
          <span>${escapeHtml(drill.seriesName)} / ${escapeHtml(drill.label || drill.date)}</span>
          <h2>${escapeHtml(modalTitle)}</h2>
        </div>
        <div class="delay-drill-head-actions">
          ${backButton}
          <button type="button" data-close-delay-drill title="关闭">×</button>
        </div>
      </header>
      <div class="delay-drill-stats">
        <span><strong>${fmtNumber(metricDisplayCount)}</strong><em>${escapeHtml(delayMetricLabel())}</em></span>
        <span><strong>${fmtNumber(rows.length)}</strong><em>订单行</em></span>
        <span><strong>${fmtNumber(orderCount)}</strong><em>订单张数</em></span>
        <span><strong>${fmtNumber(productCount)}</strong><em>产品数</em></span>
        <span><strong>${fmtNumber(skuCount)}</strong><em>SKU数</em></span>
        <span><strong>${fmtNumber(totalUnshipped)}</strong><em>未交数量</em></span>
      </div>
      ${tableHtml}
    </section>
  `;
  closeDelayDrillModal();
  document.body.appendChild(modal);
  modal.querySelectorAll("[data-close-delay-drill]").forEach((node) => node.addEventListener("click", closeDelayDrillModal));
  modal.querySelectorAll("[data-delay-customer]").forEach((button) => {
    button.addEventListener("click", () => openDelayDrillModal(seriesKind, bucketKey, button.dataset.delayCustomer));
  });
  modal.querySelector("[data-delay-customer-back]")?.addEventListener("click", () => openDelayDrillModal(seriesKind, bucketKey));
  modal.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeDelayDrillModal();
  });
  modal.querySelector("[data-close-delay-drill]")?.focus();
}

function renderSummary() {
  const overdue = getEnrichedRecords().filter((r) => r.status === "overdue");
  const showCustomer = canViewCustomerId();
  const topLimit = state.summaryTopLimit || 5;
  const customerTop = aggregate(overdue, (r) => r.customerId || "客户缺失").sort((a, b) => b.lines - a.lines).slice(0, topLimit);
  const productTop = aggregate(overdue, (r) => `${r.spec || "无规格"} / ${r.category4 || "未分类"}`).sort((a, b) => b.qty - a.qty).slice(0, topLimit);
  const stockHint = overdue.filter((r) => r.canShipFromStock).sort((a, b) => Number(b.unshippedQty || 0) - Number(a.unshippedQty || 0)).slice(0, 8);
  const datasets = delayDatasets();
  ensureDelayCompareDates(datasets);
  const barSeries = delaySeriesForDate(state.delayBarDate);
  const lineSeries = delaySeriesForDate(state.delayLineDate);
  const metricLabel = delayMetricLabel();
  const metricUnit = delayMetricUnit();
  const delayBarTotal = barSeries.total;
  const dateOptions = delayDateOptions(datasets, state.delayBarDate);
  const lineDateOptions = delayDateOptions(datasets, state.delayLineDate);
  const planAgain = overdue.filter((r) => {
    const plan = parseDate(normalizedPlanDueDate(r));
    const asOf = parseDate(state.asOfDate);
    return plan && plan < asOf;
  }).slice(0, 8);

  els.summary.innerHTML = `
    <div class="section-head">
      <h2>AI每日摘要雏形</h2>
      <span class="hint">当前为规则生成摘要，后续可接入真实 AI 文案与钉钉推送</span>
    </div>
    <div class="summary-item delay-pattern-card">
      <div class="summary-split">
        <div class="summary-chart-pane">
          <div class="delay-chart-head">
            <div>
              <strong>延期订单：延期规律</strong>
              <span>${metricLabel}：柱形图 ${barSeries.label || "-"} ${fmtNumber(delayBarTotal)} ${metricUnit}；折线图 ${lineSeries.label || "-"} ${fmtNumber(lineSeries.total)} ${metricUnit}</span>
            </div>
            <div class="delay-compare-controls">
              <div class="delay-metric-toggle" role="group" aria-label="延期图表Y轴指标">
                ${Object.entries(delayMetricDefs).map(([key, item]) => `<button class="delay-metric-button ${state.delayMetric === key ? "active" : ""}" type="button" data-delay-metric="${key}">${item.label}</button>`).join("")}
              </div>
              <button class="delay-chart-mode is-bar" type="button">柱形图</button>
              <label class="delay-cycle-control">
                日期
                <select id="delayBarDate">${dateOptions}</select>
              </label>
              <button class="delay-chart-mode is-line" type="button">折线图</button>
              <label class="delay-cycle-control">
                日期
                <select id="delayLineDate">${lineDateOptions}</select>
              </label>
              <label class="delay-cycle-control">
                设定周期
                <select id="delayCycle">
                  <option value="7" ${state.delayCycleDays === 7 ? "selected" : ""}>近 7 天</option>
                  <option value="15" ${state.delayCycleDays === 15 ? "selected" : ""}>近 15 天</option>
                  <option value="30" ${state.delayCycleDays === 30 ? "selected" : ""}>近 30 天</option>
                  <option value="60" ${state.delayCycleDays === 60 ? "selected" : ""}>近 60 天</option>
                  <option value="90" ${state.delayCycleDays === 90 ? "selected" : ""}>近 90 天</option>
                  <option value="all" ${state.delayCycleDays === "all" ? "selected" : ""}>全部</option>
                </select>
              </label>
            </div>
          </div>
          ${renderDelayPatternChart(barSeries, lineSeries, state.delayCycleDays)}
        </div>
        ${showCustomer ? `
          <div class="summary-split-divider" aria-hidden="true"></div>
          <aside class="summary-customer-pane">
            <div class="summary-top-toolbar" role="group" aria-label="摘要榜单数量">
              ${[3, 4, 5].map((limit) => `<button class="summary-top-button ${topLimit === limit ? "active" : ""}" type="button" data-summary-top="${limit}">TOP${limit}</button>`).join("")}
            </div>
            <strong>新增/当前逾期客户 TOP${topLimit}</strong>
            <ol>${customerTop.map((r) => `<li>${r.key}：${fmtNumber(r.lines)} 行，未交 ${fmtNumber(r.qty)}，最长逾期 ${fmtNumber(r.maxDays)} 天</li>`).join("")}</ol>
          </aside>` : ""}
      </div>
    </div>
    <div class="summary-list">
      ${showCustomer ? "" : `<div class="summary-top-toolbar" role="group" aria-label="摘要榜单数量">
        ${[3, 4, 5].map((limit) => `<button class="summary-top-button ${topLimit === limit ? "active" : ""}" type="button" data-summary-top="${limit}">TOP${limit}</button>`).join("")}
      </div>`}
      <div class="summary-item">
        <strong>逾期数量最高产品 TOP${topLimit}</strong>
        <ol>${productTop.map((r) => `<li>${r.key}：未交 ${fmtNumber(r.qty)}${showCustomer ? `，涉及 ${fmtNumber(r.customerCount)} 个客户` : ""}</li>`).join("")}</ol>
      </div>
      <div class="summary-item">
        <strong>库存优先核查</strong>
        <ul>${stockHint.length ? stockHint.map((r) => `<li>${r.orderNo}-${r.lineNo}，${r.spec}，未交 ${fmtNumber(r.unshippedQty)}，可用库存 ${fmtNumber(r.availableStock)}，仓库：${r.warehouses || "未标明"}</li>`).join("") : "<li>当前没有“可用库存 ≥ 未交数量”的逾期线索。</li>"}</ul>
      </div>
      <div class="summary-item">
        <strong>二次交期再次逾期</strong>
        <ul>${planAgain.length ? planAgain.map((r) => `<li>${r.orderNo}-${r.lineNo}，计划交期 ${fmtDate(normalizedPlanDueDate(r))}，业务交期 ${fmtDate(r.businessDueDate)}</li>`).join("") : "<li>当前没有二次交期已过的样例。</li>"}</ul>
      </div>
    </div>`;
  els.summary.querySelector("#delayCycle")?.addEventListener("change", (event) => {
    state.delayCycleDays = event.target.value === "all" ? "all" : Number(event.target.value);
    renderSummary();
  });
  els.summary.querySelector("#delayBarDate")?.addEventListener("change", (event) => {
    state.delayBarDate = event.target.value;
    renderSummary();
  });
  els.summary.querySelector("#delayLineDate")?.addEventListener("change", (event) => {
    state.delayLineDate = event.target.value;
    renderSummary();
  });
  els.summary.querySelectorAll("[data-delay-metric]").forEach((button) => {
    button.addEventListener("click", () => {
      state.delayMetric = button.dataset.delayMetric;
      renderSummary();
    });
  });
  els.summary.querySelectorAll("[data-summary-top]").forEach((button) => {
    button.addEventListener("click", () => {
      state.summaryTopLimit = Number(button.dataset.summaryTop);
      renderSummary();
    });
  });
  els.summary.querySelectorAll(".delay-drill-point").forEach((node) => {
    const open = () => openDelayDrillModal(node.dataset.delayDrill, node.dataset.delayBucket);
    node.addEventListener("click", open);
    node.addEventListener("keydown", (event) => {
      if (event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      open();
    });
  });
}

function renderCompare() {
  const datasets = [...state.dailyHistory].sort((a, b) => a.date.localeCompare(b.date));
  if (datasets.length < 2) {
    els.compare.innerHTML = `
      <div class="section-head">
        <h2>每日对比</h2>
        <span class="hint">至少需要两天数据后才能对比</span>
      </div>
      <div class="empty">当前只有 ${fmtNumber(datasets.length)} 天历史数据。继续导入每日三表后，这里会自动形成日对日对比。</div>`;
    return;
  }

  if (!state.compareFrom || !datasets.some((item) => item.date === state.compareFrom)) {
    state.compareFrom = datasets[datasets.length - 2].date;
  }
  if (!state.compareTo || !datasets.some((item) => item.date === state.compareTo)) {
    state.compareTo = datasets[datasets.length - 1].date;
  }
  if (state.compareFrom === state.compareTo) {
    state.compareFrom = datasets[datasets.length - 2].date;
    state.compareTo = datasets[datasets.length - 1].date;
  }

  const previous = datasets.find((item) => item.date === state.compareFrom) || datasets[datasets.length - 2];
  const current = datasets.find((item) => item.date === state.compareTo) || datasets[datasets.length - 1];
  const previousMetrics = previous.metrics || metricsFromRecords(previous.records || [], previous.date);
  const currentMetrics = current.metrics || metricsFromRecords(current.records || [], current.date);
  const dateOptions = datasets
    .map((item) => `<option value="${item.date}">${item.label || item.date}</option>`)
    .join("");
  const rows = [
    ["订单行数", "orders"],
    ["动态逾期行数", "overdueLines"],
    ["逾期未交数量", "overdueQty"],
    ["24天以上严重逾期", "severeLines"],
    ["有库存可优先出库", "stockReadyLines"],
    ["交期缺失", "missingDueLines"],
  ];
  if (canViewCustomerId()) rows.splice(3, 0, ["涉及客户", "customers"]);
  const compareRows = rows.map(([label, key]) => ({
    label,
    before: Number(previousMetrics[key] || 0),
    after: Number(currentMetrics[key] || 0),
    delta: Number(currentMetrics[key] || 0) - Number(previousMetrics[key] || 0),
  }));

  els.compare.innerHTML = `
    <div class="section-head">
      <div>
        <h2>每日对比</h2>
        <span class="hint">${previous.label || previous.date} → ${current.label || current.date}，按各自日期动态计算逾期</span>
      </div>
      <div class="compare-controls" aria-label="每日对比日期选择">
        <label class="compare-field">
          起始日期
          <select id="compareFrom">
            ${dateOptions}
          </select>
        </label>
        <label class="compare-field">
          对比日期
          <select id="compareTo">
            ${dateOptions}
          </select>
        </label>
      </div>
    </div>
    ${previous.note ? `<div class="compare-note">${previous.note}</div>` : ""}
    <div class="compare-cards">
      ${compareRows
        .slice(1, 6)
        .map((item) => {
          const trend = item.delta > 0 ? "up" : item.delta < 0 ? "down" : "flat";
          return `<article class="compare-card ${trend}">
            <span>${item.label}</span>
            <strong>${fmtNumber(item.after)}</strong>
            <em>较起始 ${fmtDelta(item.delta)}</em>
          </article>`;
        })
        .join("")}
    </div>
    <div class="table-wrap compare-table-wrap">
      <table class="compare-table">
        <thead>
          <tr><th>指标</th><th class="num">${previous.label || previous.date}</th><th class="num">${current.label || current.date}</th><th class="num">变化</th><th>判断</th></tr>
        </thead>
        <tbody>
          ${compareRows
            .map((item) => {
              const cls = item.delta > 0 ? "delta-up" : item.delta < 0 ? "delta-down" : "delta-flat";
              const trend = item.delta > 0 ? "增加" : item.delta < 0 ? "减少" : "持平";
              return `<tr>
                <td>${item.label}</td>
                <td class="num">${fmtNumber(item.before)}</td>
                <td class="num">${fmtNumber(item.after)}</td>
                <td class="num ${cls}">${fmtDelta(item.delta)}</td>
                <td>${trend}</td>
              </tr>`;
            })
            .join("")}
        </tbody>
      </table>
    </div>`;

  els.compare.querySelector("#compareFrom").value = previous.date;
  els.compare.querySelector("#compareTo").value = current.date;
  els.compare.querySelector("#compareFrom").addEventListener("change", (event) => {
    state.compareFrom = event.target.value;
    if (state.compareFrom === state.compareTo) {
      const index = datasets.findIndex((item) => item.date === state.compareFrom);
      state.compareTo = datasets[index + 1]?.date || datasets[index - 1]?.date || state.compareTo;
    }
    renderCompare();
  });
  els.compare.querySelector("#compareTo").addEventListener("change", (event) => {
    state.compareTo = event.target.value;
    if (state.compareFrom === state.compareTo) {
      const index = datasets.findIndex((item) => item.date === state.compareTo);
      state.compareFrom = datasets[index - 1]?.date || datasets[index + 1]?.date || state.compareFrom;
    }
    renderCompare();
  });
}

const DELIVERY_STATUS_SERIES = [
  { key: "逾未入", color: "#b42318" },
  { key: "逾部分入", color: "#f97316" },
  { key: "逾已入", color: "#0f766e" },
  { key: "逾拿货", color: "#2563eb" },
  { key: "未逾期", color: "#7c3aed" },
];
const DELIVERY_TREND_SERIES = DELIVERY_STATUS_SERIES.filter((series) => series.key !== "未逾期");

function deliveryStatusOrders(records, asOfDate) {
  const priority = new Map(DELIVERY_STATUS_SERIES.map((item, index) => [item.key, index]));
  const orders = new Map();
  for (const source of records || []) {
    const record = enrichForDate(source, asOfDate);
    if (!matchesGlobalFilters(record) || !priority.has(record.statusText) || !record.orderNo) continue;
    if (!orders.has(record.orderNo)) {
      orders.set(record.orderNo, {
        orderNo: record.orderNo, status: record.statusText, lines: 0, skus: new Set(),
        customers: new Set(), customerNames: new Set(), orderQty: 0, unshippedQty: 0, maxDays: 0,
        businessDueDate: "", planner: new Set(), salesPerson: new Set(),
      });
    }
    const order = orders.get(record.orderNo);
    if (priority.get(record.statusText) < priority.get(order.status)) order.status = record.statusText;
    order.lines += 1;
    if (record.sku) order.skus.add(record.sku);
    if (record.customerId) order.customers.add(record.customerId);
    if (record.customerShortName) order.customerNames.add(record.customerShortName);
    if (record.planner) order.planner.add(record.planner);
    if (record.salesPerson) order.salesPerson.add(record.salesPerson);
    order.orderQty += Number(record.orderQty || 0);
    order.unshippedQty += Number(record.unshippedQty || 0);
    order.maxDays = Math.max(order.maxDays, Number(record.overdueDays || 0));
    const dueDate = fmtDate(record.businessDueDate);
    if (dueDate && (!order.businessDueDate || dueDate < order.businessDueDate)) order.businessDueDate = dueDate;
  }
  return [...orders.values()].map((order) => ({
    ...order, skuCount: order.skus.size, customerText: [...order.customers].join("、"),
    customerNameText: [...order.customerNames].join("、"), plannerText: [...order.planner].join("、"),
    salesPersonText: [...order.salesPerson].join("、"),
  }));
}

function deliveryStatusCounts(orders) {
  const counts = new Map(DELIVERY_STATUS_SERIES.map((item) => [item.key, 0]));
  for (const order of orders) counts.set(order.status, (counts.get(order.status) || 0) + 1);
  return counts;
}

function statusCompositionRecords() {
  const statuses = new Set(DELIVERY_STATUS_SERIES.map((series) => series.key));
  const asOf = parseDate(state.asOfDate);
  const records = state.statusDueBasis === "business"
    ? state.records.map((record) => ({ ...record, ...getDerived(record, asOf, "business") }))
    : getEnrichedRecords();
  return records.filter((record) => matchesGlobalFilters(record) && statuses.has(record.statusText));
}

function statusDueBasisLabel() {
  return state.statusDueBasis === "business" ? "业务交期" : "承诺交期";
}

const statusSnapshotCountsCache = new WeakMap();

function statusSnapshotForDate(item) {
  const date = item.date;
  let payload;
  if (date === state.asOfDate) payload = { records: state.records, asOfDate: state.asOfDate };
  else if (state.delayDatasetCache.has(date)) payload = state.delayDatasetCache.get(date);
  else if (item.file) { requestDelayDataset(date); return null; }
  if (!payload || payload.error) return null;
  const records = payload.records || [];
  const asOfDate = payload.asOfDate || date;
  const signature = `${globalFilterSignature()}|${state.statusDueBasis}`;
  let cached = statusSnapshotCountsCache.get(records);
  if (!cached || cached.date !== asOfDate || cached.signature !== signature) {
    // Count each source order line in its own status, without order-level risk merging.
    const counts = new Map(DELIVERY_STATUS_SERIES.map((series) => [series.key, 0]));
    const asOf = parseDate(asOfDate);
    for (const source of records) {
      const derived = getDerived(source, asOf, state.statusDueBasis);
      if (!matchesGlobalFilters(source, derived) || !counts.has(derived.statusText)) continue;
      counts.set(derived.statusText, counts.get(derived.statusText) + 1);
    }
    cached = { date: asOfDate, signature, counts };
    statusSnapshotCountsCache.set(records, cached);
  }
  return { date, label: item.label || labelForIsoDate(date), counts: cached.counts };
}

function mondayIso(dateText) {
  const date = parseDate(dateText);
  if (!date) return dateText;
  const day = date.getDay() || 7;
  date.setDate(date.getDate() - day + 1);
  return dateIso(date);
}

function calendarWeekInfo(dateText) {
  const date = new Date(`${dateText}T00:00:00Z`);
  const monday = new Date(date);
  monday.setUTCDate(date.getUTCDate() - (date.getUTCDay() || 7) + 1);
  const sunday = new Date(monday);
  sunday.setUTCDate(monday.getUTCDate() + 6);
  // ISO weeks belong to the year containing their Thursday, including year boundaries.
  const thursday = new Date(monday);
  thursday.setUTCDate(monday.getUTCDate() + 3);
  const year = thursday.getUTCFullYear();
  const week = Math.ceil(((thursday - Date.UTC(year, 0, 1)) / DAY + 1) / 7);
  return { year, week, start: monday.toISOString().slice(0, 10), end: sunday.toISOString().slice(0, 10), label: `${year}年第${week}周` };
}

function deliveryTrendPoints() {
  const datasets = delayDatasets();
  if (state.statusTrendMode === "daily") {
    return datasets.slice(-30).map(statusSnapshotForDate).filter(Boolean);
  }
  if (state.statusTrendMode === "monthly") {
    const monthlyItems = new Map();
    for (const item of datasets) monthlyItems.set(item.date.slice(0, 7), item);
    return [...monthlyItems.entries()].slice(-12).map(([month, item]) => {
      const snapshot = statusSnapshotForDate(item);
      if (!snapshot) return null;
      return { ...snapshot, label: month, tooltipLabel: `${month}（快照 ${snapshot.date}）` };
    }).filter(Boolean);
  }
  const weeklyItems = new Map();
  for (const item of datasets) weeklyItems.set(mondayIso(item.date), item);
  return [...weeklyItems.entries()].slice(-12).map(([week, item]) => {
    const snapshot = statusSnapshotForDate(item);
    if (!snapshot) return null;
    const calendar = calendarWeekInfo(week);
    return { ...snapshot, label: calendar.label, weekStart: calendar.start, weekEnd: calendar.end,
      tooltipLabel: `${calendar.label}（${calendar.start} 至 ${calendar.end}；快照 ${snapshot.date}）` };
  }).filter(Boolean);
}

function piePoint(cx, cy, radius, angle) {
  const radians = (angle - 90) * Math.PI / 180;
  return [cx + radius * Math.cos(radians), cy + radius * Math.sin(radians)];
}

function piePath(cx, cy, radius, innerRadius, start, end) {
  if (end - start >= 360) {
    return `M ${cx} ${cy - radius} A ${radius} ${radius} 0 1 1 ${cx} ${cy + radius} A ${radius} ${radius} 0 1 1 ${cx} ${cy - radius} Z M ${cx} ${cy - innerRadius} A ${innerRadius} ${innerRadius} 0 1 0 ${cx} ${cy + innerRadius} A ${innerRadius} ${innerRadius} 0 1 0 ${cx} ${cy - innerRadius} Z`;
  }
  const [sx, sy] = piePoint(cx, cy, radius, start);
  const [ex, ey] = piePoint(cx, cy, radius, end);
  const [ix, iy] = piePoint(cx, cy, innerRadius, end);
  const [jx, jy] = piePoint(cx, cy, innerRadius, start);
  const largeArc = end - start > 180 ? 1 : 0;
  return `M ${sx} ${sy} A ${radius} ${radius} 0 ${largeArc} 1 ${ex} ${ey} L ${ix} ${iy} A ${innerRadius} ${innerRadius} 0 ${largeArc} 0 ${jx} ${jy} Z`;
}

function renderDeliveryPie(counts) {
  const total = [...counts.values()].reduce((sum, value) => sum + value, 0);
  if (!total) return `<div class="empty status-analysis-empty">当前筛选下没有五类状态订单行</div>`;
  let angle = 0;
  const slices = DELIVERY_STATUS_SERIES.map((series) => {
    const count = counts.get(series.key) || 0;
    const start = angle;
    angle += count / total * 360;
    if (!count) return "";
    const offset = count < total && ["逾未入", "逾部分入"].includes(series.key) ? 10 : 0;
    const [dx, dy] = piePoint(0, 0, offset, (start + angle) / 2);
    const shape = `<path d="${piePath(120, 120, 88, 51, start, angle)}"></path>`;
    return `<g class="delivery-pie-slice" transform="translate(${dx} ${dy})" data-delivery-status="${series.key}" tabindex="0" role="button" aria-label="${series.key} ${count} 行，占 ${(count / total * 100).toFixed(1)}%" style="fill:${series.color}">${shape}<title>${series.key}：${fmtNumber(count)} 行，${(count / total * 100).toFixed(1)}%</title></g>`;
  }).join("");
  return `<svg class="delivery-pie" viewBox="-18 -18 276 276" role="img" aria-label="五类交付状态订单行占比">${slices}<text class="delivery-pie-total" x="120" y="116">${fmtNumber(total)}</text><text class="delivery-pie-caption" x="120" y="138">订单行</text></svg>`;
}

function bindStatusPieTooltips(records) {
  const counts = new Map(DELIVERY_STATUS_SERIES.map((series) => [series.key, { ready: 0, short: 0, unknown: 0, noNotice: 0, prefix3005: 0, withWork: 0, withoutWork: 0 }]));
  for (const record of records) {
    const group = counts.get(record.statusText);
    if (!group) continue;
    const key = String(record.shipmentNoticeNo || "").trim() ? orderKittingStatus(record.orderNo) : "noNotice";
    group[key] += 1;
    if (String(record.orderNo || "").trim().startsWith("3005")) group.prefix3005 += 1;
    else group[String(record.workOrderNo || "").trim() ? "withWork" : "withoutWork"] += 1;
  }
  const tooltip = document.createElement("div");
  tooltip.id = "statusPieTooltip";
  tooltip.className = "customer-order-tooltip status-pie-tooltip";
  tooltip.setAttribute("role", "tooltip");
  tooltip.hidden = true;
  els.statusAnalysis.appendChild(tooltip);
  let active = null, hideTimer = 0;
  const hide = () => {
    clearTimeout(hideTimer);
    active?.removeAttribute("aria-describedby");
    active = null;
    tooltip.hidden = true;
  };
  const show = (node, event) => {
    clearTimeout(hideTimer);
    active?.removeAttribute("aria-describedby");
    active = node;
    node.setAttribute("aria-describedby", tooltip.id);
    const status = node.dataset.deliveryStatus, group = counts.get(status);
    const production = ["逾未入", "逾部分入"].includes(status);
    const fields = production
      ? [["withWork", "有工单号"], ["withoutWork", "无工单号"], ["prefix3005", "3005"]]
      : [["ready", "有出通单齐套"], ["short", "有出通单不齐套"], ["noNotice", "无出通单"]];
    if (!production) {
      if (group.unknown) fields.push(["unknown", "有出通单未确定"]);
      if (!["逾已入", "逾拿货"].includes(status)) fields.push(["prefix3005", "其中：3005开头"]);
    }
    const total = group.ready + group.short + group.unknown + group.noNotice;
    tooltip.innerHTML = `<strong>${escapeHtml(status)} · ${fmtNumber(total)} 行</strong><dl>${fields.map(([key, label]) => `<div data-pie-breakdown="${key}"><dt>${label}</dt><dd>${fmtNumber(group[key])} 行</dd></div>`).join("")}</dl>`;
    tooltip.hidden = false;
    const rect = node.getBoundingClientRect();
    const x = event?.clientX ?? rect.right, y = event?.clientY ?? rect.top;
    tooltip.style.left = `${Math.max(8, Math.min(x + 14, innerWidth - tooltip.offsetWidth - 8))}px`;
    tooltip.style.top = `${Math.max(8, Math.min(y + 14, innerHeight - tooltip.offsetHeight - 8))}px`;
  };
  els.statusAnalysis.querySelectorAll(".delivery-pie-slice").forEach((node) => {
    node.querySelector("title")?.remove();
    node.addEventListener("pointerenter", (event) => show(node, event));
    node.addEventListener("pointerleave", (event) => {
      if (!tooltip.contains(event.relatedTarget)) hideTimer = setTimeout(hide, 180);
    });
    node.addEventListener("focus", () => show(node));
    node.addEventListener("blur", hide);
    node.addEventListener("click", hide);
    node.addEventListener("keydown", (event) => { if (["Escape", "Enter", " "].includes(event.key)) hide(); });
  });
  tooltip.addEventListener("pointerenter", () => clearTimeout(hideTimer));
  tooltip.addEventListener("pointerleave", hide);
  els.statusAnalysis.closest(".panel").onscroll = hide;
}

function deliveryTrendScale(maxValue) {
  const target = Math.max(1, maxValue / 4);
  const magnitude = 10 ** Math.floor(Math.log10(target));
  const step = [1, 2, 5, 10].find((factor) => factor * magnitude >= target) * magnitude;
  const ceiling = Math.max(step, Math.ceil(maxValue / step) * step);
  return { step, ceiling };
}

function renderDeliveryTrend(points) {
  if (!points.length) return `<div class="empty status-analysis-empty">正在加载历史趋势数据</div>`;
  const maxValue = Math.max(0, ...points.flatMap((point) => DELIVERY_TREND_SERIES.map((series) => point.counts.get(series.key) || 0)));
  const labelWidth = fmtNumber(maxValue).length * 7;
  const weekLabelWidth = Math.max(0, ...points.map((point) => point.weekStart ? point.label.length * 10 : 0));
  const height = 300, left = Math.max(54, labelWidth / 2 + 8, weekLabelWidth / 2 + 8), right = Math.max(36, labelWidth / 2 + 8, weekLabelWidth / 2 + 8), top = 42, bottom = 46;
  const width = Math.max(680, left + right + points.length * Math.max(72, labelWidth + 16, weekLabelWidth + 20));
  const chartWidth = width - left - right, chartHeight = height - top - bottom;
  const { step, ceiling } = deliveryTrendScale(maxValue);
  const x = (index) => left + (points.length === 1 ? chartWidth / 2 : index * chartWidth / (points.length - 1));
  const y = (value) => top + chartHeight - value / ceiling * chartHeight;
  const ticks = Array.from({ length: Math.round(ceiling / step) + 1 }, (_, index) => {
    const value = index * step, ty = y(value);
    return `<line class="delivery-trend-grid" x1="${left}" y1="${ty}" x2="${left + chartWidth}" y2="${ty}"></line><text class="delivery-trend-y" x="${left - 8}" y="${ty + 4}">${fmtNumber(value)}</text>`;
  }).join("");
  const lines = DELIVERY_TREND_SERIES.map((series) => {
    const coordinates = points.map((point, index) => `${x(index)},${y(point.counts.get(series.key) || 0)}`).join(" ");
    const dots = points.map((point, index) => {
      const value = point.counts.get(series.key) || 0;
      return `<circle cx="${x(index)}" cy="${y(value)}" r="3.5"><title>${escapeHtml(point.tooltipLabel || point.label)} · ${series.key}：${fmtNumber(value)} 行</title></circle>`;
    }).join("");
    return `<g class="delivery-trend-series" style="--series-color:${series.color}"><polyline points="${coordinates}"></polyline>${dots}</g>`;
  }).join("");
  const labels = points.map((point, index) => `<text class="delivery-trend-x" x="${x(index)}" y="${height - 17}">${escapeHtml(point.label)}</text>`).join("");
  const values = points.map((point, index) => {
    const entries = DELIVERY_TREND_SERIES.map((series) => {
      const value = point.counts.get(series.key) || 0;
      return { series, value, dotY: y(value), labelY: Math.max(30, y(value) - 10) };
    }).sort((a, b) => a.dotY - b.dotY);
    // Separate labels at the same date, including coincident and zero values.
    for (let i = 1; i < entries.length; i += 1) entries[i].labelY = Math.max(entries[i].labelY, entries[i - 1].labelY + 16);
    entries[entries.length - 1].labelY = Math.min(entries[entries.length - 1].labelY, top + chartHeight - 10);
    for (let i = entries.length - 2; i >= 0; i -= 1) entries[i].labelY = Math.min(entries[i].labelY, entries[i + 1].labelY - 16);
    const leaders = entries.map(({ series, dotY, labelY }) => Math.abs(labelY - (dotY - 10)) > 2 ? `<line style="--series-color:${series.color}" class="delivery-trend-value-leader" x1="${x(index)}" y1="${dotY - 4}" x2="${x(index)}" y2="${labelY + 3}"></line>` : "").join("");
    const numbers = entries.map(({ series, value, labelY }) => `<text style="--series-color:${series.color}" class="delivery-trend-value" x="${x(index)}" y="${labelY}" data-series="${series.key}">${fmtNumber(value)}</text>`).join("");
    return `<g class="delivery-trend-annotation">${leaders}${numbers}</g>`;
  }).join("");
  return `<div class="delivery-trend-scroll"><svg class="delivery-trend" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}" role="img" aria-label="四类逾期状态订单行趋势"><text class="customer-bar-axis" x="${left}" y="15">订单行数（行）</text>${ticks}<line class="delivery-trend-axis" x1="${left}" y1="${top + chartHeight}" x2="${left + chartWidth}" y2="${top + chartHeight}"></line>${lines}${labels}${values}</svg></div>`;
}

function closeStatusDrill() { document.querySelector(".status-drill-modal")?.remove(); }

function statusDrillBreakdown(status, records) {
  const shipping = ["逾已入", "逾拿货"].includes(status);
  const production = ["逾未入", "逾部分入"].includes(status);
  if (!shipping && !production) return [];
  const definitions = shipping
    ? [["ready", "有出通单齐套"], ["short", "有出通单不齐套"], ["unknown", "有出通单未确定"], ["noNotice", "无出通单"]]
    : [["withWork", "有工单号"], ["withoutWork", "无工单号"], ["3005", "3005"]];
  const groups = definitions.map(([key, label]) => ({ key, label, records: new Set() }));
  const byKey = new Map(groups.map((group) => [group.key, group]));
  for (const record of records) {
    let key;
    if (shipping) {
      key = String(record.shipmentNoticeNo || "").trim() ? orderKittingStatus(record.orderNo) : "noNotice";
    } else {
      key = String(record.orderNo || "").trim().startsWith("3005") ? "3005"
        : String(record.workOrderNo || "").trim() ? "withWork" : "withoutWork";
    }
    byKey.get(key).records.add(record);
  }
  return groups;
}

function openStatusDrill(status, options = {}) {
  const records = (options.records || statusCompositionRecords()).filter((record) => status == null || record.statusText === status)
    .sort((a, b) => b.overdueDays - a.overdueDays || Number(b.unshippedQty || 0) - Number(a.unshippedQty || 0)
      || columnValueCollator.compare(String(a.orderNo || ""), String(b.orderNo || "")) || columnValueCollator.compare(String(a.lineNo ?? ""), String(b.lineNo ?? "")));
  const orderCount = new Set(records.map((record) => record.orderNo).filter(Boolean)).size;
  const columns = (options.columns || orderExportColumns(true)).map((column) => ({
    ...column,
    label: column.label === "未出" ? "未出数量" : column.label,
    width: column.width || (column.numeric ? 110 : column.label === "项次" ? 65 : ["品名", "规格", "工单号", "出通单号"].includes(column.label) ? 200 : column.label === "订单号" ? 170 : 140),
  }));
  const rows = records.map((record) => ({ record, values: columns.map((column) => {
    const value = column.value(record);
    return column.numeric && value !== "" ? fmtNumber(value) : String(value ?? "");
  }) }));
  const breakdown = options.breakdown === false ? [] : statusDrillBreakdown(status, records);
  let page = 0, query = "", category = "all";
  const pageSize = 100;
  const previousFocus = document.activeElement;
  const modal = document.createElement("div");
  modal.className = "delay-drill-modal status-drill-modal";
  modal.tabIndex = -1;
  modal.innerHTML = `<div class="delay-drill-backdrop" data-close-status-drill></div><section class="delay-drill-page" role="dialog" aria-modal="true" aria-label="${escapeHtml(status)}订单明细"><header class="delay-drill-head"><div><span>${escapeHtml(options.context || `${state.asOfDate} · 按明细行自身交付状态归类 · 与饼图筛选一致`)}</span><h2>${escapeHtml(options.heading || status)} / ${fmtNumber(rows.length)} 行 · ${fmtNumber(orderCount)} 单</h2></div><button type="button" data-close-status-drill title="关闭">×</button></header><div class="kpi-drill-toolbar"><form class="customer-order-search"><input type="search" aria-label="订单明细搜索" placeholder="订单号 / SKU / 关键词"/><button type="submit">查询</button></form></div><div class="table-wrap delay-drill-table-wrap"><table class="delay-drill-table status-drill-table" style="width:${columns.reduce((sum, column) => sum + column.width, 0)}px"><colgroup>${columns.map((column) => `<col style="width:${column.width}px">`).join("")}</colgroup><thead><tr>${columns.map((column) => `<th${column.numeric ? ' class="num"' : ""}>${escapeHtml(column.label)}</th>`).join("")}</tr></thead><tbody></tbody></table></div><footer class="customer-orders-pagination"><span aria-live="polite"></span><button type="button" data-status-prev title="上一页" aria-label="上一页">‹</button><button type="button" data-status-next title="下一页" aria-label="下一页">›</button></footer></section>`;
  const draw = () => {
    const group = breakdown.find((item) => item.key === category);
    const filtered = rows.filter((row) => (!group || group.records.has(row.record))
      && (!query || row.values.some((value) => value.toLocaleLowerCase().includes(query))));
    modal.querySelectorAll("[data-status-category]").forEach((button) => button.setAttribute("aria-pressed", String(button.dataset.statusCategory === category)));
    const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
    page = Math.min(page, pages - 1);
    modal.querySelector("tbody").innerHTML = filtered.length ? filtered.slice(page * pageSize, (page + 1) * pageSize).map((row) => `<tr>${row.values.map((value, index) => `<td${columns[index].numeric ? ' class="num"' : ""} title="${escapeHtml(value)}">${escapeHtml(value)}</td>`).join("")}</tr>`).join("") : `<tr><td colspan="${columns.length}" class="empty-cell">没有匹配的订单明细</td></tr>`;
    modal.querySelector("footer span").textContent = `${page + 1} / ${pages} 页 · ${fmtNumber(new Set(filtered.map((row) => row.record.orderNo)).size)} 单 · ${fmtNumber(filtered.length)} 行 · 每页 ${pageSize} 行`;
    modal.querySelector("[data-status-prev]").disabled = page === 0;
    modal.querySelector("[data-status-next]").disabled = page + 1 === pages;
    if (!modal.contains(document.activeElement) || document.activeElement.disabled) modal.querySelector("input").focus();
    modal.querySelector(".table-wrap").scrollTop = 0;
  };
  const close = () => { closeStatusDrill(); if (previousFocus?.isConnected) previousFocus.focus(); };
  modal.querySelector('[role="dialog"]').setAttribute("aria-label", `${options.heading || status}订单明细`);
  if (!options.context) modal.querySelector(".delay-drill-head span").textContent = `${state.asOfDate} · ${statusDueBasisLabel()} · 按明细行自身交付状态归类 · 与饼图筛选一致`;
  closeStatusDrill();
  document.body.appendChild(modal);
  if (breakdown.length) {
    const choices = [{ key: "all", label: "全部", records: new Set(records) }, ...breakdown];
    modal.querySelector(".kpi-drill-toolbar").insertAdjacentHTML("beforebegin", `<div class="status-drill-breakdown" role="group" aria-label="订单行分类">${choices.map((group) => `<button type="button" data-status-category="${group.key}" aria-pressed="${group.key === "all"}"><span>${group.label}</span><strong>${fmtNumber(group.records.size)}</strong>行</button>`).join("")}</div>`);
    modal.querySelectorAll("[data-status-category]").forEach((button) => button.addEventListener("click", () => {
      category = button.dataset.statusCategory;
      page = 0;
      draw();
    }));
  }
  modal.querySelectorAll("[data-close-status-drill]").forEach((node) => node.addEventListener("click", close));
  modal.querySelector("form").addEventListener("submit", (event) => { event.preventDefault(); query = modal.querySelector("input").value.trim().toLocaleLowerCase(); page = 0; draw(); });
  modal.querySelector("[data-status-prev]").addEventListener("click", () => { page -= 1; draw(); });
  modal.querySelector("[data-status-next]").addEventListener("click", () => { page += 1; draw(); });
  modal.addEventListener("keydown", (event) => {
    if (event.key === "Escape") close();
    if (event.key === "Tab") {
      const focusable = [...modal.querySelectorAll("button:not(:disabled), input")];
      const first = focusable[0], last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  draw();
  modal.querySelector("[data-close-status-drill][type=button]").focus();
}

function renderStatusAnalysis() {
  const records = statusCompositionRecords();
  const counts = new Map(DELIVERY_STATUS_SERIES.map((series) => [series.key, 0]));
  const skus = new Map(DELIVERY_STATUS_SERIES.map((series) => [series.key, new Set()]));
  for (const record of records) {
    counts.set(record.statusText, counts.get(record.statusText) + 1);
    const sku = String(record.sku ?? "").trim();
    if (sku) skus.get(record.statusText).add(sku);
  }
  const total = records.length, points = deliveryTrendPoints();
  els.statusAnalysis.innerHTML = `<div class="section-head"><div><h2>状态分析</h2><span class="hint">${state.asOfDate} · 占比与趋势均按订单行统计</span></div></div><div class="status-analysis-layout"><section class="status-composition-pane"><div class="status-pane-head"><h3>订单行状态占比</h3><span>不含交期缺失和已交完</span></div><div class="delivery-pie-wrap">${renderDeliveryPie(counts)}</div><div class="delivery-status-legend"><div class="delivery-status-legend-head"><span class="delivery-status-heading">状态</span><span>SKU去重数</span><span>订单行数</span><span>占比</span></div>${DELIVERY_STATUS_SERIES.map((series) => { const count = counts.get(series.key) || 0; return `<button type="button" data-delivery-status="${series.key}" aria-label="${series.key} ${count} 行，SKU去重 ${skus.get(series.key).size} 个"><i style="background:${series.color}"></i><span>${series.key}</span><span class="delivery-status-sku-count" title="当前状态内非空SKU去重数量">${fmtNumber(skus.get(series.key).size)}</span><strong>${fmtNumber(count)}</strong><em>${total ? (count / total * 100).toFixed(1) : "0.0"}%</em></button>`; }).join("")}</div></section><div class="status-analysis-divider"></div><section class="status-trend-pane"><div class="status-pane-head"><div><h3>预期订单状态趋势</h3><span>${state.statusTrendMode === "monthly" ? "最近12个月 · 每月最后一份快照" : state.statusTrendMode === "weekly" ? "最近12周 · 每周最后一份快照" : "最近30个每日快照"}</span></div><div class="status-trend-toggle" aria-label="趋势周期"><button type="button" data-status-trend-mode="daily" class="${state.statusTrendMode === "daily" ? "active" : ""}">每天</button><button type="button" data-status-trend-mode="weekly" class="${state.statusTrendMode === "weekly" ? "active" : ""}">每周</button><button type="button" data-status-trend-mode="monthly" class="${state.statusTrendMode === "monthly" ? "active" : ""}">每月</button></div></div><div class="delivery-trend-legend">${DELIVERY_TREND_SERIES.map((series) => `<span><i style="background:${series.color}"></i>${series.key}</span>`).join("")}</div>${renderDeliveryTrend(points)}</section></div>`;
  const head = els.statusAnalysis.querySelector(".section-head");
  head.classList.add("status-analysis-head");
  head.querySelector(".hint").textContent = `${state.asOfDate} · ${statusDueBasisLabel()} · 占比与趋势均按订单行统计`;
  head.insertAdjacentHTML("beforeend", `<div class="status-trend-toggle status-due-basis" role="group" aria-label="交期口径">${[["plan", "承诺交期"], ["business", "业务交期"]].map(([key, label]) => `<button type="button" data-status-due-basis="${key}" aria-pressed="${state.statusDueBasis === key}" class="${state.statusDueBasis === key ? "active" : ""}">${label}</button>`).join("")}</div>`);
  head.querySelectorAll("[data-status-due-basis]").forEach((button) => button.addEventListener("click", () => {
    state.statusDueBasis = button.dataset.statusDueBasis;
    renderStatusAnalysis();
    els.statusAnalysis.querySelector(`[data-status-due-basis="${state.statusDueBasis}"]`).focus();
  }));
  els.statusAnalysis.querySelectorAll("[data-delivery-status]").forEach((node) => {
    const open = () => openStatusDrill(node.dataset.deliveryStatus);
    node.addEventListener("click", open);
    node.addEventListener("keydown", (event) => { if (["Enter", " "].includes(event.key)) { event.preventDefault(); open(); } });
  });
  els.statusAnalysis.querySelectorAll("[data-status-trend-mode]").forEach((button) => button.addEventListener("click", () => { state.statusTrendMode = button.dataset.statusTrendMode; renderStatusAnalysis(); }));
  bindStatusPieTooltips(records);
}

const CUSTOMER_ORDER_SERIES = [
  { key: "逾已入", color: "#0f766e" },
  { key: "逾拿货", color: "#2563eb" },
];
const CUSTOMER_KITTING_SERIES = [
  { key: "ready", label: "齐套", color: "#0f766e" },
  { key: "short", label: "非齐套", color: "#d97706" },
  { key: "unknown", label: "未确定", color: "#7b8492" },
];

function customerOrderKittingKey(order) {
  return order.kittingText === "齐套" ? "ready" : order.kittingText === "未齐套" ? "short" : "unknown";
}

function customerKittingCounts(orders) {
  const counts = { ready: 0, short: 0, unknown: 0 };
  for (const order of orders) counts[customerOrderKittingKey(order)] += 1;
  return counts;
}

function customerOrderGroups() {
  const notices = new Map();
  for (const record of state.records) {
    const value = String(record.shipmentNoticeNo || "").trim();
    if (!value) continue;
    if (!notices.has(record.orderNo)) notices.set(record.orderNo, new Set());
    notices.get(record.orderNo).add(value);
  }
  const groups = new Map();
  for (const order of deliveryStatusOrders(state.records, state.asOfDate)) {
    if (!CUSTOMER_ORDER_SERIES.some((series) => series.key === order.status)) continue;
    order.noticeText = [...(notices.get(order.orderNo) || [])].join("、");
    order.kittingText = kittingReferenceStatusText(kittingReferenceFor(order.orderNo));
    const key = order.customerText || order.customerNameText || "客户未标明";
    if (!groups.has(key)) groups.set(key, {
      key, label: order.customerNameText || order.customerText || "客户未标明", orders: [],
    });
    groups.get(key).orders.push(order);
  }
  return [...groups.values()];
}
function customerOrderMonths(groups) {
  const months = new Map();
  for (const group of groups) {
    for (const order of group.orders) {
      const match = /^(\d{4}-(?:0[1-9]|1[0-2]))-\d{2}$/.exec(order.businessDueDate);
      const key = match ? match[1] : "交期缺失";
      if (!months.has(key)) months.set(key, { key, label: key, orders: [] });
      months.get(key).orders.push(order);
    }
  }
  return [...months.values()].sort((a, b) => {
    if (a.key === "交期缺失") return 1;
    if (b.key === "交期缺失") return -1;
    return a.key.localeCompare(b.key);
  });
}

function renderCustomerOrderBars(groups, byMonth = false) {
  const width = Math.max(700, 64 + groups.length * 112), height = byMonth ? 300 : 390;
  const axisLabel = byMonth ? "业务交期月份" : "客户";
  const barAttribute = byMonth ? "data-month-bar" : "data-customer-bar";
  const left = 54, top = 32, bottom = height - 98, plotWidth = width - left - 16;
  const values = groups.map((group) => group.orders.length);
  const step = Math.max(1, Math.ceil(Math.max(0, ...values) / 4)), ceiling = step * 4;
  const y = (value) => bottom - value / ceiling * (bottom - top);
  const ticks = Array.from({ length: 5 }, (_, index) => {
    const value = index * step, py = y(value);
    return `<line x1="${left}" y1="${py}" x2="${width - 16}" y2="${py}" class="delivery-trend-grid"/><text x="${left - 8}" y="${py + 4}" class="delivery-trend-y">${fmtNumber(value)}</text>`;
  }).join("");
  const columns = groups.map((group, index) => {
    const cx = left + (index + .5) * plotWidth / groups.length;
    const value = values[index], x = cx - 18;
    const counts = customerKittingCounts(group.orders);
    const smallLabels = [];
    let cumulative = 0;
    const segments = CUSTOMER_KITTING_SERIES.map((series) => {
      const count = counts[series.key], base = cumulative;
      cumulative += count;
      if (!count) return "";
      const segmentHeight = y(base) - y(cumulative), middle = (y(base) + y(cumulative)) / 2;
      const ratio = count / value * 100;
      const percent = ratio < .1 ? "<0.1%" : `${Number(ratio.toFixed(1))}%`;
      const label = (labelX, labelY, external = false) => `<text class="customer-bar-percent${external ? " is-external" : ""}" data-kitting-percent="${series.key}" x="${labelX}" y="${labelY}" fill="${external || series.key !== "ready" ? "#14212b" : "#fff"}" aria-hidden="true">${escapeHtml(percent)}</text>`;
      if (segmentHeight < 14) smallLabels.push({ middle, label });
      return `<rect class="customer-bar-fill" data-kitting-segment="${series.key}" data-count="${count}" tabindex="0" role="button" aria-label="${escapeHtml(group.label)} ${series.label} ${count}单，占${percent}" style="--series-color:${series.color}" x="${x}" y="${y(cumulative)}" width="36" height="${segmentHeight}"/>${segmentHeight >= 14 ? label(cx, middle) : ""}`;
    }).join("");
    smallLabels.sort((a, b) => a.middle - b.middle);
    smallLabels.forEach((item, i) => { item.y = Math.max(item.middle, i ? smallLabels[i - 1].y + 14 : top + 6); });
    const overflow = Math.max(0, (smallLabels.at(-1)?.y || 0) - bottom + 6);
    const callouts = smallLabels.map((item) => `<path class="customer-percent-leader" d="M${x + 36} ${item.middle} L${x + 42} ${item.y - overflow} H${x + 46}"/><g>${item.label(x + 49, item.y - overflow, true)}</g>`).join("");
    const description = `${escapeHtml(group.label)} 逾已入与逾拿货合计 ${value}单${byMonth ? "" : `，${CUSTOMER_KITTING_SERIES.map((series) => `${series.label}${counts[series.key]}单`).join("，")}`}`;
    const bars = `<g role="button" tabindex="0" class="customer-order-bar" ${barAttribute}="${index}" aria-label="${description}" style="--series-color:${byMonth ? "#2563eb" : "#0f766e"}">${byMonth ? `<title>${description}</title>` : ""}<rect class="customer-bar-hit" x="${x}" y="${top}" width="36" height="${bottom - top}"/>${byMonth ? `<rect class="customer-bar-fill" x="${x}" y="${y(value)}" width="36" height="${Math.max(0, bottom - y(value))}" rx="2"/>` : segments + callouts}<text x="${cx}" y="${y(value) - 7}" class="customer-bar-value">${fmtNumber(value)}</text></g>`;
    const chars = Array.from(group.label);
    const shortLabel = chars.length > 7 ? `${chars.slice(0, 6).join("")}…` : group.label;
    return `${bars}<text x="${cx}" y="${bottom + 24}" class="customer-bar-label"><title>${escapeHtml(group.label)}（${escapeHtml(group.key)}）</title>${escapeHtml(shortLabel)}</text>${byMonth ? "" : `<text x="${cx}" y="${bottom + 43}" class="customer-bar-id">${escapeHtml(group.key.length > 13 ? group.key.slice(0, 12) + "…" : group.key)}</text>`}`;
  }).join("");
  return `<div class="customer-order-chart-scroll"><svg class="customer-order-chart${byMonth ? " business-month-chart" : ""}" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-label="按${axisLabel}统计的无出通单订单数"><text x="8" y="17" class="customer-bar-axis">订单数</text>${ticks}${columns}<text x="${left + plotWidth / 2}" y="${height - 13}" class="customer-bar-label">${axisLabel}</text></svg></div>`;
}

function openNoNoticeMonthDetail(group) {
  if (!canViewCustomerId()) return;
  const ranks = new Map([...group.orders].sort((a, b) => b.maxDays - a.maxDays || a.orderNo.localeCompare(b.orderNo)).map((order, index) => [order.orderNo, index]));
  const records = getEnrichedRecords().filter((record) => ranks.has(record.orderNo))
    .sort((a, b) => ranks.get(a.orderNo) - ranks.get(b.orderNo) || columnValueCollator.compare(String(a.lineNo ?? ""), String(b.lineNo ?? "")));
  const columns = orderExportColumns(true).map((column) => ({
    ...column, label: column.label === "未出" ? "未出数量" : column.label,
    width: column.numeric ? 110 : column.label === "项次" ? 65 : ["品名", "规格", "工单号", "出通单号"].includes(column.label) ? 200 : column.label === "订单号" ? 170 : 140,
  }));
  const rows = records.map((record) => ({ record, values: columns.map((column) => {
    const value = column.value(record);
    return column.numeric && value !== "" ? fmtNumber(value) : String(value ?? "");
  }) }));
  let page = 0, query = "";
  const pageSize = 100, previousFocus = document.activeElement;
  document.querySelector(".customer-order-modal")?.remove();
  const modal = document.createElement("div");
  modal.className = "delay-drill-modal customer-order-modal";
  const close = () => { modal.remove(); if (previousFocus?.isConnected) previousFocus.focus(); };
  modal.innerHTML = `<div class="delay-drill-backdrop" data-close-customer-orders></div><section class="delay-drill-page" role="dialog" aria-modal="true" aria-label="无出通单订单明细"><header class="delay-drill-head"><div><span>${escapeHtml(group.label)} · 逾已入 + 逾拿货 · 按最早业务交期归月 · 全部关联订单行</span><h2>无出通单订单 / ${fmtNumber(group.orders.length)} 单 · ${fmtNumber(rows.length)} 行</h2></div><button type="button" data-close-customer-orders title="关闭" aria-label="关闭">×</button></header><div class="kpi-drill-toolbar"><form class="customer-order-search"><input type="search" aria-label="订单明细搜索" placeholder="订单号 / SKU / 关键词"/><button type="submit">查询</button></form></div><div class="table-wrap delay-drill-table-wrap"><table class="delay-drill-table status-drill-table" style="width:${columns.reduce((sum, column) => sum + column.width, 0)}px"><colgroup>${columns.map((column) => `<col style="width:${column.width}px">`).join("")}</colgroup><thead><tr>${columns.map((column) => `<th${column.numeric ? ' class="num"' : ""}>${escapeHtml(column.label)}</th>`).join("")}</tr></thead><tbody></tbody></table></div><footer class="customer-orders-pagination"><span aria-live="polite"></span><button type="button" data-detail-prev title="上一页" aria-label="上一页">‹</button><button type="button" data-detail-next title="下一页" aria-label="下一页">›</button></footer></section>`;
  const draw = () => {
    const filtered = query ? rows.filter((row) => row.values.some((value) => value.toLocaleLowerCase().includes(query))) : rows;
    const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
    page = Math.min(page, pages - 1);
    modal.querySelector("tbody").innerHTML = filtered.length ? filtered.slice(page * pageSize, (page + 1) * pageSize).map((row) => `<tr>${row.values.map((value, index) => `<td${columns[index].numeric ? ' class="num"' : ""} title="${escapeHtml(value)}">${escapeHtml(value)}</td>`).join("")}</tr>`).join("") : `<tr><td colspan="${columns.length}" class="empty-cell">没有匹配的订单明细</td></tr>`;
    modal.querySelector("footer span").textContent = `${page + 1} / ${pages} 页 · ${fmtNumber(new Set(filtered.map((row) => row.record.orderNo)).size)} 单 · ${fmtNumber(filtered.length)} 行 · 每页 ${pageSize} 行`;
    modal.querySelector("[data-detail-prev]").disabled = page === 0;
    modal.querySelector("[data-detail-next]").disabled = page + 1 === pages;
    modal.querySelector(".table-wrap").scrollTop = 0;
    if (document.activeElement?.disabled) modal.querySelector("input").focus();
  };
  modal.querySelectorAll("[data-close-customer-orders]").forEach((node) => node.addEventListener("click", close));
  modal.querySelector("form").addEventListener("submit", (event) => { event.preventDefault(); query = modal.querySelector("input").value.trim().toLocaleLowerCase(); page = 0; draw(); });
  modal.querySelector("[data-detail-prev]").addEventListener("click", () => { page -= 1; draw(); });
  modal.querySelector("[data-detail-next]").addEventListener("click", () => { page += 1; draw(); });
  modal.addEventListener("keydown", (event) => {
    if (event.key === "Escape") close();
    if (event.key === "Tab") {
      const controls = [...modal.querySelectorAll("button:not(:disabled), input")];
      const first = controls[0], last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  document.body.appendChild(modal);
  draw();
  modal.querySelector("button[data-close-customer-orders]").focus();
}

function bindCustomerOrderTooltips(groups) {
  const tooltip = document.createElement("div");
  tooltip.id = "customerOrderMonthTooltip";
  tooltip.className = "customer-order-tooltip";
  tooltip.setAttribute("role", "tooltip");
  tooltip.hidden = true;
  els.customerOrders.appendChild(tooltip);
  let active = null;
  let hideTimer = 0;
  const hide = () => {
    clearTimeout(hideTimer);
    active?.removeAttribute("aria-describedby");
    active = null;
    tooltip.hidden = true;
  };
  const cells = (counts) => CUSTOMER_KITTING_SERIES.map((series) => `<td class="num">${fmtNumber(counts[series.key])}</td>`).join("");
  const quantity = (orders) => orders.reduce((sum, order) => sum + Number(order.orderQty || 0), 0);
  const show = (node, event) => {
    clearTimeout(hideTimer);
    const group = groups[Number(node.dataset.customerBar)];
    const months = customerOrderMonths([group]);
    active?.removeAttribute("aria-describedby");
    active = node;
    node.setAttribute("aria-describedby", tooltip.id);
    tooltip.innerHTML = `<strong>${escapeHtml(group.label)}</strong><div class="hint">业务交期月份 · 按订单最早业务交期归月</div><div class="customer-tooltip-scroll"><table><thead><tr><th>月份</th>${CUSTOMER_KITTING_SERIES.map((series) => `<th class="num">${series.label}<span class="customer-tooltip-unit">（单）</span></th>`).join("")}<th class="num" title="当前统计范围内的订单数量合计">订单数量</th></tr></thead><tbody>${months.map((month) => `<tr><td>${escapeHtml(month.key)}</td>${cells(customerKittingCounts(month.orders))}<td class="num">${fmtNumber(quantity(month.orders))}</td></tr>`).join("")}</tbody><tfoot><tr><th>总计</th>${cells(customerKittingCounts(group.orders))}<td class="num">${fmtNumber(quantity(group.orders))}</td></tr></tfoot></table></div>`;
    tooltip.hidden = false;
    const rect = node.getBoundingClientRect();
    const x = event?.clientX ?? rect.right, y = event?.clientY ?? rect.top;
    tooltip.style.left = `${Math.max(8, Math.min(x + 14, innerWidth - tooltip.offsetWidth - 8))}px`;
    tooltip.style.top = `${Math.max(8, Math.min(y + 14, innerHeight - tooltip.offsetHeight - 8))}px`;
  };
  els.customerOrders.querySelectorAll("[data-customer-bar]").forEach((node) => {
    node.addEventListener("pointerenter", (event) => show(node, event));
    node.addEventListener("pointerleave", (event) => {
      if (!tooltip.contains(event.relatedTarget)) hideTimer = setTimeout(hide, 180);
    });
    node.addEventListener("focusin", () => show(node));
    node.addEventListener("focusout", hide);
    node.addEventListener("click", hide);
    node.addEventListener("keydown", (event) => { if (event.key === "Escape") hide(); });
  });
  tooltip.addEventListener("pointerenter", () => clearTimeout(hideTimer));
  tooltip.addEventListener("pointerleave", hide);
  // Assign rather than accumulate listeners when filters rebuild this panel.
  els.customerOrders.onscroll = hide;
  els.customerOrders.querySelectorAll(".customer-order-chart-scroll").forEach((scroll) => scroll.addEventListener("scroll", hide, { passive: true }));
}

function openCustomerOrderDetail(group, kittingKey = "all") {
  if (!canViewCustomerId()) return;
  const segment = CUSTOMER_KITTING_SERIES.find((series) => series.key === kittingKey);
  const status = `逾已入 + 逾拿货${segment ? ` · ${segment.label}` : ""}`;
  const orders = group.orders.filter((order) => !segment || customerOrderKittingKey(order) === segment.key)
    .sort((a, b) => b.maxDays - a.maxDays || a.orderNo.localeCompare(b.orderNo));
  const previousFocus = document.activeElement;
  document.querySelector(".customer-order-modal")?.remove();
  const modal = document.createElement("div");
  modal.className = "delay-drill-modal customer-order-modal";
  let page = 0;
  const close = () => { modal.remove(); previousFocus?.focus(); };
  const draw = () => {
    const pageSize = 100, pages = Math.max(1, Math.ceil(orders.length / pageSize));
    const rows = orders.slice(page * pageSize, (page + 1) * pageSize);
    modal.innerHTML = `<div class="delay-drill-backdrop" data-close-customer-orders></div><section class="delay-drill-page" role="dialog" aria-modal="true" aria-label="客户订单明细"><header class="delay-drill-head"><div><span>${escapeHtml(group.label)} · ${escapeHtml(group.key)} · 无出通单订单数</span><h2>${status} / ${fmtNumber(orders.length)} 单</h2></div><button type="button" data-close-customer-orders title="关闭" aria-label="关闭">×</button></header><div class="table-wrap delay-drill-table-wrap"><table class="delay-drill-table status-drill-table"><thead><tr><th>订单号</th><th>状态</th><th>出通单号</th><th>齐套状态</th><th class="num">SKU数</th><th class="num" title="该订单当前统计范围内各明细行的订单数量合计">订单数量</th><th class="num">未出数量</th><th class="num">最长逾期</th><th>业务交期</th><th>计划员</th><th>业务员</th></tr></thead><tbody>${rows.length ? rows.map((order) => `<tr><td>${escapeHtml(order.orderNo)}</td><td>${order.status}</td><td>${escapeHtml(order.noticeText)}</td><td>${order.kittingText}</td><td class="num">${fmtNumber(order.skuCount)}</td><td class="num">${fmtNumber(order.orderQty)}</td><td class="num">${fmtNumber(order.unshippedQty)}</td><td class="num">${fmtNumber(order.maxDays)}</td><td>${escapeHtml(order.businessDueDate)}</td><td>${escapeHtml(order.plannerText)}</td><td>${escapeHtml(order.salesPersonText)}</td></tr>`).join("") : '<tr><td colspan="11" class="empty-cell">暂无订单</td></tr>'}</tbody></table></div><footer class="customer-orders-pagination"><span>${page + 1} / ${pages} 页 · ${fmtNumber(orders.length)} 单</span><button type="button" data-detail-prev title="上一页" aria-label="上一页" ${page === 0 ? "disabled" : ""}>‹</button><button type="button" data-detail-next title="下一页" aria-label="下一页" ${page + 1 === pages ? "disabled" : ""}>›</button></footer></section>`;
    modal.querySelectorAll("[data-close-customer-orders]").forEach((node) => node.addEventListener("click", close));
    modal.querySelector("[data-detail-prev]").addEventListener("click", () => { page -= 1; draw(); });
    modal.querySelector("[data-detail-next]").addEventListener("click", () => { page += 1; draw(); });
    modal.querySelector("button[data-close-customer-orders]").focus();
  };
  modal.addEventListener("keydown", (event) => {
    if (event.key === "Escape") close();
    if (event.key === "Tab") {
      const controls = [...modal.querySelectorAll("button:not([disabled])")];
      const first = controls[0], last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  document.body.appendChild(modal);
  draw();
}

function renderCustomerOrders() {
  if (!canViewCustomerId()) {
    els.customerOrders.innerHTML = '<div class="empty">当前账号没有客户数据查看权限。</div>';
    return;
  }
  const query = state.customerOrderSearch.trim().toLocaleLowerCase();
  const customerGroups = customerOrderGroups().filter((group) => !query || `${group.key} ${group.label}`.toLocaleLowerCase().includes(query));
  const groups = customerGroups
    .map((group) => ({ ...group, orders: group.orders.filter((order) => !order.noticeText) }))
    .filter((group) => group.orders.length)
    .sort((a, b) => b.orders.length - a.orders.length || a.key.localeCompare(b.key, "zh-CN"));
  const pageSize = 20, pages = Math.max(1, Math.ceil(groups.length / pageSize));
  state.customerOrderPage = Math.min(state.customerOrderPage, pages - 1);
  const visible = groups.slice(state.customerOrderPage * pageSize, (state.customerOrderPage + 1) * pageSize);
  const total = groups.reduce((sum, group) => sum + group.orders.length, 0);
  els.customerOrders.innerHTML = `<div class="section-head"><div><h2>逾已入、逾拿货订单分析</h2><span class="hint">${state.asOfDate} · 按订单号去重，混合状态按风险优先</span></div></div><div class="customer-orders-toolbar"><h3 class="customer-order-metric-title">无出通单订单数</h3><form class="customer-order-search"><input type="search" aria-label="客户搜索" placeholder="客户编号 / 简称" value="${escapeHtml(state.customerOrderSearch)}"/><button type="submit">查询</button></form></div><div class="customer-order-totals"><span><i style="background:#0f766e"></i>逾已入 + 逾拿货<strong data-customer-total="combined">${fmtNumber(total)}</strong>单</span><span class="customer-order-count">${fmtNumber(groups.length)} 个客户</span></div>${visible.length ? renderCustomerOrderBars(visible) : '<div class="empty">当前筛选下没有客户订单</div>'}<footer class="customer-orders-pagination"><span>${state.customerOrderPage + 1} / ${pages} 页 · 每页 ${pageSize} 个客户</span><button type="button" data-customer-prev title="上一页" aria-label="上一页" ${state.customerOrderPage === 0 ? "disabled" : ""}>‹</button><button type="button" data-customer-next title="下一页" aria-label="下一页" ${state.customerOrderPage + 1 === pages ? "disabled" : ""}>›</button></footer>`;
  els.customerOrders.querySelector(".customer-order-totals").insertAdjacentHTML("afterend", `<div class="customer-kitting-legend">${CUSTOMER_KITTING_SERIES.map((series) => `<span><i style="background:${series.color}"></i>${series.label}</span>`).join("")}</div>`);
  const search = els.customerOrders.querySelector(".customer-order-search");
  search.addEventListener("submit", (event) => {
    event.preventDefault();
    state.customerOrderSearch = search.querySelector("input").value;
    state.customerOrderPage = 0;
    renderCustomerOrders();
  });
  els.customerOrders.querySelector("[data-customer-prev]").addEventListener("click", () => { state.customerOrderPage -= 1; renderCustomerOrders(); });
  els.customerOrders.querySelector("[data-customer-next]").addEventListener("click", () => { state.customerOrderPage += 1; renderCustomerOrders(); });
  els.customerOrders.querySelectorAll("[data-customer-bar]").forEach((node) => {
    const open = (event) => {
      const segment = event.target.closest("[data-kitting-segment]");
      if (segment) segment.focus();
      openCustomerOrderDetail(visible[Number(node.dataset.customerBar)], segment?.dataset.kittingSegment || "all");
    };
    node.addEventListener("click", open);
    node.addEventListener("keydown", (event) => { if (["Enter", " "].includes(event.key)) { event.preventDefault(); event.stopPropagation(); open(event); } });
  });
  const months = customerOrderMonths(customerGroups.map((group) => ({ ...group, orders: group.orders.filter((order) => !order.noticeText) })));
  const noNoticeTotal = months.reduce((sum, month) => sum + month.orders.length, 0);
  els.customerOrders.insertAdjacentHTML("beforeend", `<section class="business-month-section" aria-label="无出通单订单分布"><div class="business-month-head"><h3>无出通单订单分布</h3><span>无出通单订单数 · ${fmtNumber(noNoticeTotal)} 单</span></div><div class="business-month-note">逾已入 + 逾拿货 · 当前筛选全部客户 · 每个订单按最早业务交期归月</div>${months.length ? renderCustomerOrderBars(months, true) : '<div class="empty">当前筛选下没有无出通单订单</div>'}</section>`);
  els.customerOrders.querySelectorAll("[data-month-bar]").forEach((node) => {
    const open = () => openNoNoticeMonthDetail(months[Number(node.dataset.monthBar)]);
    node.addEventListener("click", open);
    node.addEventListener("keydown", (event) => { if (["Enter", " "].includes(event.key)) { event.preventDefault(); open(); } });
  });
  bindCustomerOrderTooltips(visible);
}

function warehouseChartSeries(mode) {
  return mode === "production" ? DELIVERY_STATUS_SERIES.slice(0, 2) : CUSTOMER_ORDER_SERIES;
}

const WAREHOUSE_PRODUCTION_COLUMNS = [
  { field: "orderQty", label: "订单数量" },
  { field: "workOrderQty", label: "工单数量" },
  { field: "reportedQty", label: "报工" },
  { field: "inspectionQty", label: "检验" },
  { field: "stockInQty", label: "入库" },
];

function warehouseOrderDays(mode = "shipping") {
  const series = warehouseChartSeries(mode);
  const days = new Map();
  for (const record of getEnrichedRecords()) {
    if (!series.some((item) => item.key === record.statusText)) continue;
    if (mode === "production") {
      if (!String(record.workOrderNo || "").trim() || String(record.orderNo || "").trim().startsWith("3005")) continue;
    } else if (!String(record.shipmentNoticeNo || "").trim() || orderKittingStatus(record.orderNo) !== "ready") continue;
    const day = Number(record.overdueDays);
    if (!Number.isFinite(day) || day <= 0) continue;
    if (!days.has(day)) days.set(day, { day, counts: new Map(series.map((item) => [item.key, 0])) });
    const group = days.get(day);
    group.counts.set(record.statusText, group.counts.get(record.statusText) + 1);
    if (mode === "production") {
      (group.records ||= []).push(record);
      group.quantities ||= Object.fromEntries(WAREHOUSE_PRODUCTION_COLUMNS.map(({ field }) => [field, 0]));
      for (const { field } of WAREHOUSE_PRODUCTION_COLUMNS) {
        const value = Number(record[field] || 0);
        if (Number.isFinite(value)) group.quantities[field] += value;
      }
    }
  }
  return [...days.values()].sort((a, b) => mode === "production" ? a.day - b.day : b.day - a.day);
}

function renderWarehouseDayBars(groups, mode = "shipping") {
  const series = warehouseChartSeries(mode);
  if (!groups.length) return `<div class="empty">${mode === "production" ? "暂无非3005且有工单号的逾未入或逾部分入订单明细" : "暂无有出通单且齐套的逾拿货或逾已入订单明细"}</div>`;
  const maximum = Math.max(...groups.map((group) => [...group.counts.values()].reduce((sum, count) => sum + count, 0)));
  const { step, ceiling } = deliveryTrendScale(maximum);
  const left = Math.max(58, fmtNumber(ceiling).length * 7 + 18), right = 24, top = 40, bottom = 334, height = 400;
  const groupWidth = Math.max(80, fmtNumber(maximum).length * 7 + 24);
  const width = Math.max(760, left + right + groups.length * groupWidth);
  const plotWidth = width - left - right;
  const y = (value) => bottom - value / ceiling * (bottom - top);
  const ticks = Array.from({ length: Math.round(ceiling / step) + 1 }, (_, index) => {
    const value = index * step;
    return `<line class="delivery-trend-grid" x1="${left}" y1="${y(value)}" x2="${width - right}" y2="${y(value)}"/><text class="delivery-trend-y" x="${left - 8}" y="${y(value) + 4}">${fmtNumber(value)}</text>`;
  }).join("");
  const bars = groups.map((group, index) => {
    const center = left + (index + .5) * plotWidth / groups.length;
    let cumulative = 0;
    const segments = series.map((series) => {
      const value = group.counts.get(series.key);
      const segmentBottom = y(cumulative);
      cumulative += value;
      const segmentTop = y(cumulative), segmentHeight = segmentBottom - segmentTop;
      const description = `逾期${group.day}天 · ${series.key}：${fmtNumber(value)}行`;
      return `<g class="warehouse-day-bar" ${value ? 'tabindex="0"' : ""} role="${mode === "shipping" && value ? "button" : "img"}" ${mode === "shipping" && value ? 'aria-haspopup="dialog"' : ""} aria-label="${description}" data-day="${group.day}" data-status="${series.key}" data-count="${value}" style="--series-color:${series.color}"><title>${description}</title><rect class="customer-bar-fill" x="${center - 20}" y="${segmentTop}" width="40" height="${segmentHeight}"/></g>`;
    }).join("");
    return `${segments}<text class="warehouse-day-total" data-day="${group.day}" x="${center}" y="${y(cumulative) - 8}">${fmtNumber(cumulative)}</text><text class="customer-bar-label warehouse-day-label" x="${center}" y="${bottom + 25}">${group.day}</text>`;
  }).join("");
  const description = mode === "production" ? "有工单号且排除3005的逾未入和逾部分入订单行数总计，按逾期天数统计" : "有出通单且齐套的逾拿货和逾已入订单行数总计，按逾期天数统计";
  return `<div class="customer-order-chart-scroll"><svg class="warehouse-day-chart" role="img" aria-label="${description}" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><text class="customer-bar-axis" x="8" y="18">订单行数总计（行）</text>${ticks}<line class="delivery-trend-axis" x1="${left}" y1="${bottom}" x2="${width - right}" y2="${bottom}"/>${bars}<text class="customer-bar-label" x="${left + plotWidth / 2}" y="${height - 12}">逾期天数（天）</text></svg></div>`;
}

function renderWarehouseProductionTable(groups) {
  const columns = WAREHOUSE_PRODUCTION_COLUMNS;
  const rowCount = (group) => [...group.counts.values()].reduce((sum, count) => sum + count, 0);
  const totalRows = groups.reduce((sum, group) => sum + rowCount(group), 0);
  const drillCount = (count, day) => count ? `<button type="button" class="production-drill-link" data-production-drill="${day}" aria-haspopup="dialog" aria-label="${day === "all" ? "全部" : `逾期${day}天`}，${fmtNumber(count)}行，查看订单明细">${fmtNumber(count)}</button>` : "0";
  const totals = Object.fromEntries(columns.map(({ field }) => [field, groups.reduce((sum, group) => sum + group.quantities[field], 0)]));
  const cells = (quantities) => columns.map(({ field }) => `<td class="num" data-field="${field}">${fmtNumber(quantities[field])}</td>`).join("");
  return `<div class="warehouse-production-scroll"><table class="warehouse-production-table" aria-label="生产和计划管理数量汇总表"><thead><tr><th scope="col">逾期天数</th><th scope="col" class="num">订单行数</th>${columns.map(({ label }) => `<th scope="col" class="num">${label}</th>`).join("")}</tr></thead><tbody>${groups.length ? groups.map((group) => `<tr data-production-day="${group.day}"><td>${fmtNumber(group.day)}</td><td class="num" data-field="rowCount">${drillCount(rowCount(group), group.day)}</td>${cells(group.quantities)}</tr>`).join("") : '<tr><td colspan="7" class="empty-cell">暂无非3005且有工单号的逾未入或逾部分入订单明细</td></tr>'}</tbody><tfoot><tr><th scope="row">总计</th><td class="num" data-field="rowCount">${drillCount(totalRows, "all")}</td>${cells(totals)}</tr></tfoot></table></div>`;
}

function renderWarehouseChartSection(mode) {
  const production = mode === "production";
  const groups = warehouseOrderDays(mode);
  const totals = warehouseChartSeries(mode).map((series) => ({ ...series, count: groups.reduce((sum, group) => sum + group.counts.get(series.key), 0) }));
  const legend = `<div class="customer-order-totals">${totals.map((series) => `<span><i style="background:${series.color}"></i>${series.key}<strong data-warehouse-total="${series.key}">${fmtNumber(series.count)}</strong>行</span>`).join("")}</div>`;
  const summary = production
    ? `<div class="warehouse-production-summary">总订单行数 / 符合条件订单行数：<strong>${fmtNumber(state.records.length)} / <span data-production-row-count>${fmtNumber(totals.reduce((sum, series) => sum + series.count, 0))}</span></strong></div>`
    : legend;
  const head = production
    ? `<div class="section-head"><div><h2>生产和计划管理</h2><span class="hint">${state.asOfDate} · 有工单号 · 逾未入、逾部分入 · 排除3005</span></div></div>`
    : '<div class="business-month-head"><h3>有出通单订单分析</h3><span>有出通单且齐套</span></div>';
  return `<section class="warehouse-chart-section" data-warehouse-view="${mode}">${head}${production ? legend + renderWarehouseDayBars([...groups].reverse(), mode) : ""}${summary}${production ? renderWarehouseProductionTable(groups) : renderWarehouseDayBars(groups, mode)}</section>`;
}

function renderWarehouseCustomerOrders() {
  if (!canViewCustomerId()) {
    els.warehouseCustomerOrders.innerHTML = '<div class="empty">当前账号没有客户数据查看权限。</div>';
    return;
  }
  els.warehouseCustomerOrders.innerHTML = `<div class="section-head"><div><h2>逾逾已入、逾拿货订单分析</h2><span class="hint">${state.asOfDate}</span></div></div>${renderWarehouseChartSection("shipping")}`;
  els.warehouseCustomerOrders.querySelectorAll('.warehouse-day-bar[role="button"]').forEach((node) => {
    const open = () => {
      if (!canViewCustomerId()) return;
      const day = Number(node.dataset.day), status = node.dataset.status;
      const records = kpiDrillRecords("noticeReady").filter((record) => Number(record.overdueDays) === day);
      openStatusDrill(status, {
        records,
        breakdown: false,
        heading: `逾期${day}天 · ${status}`,
        context: `${state.asOfDate} · 有出通单且齐套 · 按订单行统计`,
      });
    };
    node.addEventListener("click", open);
    node.addEventListener("keydown", (event) => {
      if (["Enter", " "].includes(event.key)) { event.preventDefault(); open(); }
    });
  });
}

function renderProductionPlanning() {
  if (!canViewCustomerId()) {
    els.productionPlanning.innerHTML = '<div class="empty">当前账号没有客户数据查看权限。</div>';
    return;
  }
  els.productionPlanning.innerHTML = renderWarehouseChartSection("production");
  els.productionPlanning.querySelectorAll("[data-production-drill]").forEach((node) => {
    node.addEventListener("click", () => {
      if (!canViewCustomerId()) return;
      const day = node.dataset.productionDrill;
      const records = warehouseOrderDays("production").filter((group) => day === "all" || group.day === Number(day)).flatMap((group) => group.records);
      const preferred = ["订单号", "项次", "工单号", "报工", "报工时间", "状态", "逾期天数", "SKU"];
      const columns = orderExportColumns(true);
      openStatusDrill(null, {
        records,
        columns: [...preferred.map((label) => columns.find((column) => column.label === label)), ...columns.filter((column) => !preferred.includes(column.label))]
          .map((column) => column.label === "报工时间" ? { ...column, width: 190 } : column),
        breakdown: false,
        heading: day === "all" ? "全部生产订单" : `逾期${day}天 · 生产订单`,
        context: `${state.asOfDate} · 有工单号 · 逾未入、逾部分入 · 排除3005`,
      });
    });
  });
}

function stockOccupancyData() {
  const quantity = (value) => value == null || String(value).trim() === "" || !Number.isFinite(Number(value)) || Number(value) < 0 ? null : Number(value);
  const dateDay = (value) => {
    const text = String(value || "").slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return null;
    const stamp = Date.parse(`${text}T00:00:00Z`);
    return Number.isFinite(stamp) && new Date(stamp).toISOString().slice(0, 10) === text ? stamp : null;
  };
  const asOf = dateDay(state.asOfDate);
  const records = [], invalid = [];
  for (const record of getEnrichedRecords()) {
    const stock = quantity(record.stockInQty), shipped = quantity(record.shippedQty), unshipped = quantity(record.unshippedQty);
    if (stock === 0 || unshipped === 0) continue;
    if (stock == null || shipped == null || unshipped == null) { invalid.push(record); continue; }
    // Order-line estimate only: never allocate the same SKU-level available stock to multiple orders.
    const occupiedQty = Math.min(unshipped, Math.max(0, stock - shipped));
    if (!occupiedQty) continue;
    const stockedAt = dateDay(record.lastStockInDate);
    const age = asOf != null && stockedAt != null && stockedAt <= asOf ? (asOf - stockedAt) / DAY : null;
    const ageBand = age == null ? "日期缺失或异常" : age <= 7 ? "0–7天" : age <= 30 ? "8–30天" : age <= 60 ? "31–60天" : age <= 90 ? "61–90天" : "90天以上";
    const notice = String(record.shipmentNoticeNo || "").trim();
    const ready = orderKittingStatus(record.orderNo);
    const dispatchGroup = `${notice ? "有出通单" : "无出通单"} · ${ready === "ready" ? "齐套" : ready === "short" ? "未齐套" : "齐套未确定"}`;
    records.push({ ...record, occupiedQty, stockAgeDays: age, stockAgeBand: ageBand, dispatchGroup });
  }
  return { records, invalid };
}

function renderStockOccupancy() {
  const root = els.stockOccupancy;
  if (!canViewCustomerId()) { root.innerHTML = '<div class="empty">当前账号没有客户数据查看权限。</div>'; return; }
  const settings = state.stockOccupancy;
  const source = stockOccupancyData();
  const matches = (record) => (!settings.query || [record.customerId, record.customerShortName, record.orderNo, record.sku].some((value) => String(value || "").toLocaleLowerCase().includes(settings.query.toLocaleLowerCase())))
    && (settings.scope === "all" || record.status === settings.scope)
    && (settings.notice === "all" || Boolean(String(record.shipmentNoticeNo || "").trim()) === (settings.notice === "with"));
  const records = source.records.filter(matches), invalid = source.invalid.filter(matches);
  const sum = (rows) => rows.reduce((total, row) => total + row.occupiedQty, 0);
  const measure = (rows) => settings.metric === "rows" ? rows.length : sum(rows);
  const total = measure(records), totalQty = sum(records);
  const customerKey = (record) => String(record.customerId || record.customerShortName || "未标明客户");
  const customers = new Set(records.map(customerKey)).size;
  const overdue = records.filter((record) => record.status === "overdue");
  const dimensions = { customer: "客户", sku: "SKU", salesPerson: "业务员", planner: "计划员" };
  const groupRows = (getKey, getLabel = (record) => getKey(record)) => {
    const groups = new Map();
    for (const record of records) {
      const key = getKey(record);
      if (!groups.has(key)) groups.set(key, { key, label: getLabel(record), records: [] });
      groups.get(key).records.push(record);
    }
    return [...groups.values()];
  };
  const ranked = groupRows((record) => settings.dimension === "customer" ? customerKey(record) : String(record[settings.dimension] || "未标明"),
    (record) => settings.dimension === "customer" ? `${record.customerShortName || record.customerId || "未标明客户"}${record.customerId ? ` (${record.customerId})` : ""}` : String(record[settings.dimension] || "未标明"))
    .sort((a, b) => measure(b.records) - measure(a.records) || a.key.localeCompare(b.key, "zh-CN"));
  const ranking = ranked.slice(0, 10);
  if (ranked.length > 10) ranking.push({ label: `其他${ranked.length - 10}个${dimensions[settings.dimension]}`, records: ranked.slice(10).flatMap((group) => group.records) });
  const ageLabels = ["0–7天", "8–30天", "31–60天", "61–90天", "90天以上", "日期缺失或异常"];
  const ages = ageLabels.map((label) => ({ label, records: records.filter((record) => record.stockAgeBand === label) }));
  const dispatch = ["无出通单 · 齐套", "无出通单 · 未齐套", "无出通单 · 齐套未确定", "有出通单 · 齐套", "有出通单 · 未齐套", "有出通单 · 齐套未确定"]
    .map((label) => ({ label, records: records.filter((record) => record.dispatchGroup === label) }));
  const drills = [];
  const drillId = (rows, heading) => { drills.push({ records: rows, heading }); return drills.length - 1; };
  const pct = (value) => `${total ? (100 * value / total).toFixed(1) : "0.0"}%`;
  const metricLabel = settings.metric === "rows" ? "订单行数（行）" : "占用数量（估算）";
  const chart = (groups, color, name) => {
    const max = Math.max(1, ...groups.map((group) => measure(group.records)));
    return `<div class="occupancy-bars" aria-label="${escapeHtml(name)}">${groups.map((group) => {
      const value = measure(group.records), hint = `${group.label}：${fmtNumber(group.records.length)}行，占用数量（估算）${fmtNumber(sum(group.records))}，占当前筛选${pct(value)}`;
      return `<button type="button" class="occupancy-bar" data-occupancy-drill="${drillId(group.records, group.label)}" ${group.records.length ? '' : 'disabled'} aria-haspopup="dialog" aria-label="${escapeHtml(hint)}" title="${escapeHtml(hint)}"><span class="occupancy-bar-label">${escapeHtml(group.label)}</span><span class="occupancy-bar-track"><span style="width:${100 * value / max}%;background:${color}"></span></span><span class="occupancy-bar-value">${fmtNumber(value)}<small>${pct(value)}</small></span></button>`;
    }).join("")}</div>`;
  };
  const kpi = (label, value, rows, key) => `<button type="button" class="occupancy-kpi" data-occupancy-kpi="${key}" data-occupancy-drill="${drillId(rows, label)}" aria-haspopup="dialog" ${rows.length ? '' : 'disabled'}><span>${label}</span><strong>${fmtNumber(value)}</strong></button>`;
  root.innerHTML = `<div class="section-head"><div><h2>客户订单已入库未出货占用分布</h2><span class="hint">${escapeHtml(state.asOfDate)} · 数据生成 ${escapeHtml(state.generatedAt || "未提供")}</span></div><div class="occupancy-mode" role="group" aria-label="分布指标">${[["quantity", "占用数量"], ["rows", "订单行数"]].map(([key, label]) => `<button type="button" data-occupancy-metric="${key}" aria-pressed="${settings.metric === key}">${label}</button>`).join("")}</div></div>
    <form class="occupancy-filters"><label>客户 / 订单 / SKU<input name="query" type="search" value="${escapeHtml(settings.query)}"/></label><label>交期范围<select name="scope">${[["all", "全部交期"], ["overdue", "已逾期"], ["normal", "未逾期"], ["missing", "交期缺失"]].map(([key, label]) => `<option value="${key}" ${settings.scope === key ? "selected" : ""}>${label}</option>`).join("")}</select></label><label>出通单<select name="notice">${[["all", "全部"], ["with", "有出通单"], ["without", "无出通单"]].map(([key, label]) => `<option value="${key}" ${settings.notice === key ? "selected" : ""}>${label}</option>`).join("")}</select></label><button type="submit" class="ghost-button">查询</button><button type="button" class="ghost-button" data-occupancy-reset>重置</button></form>
    <div class="occupancy-kpis">${kpi("占用数量（估算）", totalQty, records, "quantity")}${kpi("涉及订单行数", records.length, records, "rows")}${kpi("涉及客户（家）", customers, records, "customers")}${kpi("已逾期占用数量（估算）", sum(overdue), overdue, "overdue")}</div>
    <p class="occupancy-definition">占用数量按订单行估算：min（未出数，max（入库数 − 已出数，0））。包含部分入库及未逾期订单；不代表实时可用库存或占用金额。</p>
    ${invalid.length ? `<p class="occupancy-warning">当前范围有 <button type="button" class="production-drill-link" data-occupancy-drill="${drillId(invalid, "数量缺失或异常，未纳入估算")}">${fmtNumber(invalid.length)} 行</button>数量缺失或异常，未纳入估算。</p>` : ""}
    ${records.length ? `<div class="occupancy-layout"><section class="occupancy-section"><div class="occupancy-section-head"><h3>${dimensions[settings.dimension]}占用分布</h3><select aria-label="分布维度" data-occupancy-dimension>${Object.entries(dimensions).map(([key, label]) => `<option value="${key}" ${settings.dimension === key ? "selected" : ""}>${label}</option>`).join("")}</select></div><p class="hint">${metricLabel} · 前10名及其他 · 占比以当前筛选总量为分母</p>${chart(ranking, "var(--teal)", "占用排名")}</section><section class="occupancy-section"><h3>距最近入库的时间分布</h3><p class="hint">${metricLabel} · 按最近入库日期，不等同批次库龄</p>${chart(ages, "var(--blue)", "入库时间分布")}</section></div><section class="occupancy-section occupancy-dispatch"><h3>出通单与齐套结构</h3><p class="hint">${metricLabel} · 出通单按订单行、齐套按订单判定</p>${chart(dispatch, "var(--orange)", "出通单与齐套分布")}</section>` : '<div class="empty">当前筛选下没有可计算的已入库未出货占用。</div>'}`;
  root.querySelector("form").addEventListener("submit", (event) => {
    event.preventDefault();
    const values = new FormData(event.currentTarget);
    Object.assign(settings, { query: String(values.get("query")).trim(), scope: values.get("scope"), notice: values.get("notice") });
    renderStockOccupancy();
  });
  root.querySelector("[data-occupancy-reset]").addEventListener("click", () => { Object.assign(settings, { query: "", scope: "all", notice: "all" }); renderStockOccupancy(); });
  root.querySelectorAll("[data-occupancy-metric]").forEach((node) => node.addEventListener("click", () => { settings.metric = node.dataset.occupancyMetric; renderStockOccupancy(); }));
  root.querySelector("[data-occupancy-dimension]")?.addEventListener("change", (event) => { settings.dimension = event.target.value; renderStockOccupancy(); });
  root.querySelectorAll("[data-occupancy-drill]").forEach((node) => node.addEventListener("click", () => {
    if (!canViewCustomerId()) return;
    const group = drills[Number(node.dataset.occupancyDrill)];
    const columns = orderExportColumns(true);
    const leading = ["客户", "客户简称", "订单号", "项次", "SKU"];
    openStatusDrill(null, { records: group.records, heading: group.heading, breakdown: false,
      context: `${state.asOfDate} · 已入库未出货占用 · 订单行估算`,
      columns: [...leading.map((label) => columns.find((column) => column.label === label)),
        { label: "占用数量（估算）", numeric: true, width: 150, value: (record) => record.occupiedQty ?? "" },
        { label: "距最近入库（天）", numeric: true, width: 150, value: (record) => record.stockAgeDays ?? "" },
        ...["入库", "已出", "未出", "入库时间"].map((label) => columns.find((column) => column.label === label)),
        ...columns.filter((column) => ![...leading, "入库", "已出", "未出", "入库时间"].includes(column.label))] });
  }));
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

async function loadUserPanelData(path) {
  const controller = new AbortController();
  let timer;
  try {
    return await Promise.race([
      api(path, { signal: controller.signal }),
      new Promise((_, reject) => {
        timer = setTimeout(() => {
          reject(new Error("请求超时，请重试。"));
          controller.abort();
        }, 10000);
      }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}

function renderUserLoginLogs(logs) {
  return `<div class="login-log-block">
          <div class="section-head compact-head">
            <div>
              <h2>登录日志</h2>
              <p>显示最近 200 条成功登录记录。</p>
            </div>
          </div>
          <div class="table-wrap login-log-wrap">
            <table class="login-log-table">
              <thead><tr><th>登录时间</th><th>用户名</th><th>备注</th><th>角色</th><th>来源 IP</th><th>浏览器</th></tr></thead>
              <tbody>
                ${
                  logs.length
                    ? logs
                        .map((log) => `<tr>
                          <td>${escapeHtml(log.loginAt || "")}</td>
                          <td>${escapeHtml(log.username || "")}</td>
                          <td>${escapeHtml(log.role === "admin" ? "管理员" : "查看")}</td>
                          <td>${escapeHtml(log.ip || "")}</td>
                          <td class="ua">${escapeHtml(log.userAgent || "")}</td>
                        </tr>`)
                        .join("")
                    : `<tr><td colspan="5" class="empty-cell">暂无登录日志</td></tr>`
                }
              </tbody>
            </table>
          </div>
        </div>`;
}

const userGroupExpanded = {admin: true, viewer: true};
function renderUsers() {
  if (!isAdmin()) {
    els.users.innerHTML = `<div class="empty">当前账号没有权限管理权限。</div>`;
    return;
  }
  const user = state.user, token = ++state.usersRenderToken;
  const current = () => isAdmin() && state.user === user && token === state.usersRenderToken;
  els.users.innerHTML = '<div class="section-head"><h2>权限管理</h2></div><div class="empty" role="status">正在加载账号列表...</div>';
  loadUserPanelData("/api/users")
    .then((payload) => {
      if (!current()) return;
      state.users = payload.users || [];
      els.users.innerHTML = `
        <div class="section-head">
          <div>
            <h2>权限管理</h2>
            <p>管理员可维护登录账号。查看账号只能看数据，不能导入每日三表，也不能管理账号。</p>
          </div>
        </div>
        <form id="userCreateForm" class="user-create">
          <label>用户名<input name="username" type="text" autocomplete="off" required /></label>
          <label>初始密码<input name="password" type="password" autocomplete="new-password" required /></label>
          <label>角色
            <select name="role">
              <option value="viewer">查看</option>
              <option value="admin">管理员</option>
            </select>
          </label>
          <button class="primary-button" type="submit">新增账号</button>
          <small id="userStatus"></small>
        </form>
        ${[['admin', '管理员'], ['viewer', '查看']].map(([role, label]) => `<details class="user-role-group" data-user-group="${role}" ${userGroupExpanded[role] ? 'open' : ''}><summary>${label}<span>${state.users.filter(user => user.role === role).length} 个账号</span></summary><div class="table-wrap user-table-wrap">
          <table class="user-table">
            <thead><tr><th>用户名</th><th>备注</th><th>角色</th><th>状态</th><th>创建时间</th><th>最后登录</th><th>操作</th></tr></thead>
            <tbody>
              ${state.users.filter(user => user.role === role)
                .map((user) => {
                  const resetting = state.passwordResetUser === user.username;
                  return `<tr>
                  <td>${escapeHtml(user.username)}</td><td>${escapeHtml(user.remark || "")}</td>
                  <td>
                    <select data-user-role="${escapeHtml(user.username)}" ${user.username === state.user.username ? "disabled" : ""}>
                      <option value="viewer" ${user.role === "viewer" ? "selected" : ""}>查看</option>
                      <option value="admin" ${user.role === "admin" ? "selected" : ""}>管理员</option>
                    </select>
                  </td>
                  <td>${user.active ? "启用" : "停用"}</td>
                  <td>${escapeHtml(user.createdAt || "")}</td>
                  <td>${escapeHtml(user.lastLogin || "")}</td>
                  <td class="user-actions">
                    <button type="button" data-user-toggle="${escapeHtml(user.username)}" ${user.username === state.user.username ? "disabled" : ""}>${user.active ? "停用" : "启用"}</button>
                    ${
                      resetting
                        ? `<span class="inline-reset">
                            <input type="password" data-user-reset-password="${escapeHtml(user.username)}" placeholder="新密码" autocomplete="new-password" />
                            <button type="button" data-user-reset-save="${escapeHtml(user.username)}">确认</button>
                            <button type="button" data-user-reset-cancel>取消</button>
                          </span>`
                        : `<button type="button" data-user-reset="${escapeHtml(user.username)}">重置密码</button>`
                    }
                    <button type="button" data-user-delete="${escapeHtml(user.username)}" ${user.username === state.user.username ? "disabled" : ""}>删除</button>
                  </td>
                </tr>`;
                })
                .join("")}
            </tbody>
          </table>
        </div></details>`).join('')}
        <div class="login-log-block"></div>`;
      els.users.querySelectorAll('[data-user-group]').forEach(group => group.addEventListener('toggle', () => {userGroupExpanded[group.dataset.userGroup] = group.open;}));
      bindUserPanel();
      const loadLogs = () => {
        const block = els.users.querySelector(".login-log-block");
        block.innerHTML = '<div class="section-head"><h2>登录日志</h2></div><div class="empty" role="status">正在加载登录日志...</div>';
        loadUserPanelData("/api/login-logs").then((payload) => {
          if (!current() || !block.isConnected) return;
          state.loginLogs = payload.logs || [];
          block.outerHTML = renderUserLoginLogs(state.loginLogs);
        }).catch((error) => {
          if (!current() || !block.isConnected) return;
          block.innerHTML = `<div class="section-head"><h2>登录日志</h2></div><div class="empty" role="alert">登录日志加载失败：${escapeHtml(error.message)} <button type="button" class="ghost-button" data-logs-retry>重试</button></div>`;
          block.querySelector("[data-logs-retry]").addEventListener("click", loadLogs);
        });
      };
      loadLogs();
    })
    .catch((error) => {
      if (!current()) return;
      els.users.innerHTML = `<div class="section-head"><h2>权限管理</h2></div><div class="empty" role="alert">账号列表加载失败：${escapeHtml(error.message)} <button type="button" class="ghost-button" data-users-retry>重试</button></div>`;
      els.users.querySelector("[data-users-retry]").addEventListener("click", renderUsers);
    });
}

function bindUserPanel() {
  const status = els.users.querySelector("#userStatus");
  els.users.querySelector("#userCreateForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    status.textContent = "正在新增账号...";
    try {
      await api("/api/users", {
        method: "POST",
        body: JSON.stringify({
          username: String(form.get("username") || "").trim(),
          password: String(form.get("password") || ""),
          role: String(form.get("role") || "viewer"),
        }),
      });
      status.textContent = "账号已新增";
      renderUsers();
    } catch (error) {
      status.textContent = error.message;
    }
  });

  els.users.querySelectorAll("[data-user-role]").forEach((select) => {
    select.addEventListener("change", async () => {
      try {
        await api(`/api/users/${encodeURIComponent(select.dataset.userRole)}`, {
          method: "PATCH",
          body: JSON.stringify({ role: select.value }),
        });
        renderUsers();
      } catch (error) {
        window.alert(error.message);
        renderUsers();
      }
    });
  });

  els.users.querySelectorAll("[data-user-toggle]").forEach((button) => {
    button.addEventListener("click", async () => {
      const username = button.dataset.userToggle;
      const user = state.users.find((item) => item.username === username);
      try {
        await api(`/api/users/${encodeURIComponent(username)}`, {
          method: "PATCH",
          body: JSON.stringify({ active: !user.active }),
        });
        renderUsers();
      } catch (error) {
        window.alert(error.message);
      }
    });
  });

  els.users.querySelectorAll("[data-user-reset]").forEach((button) => {
    button.addEventListener("click", () => {
      state.passwordResetUser = button.dataset.userReset;
      renderUsers();
    });
  });

  els.users.querySelectorAll("[data-user-reset-save]").forEach((button) => {
    button.addEventListener("click", async () => {
      const username = button.dataset.userResetSave;
      const input = els.users.querySelector(`[data-user-reset-password="${CSS.escape(username)}"]`);
      const password = input?.value || "";
      if (!password) {
        window.alert("请输入新密码");
        input?.focus();
        return;
      }
      try {
        await api(`/api/users/${encodeURIComponent(username)}`, {
          method: "PATCH",
          body: JSON.stringify({ password }),
        });
        state.passwordResetUser = "";
        window.alert("密码已重置");
        renderUsers();
      } catch (error) {
        window.alert(error.message);
      }
    });
  });

  els.users.querySelectorAll("[data-user-reset-password]").forEach((input) => {
    input.addEventListener("keydown", (event) => {
      if (event.key !== "Enter") return;
      event.preventDefault();
      const username = input.dataset.userResetPassword;
      els.users.querySelector(`[data-user-reset-save="${CSS.escape(username)}"]`)?.click();
    });
  });

  els.users.querySelectorAll("[data-user-reset-cancel]").forEach((button) => {
    button.addEventListener("click", () => {
      state.passwordResetUser = "";
      renderUsers();
    });
  });

  els.users.querySelector("[data-user-reset-password]")?.focus();

  els.users.querySelectorAll("[data-user-delete]").forEach((button) => {
    button.addEventListener("click", async () => {
      const username = button.dataset.userDelete;
      if (!window.confirm(`确定删除账号 ${username} 吗？删除后该账号将无法登录。`)) return;
      try {
        await api(`/api/users/${encodeURIComponent(username)}`, {
          method: "DELETE",
          body: "{}",
        });
        renderUsers();
      } catch (error) {
        window.alert(error.message);
      }
    });
  });
}

function render() {
  applyFilters();
  renderKpis();
  renderActivePanel();
}

function renderCustomerAnalysis() {
  const admin = isAdmin();
  const ratingsRoot = document.querySelector('#customerRatingsPanel');
  const scoringRoot = document.querySelector('#customerScoringPanel');
  ratingsRoot.classList.toggle('hidden', !admin);
  ratingsRoot.classList.toggle('active', admin);
  scoringRoot.classList.toggle('hidden', admin);
  scoringRoot.classList.toggle('active', !admin);
  if (admin) customerRatings.render(); else customerScoring.render();
}

function renderActivePanel() {
  const renderers = {
    orders: renderOrders,
    customers: renderCustomers,
    products: renderProducts,
    alerts: renderAlerts,
    kitting: renderKitting,
    summary: renderSummary,
    compare: renderCompare,
    orderStatusOverview: renderStatusAnalysis,
    customerOrders: renderCustomerOrders,
    warehouseCustomerOrders: renderWarehouseCustomerOrders,
    productionPlanning: renderProductionPlanning,
    stockOccupancy: renderStockOccupancy,
    salesAnalysis: salesAnalysis.render,
    customerRatings: customerRatings.render,
    customerScoring: customerScoring.render,
    customerAnalysis: renderCustomerAnalysis,
    users: renderUsers,
  };
  renderers[state.activeTab]?.();
}

function setSidebarCollapsed(collapsed) {
  state.sidebarCollapsed = collapsed;
  els.workbench?.classList.toggle("sidebar-collapsed", collapsed);
  if (els.sidebarToggle) {
    els.sidebarToggle.textContent = collapsed ? "›" : "‹";
    els.sidebarToggle.title = collapsed ? "展开侧边栏" : "隐藏侧边栏";
    els.sidebarToggle.setAttribute("aria-expanded", collapsed ? "false" : "true");
  }
}

function showTab(tab) {
  if (["salesAnalysis", "customerRatings", "customerScoring"].includes(tab)) tab = "customerAnalysis";
  if (tab === "users" && !isAdmin()) tab = "orders";
  if (["salesAnalysis", "customerRatings"].includes(tab) && !canViewCustomerId()) tab = "orders";
  document.querySelector('.sidebar-filters').classList.toggle('hidden', ['salesAnalysis', 'customerRatings', 'customerScoring', 'customerAnalysis'].includes(tab));
  state.activeTab = tab;
  const navGroup = document.querySelector(`.tab[data-tab="${tab}"]`)?.closest(".nav-group");
  if (navGroup) navGroup.open = true;
  if (tab !== "orders") state.ordersRenderToken += 1;
  document.querySelectorAll(".tab").forEach((button) => button.classList.toggle("active", button.dataset.tab === tab));
  document.querySelectorAll(".panel").forEach((panel) => panel.classList.remove("active"));
  document.querySelectorAll(".customer-module").forEach(node => node.classList.remove("active"));
  document.querySelector(`#${tab}Panel`).classList.add("active");
  renderActivePanel();
}

function populatePlannerOptions() {
  const planners = [...new Set(state.records.map((r) => r.planner).filter(Boolean))].sort((a, b) => a.localeCompare(b, "zh-CN"));
  els.planner.innerHTML = `<option value="all">全部计划员</option>${planners.map((p) => `<option value="${p}">${p}</option>`).join("")}`;
}

function populateSalesPersonOptions() {
  const salesPeople = [...new Set(state.records.map((r) => r.salesPerson).filter(Boolean))].sort((a, b) => a.localeCompare(b, "zh-CN"));
  els.salesPerson.innerHTML = `<option value="all">全部业务员</option>${salesPeople.map((p) => `<option value="${p}">${p}</option>`).join("")}`;
}

function productionProgressValue(record) {
  return record.productionProgress || record.workOrderStatus || "未标明";
}

function populateProductionProgressOptions() {
  const progressValues = [...new Set(state.records.map(productionProgressValue).filter(Boolean))].sort((a, b) => {
    if (a === "未标明") return 1;
    if (b === "未标明") return -1;
    return a.localeCompare(b, "zh-CN");
  });
  els.productionProgress.innerHTML = `<option value="all">全部进度</option>${progressValues.map((p) => `<option value="${p}">${p}</option>`).join("")}`;
}

function populateFilterOptions() {
  populatePlannerOptions();
  populateSalesPersonOptions();
  populateProductionProgressOptions();
}

function resetFiltersAfterImport() {
  state.status = "all";
  state.bucket = "all";
  state.planner = "all";
  state.salesPerson = "all";
  state.productionProgress = "all";
  state.columnFilters = {};
  state.openColumnFilter = "";
  state.selectedCustomer = "";
  els.status.value = "all";
  els.bucket.value = "all";
  els.planner.value = "all";
  els.salesPerson.value = "all";
  els.productionProgress.value = "all";
}

els.loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  els.loginError.textContent = "正在登录...";
  try {
    const payload = await api("/api/login", {
      method: "POST",
      body: JSON.stringify({
        username: els.loginUser.value.trim(),
        password: els.loginPass.value,
      }),
    });
    state.user = payload.user;
    els.loginError.textContent = "";
    showDashboard();
    await loadData();
  } catch (error) {
    showLogin(error.message);
  }
});

els.logoutButton.addEventListener("click", async () => {
  try {
    await api("/api/logout", { method: "POST", body: "{}" });
  } catch {
    // The local page still returns to the login screen if the server already dropped the session.
  }
  showLogin();
});

els.openLoginButton.addEventListener("click", () => openLoginModal());
els.closeLoginButton.addEventListener("click", closeLoginModal);
els.loginModal.querySelector("[data-close-login]").addEventListener("click", closeLoginModal);
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !els.loginModal.classList.contains("hidden")) closeLoginModal();
});

async function loadData() {
  await loadHistory();
  await loadKittingReference();
  const response = await fetch("./public/data/orders.json");
  if (response.status === 401) {
    showLogin("登录已过期，请重新登录。");
    return;
  }
  if (!response.ok) throw new Error(`订单数据加载失败 ${response.status}`);
  const payload = await response.json();
  applyOrderDataset(payload, effectiveAsOfDate(payload));
}

async function loadKittingReference() {
  try {
    const response = await fetch("./public/data/kitting-reference.json", { cache: "no-store" });
    if (!response.ok) {
      state.kittingReference = { orders: {} };
      return;
    }
    const payload = await response.json();
    state.kittingReference = payload && payload.orders ? payload : { orders: {} };
  } catch {
    state.kittingReference = { orders: {} };
  } finally {
    state.columnFilterOptionCache.clear();
  }
}

async function loadHistory() {
  try {
    const historyResponse = await fetch("./public/data/daily-history.json");
    if (historyResponse.ok) {
      const historyPayload = await historyResponse.json();
      state.dailyHistory = historyPayload.datasets || [];
    } else {
      state.dailyHistory = [];
    }
  } catch {
    state.dailyHistory = [];
  }
}

function applyOrderDataset(payload, fallbackDate) {
  const asOfDate = String(payload?.asOfDate || fallbackDate || todayIso()).slice(0, 10);
  state.asOfDate = asOfDate;
  els.asOfDate.value = asOfDate;
  state.records = payload.records || [];
  resetDerivedCaches();
  state.generatedAt = payload.generatedAt || "";
  state.sources = payload.sources || { formal: state.records.length, overdue: 0, inventory: 0 };
  state.delayDatasetCache.set(asOfDate, payload);
  els.dataTime.textContent = `数据生成：${formatGeneratedAt(payload.generatedAt)}`;
  els.freshness.textContent = `当前数据 ${asOfDate} 实时计算`;
  populateFilterOptions();
  render();
}

async function loadOrdersForDate(date) {
  const targetDate = String(date || "").slice(0, 10);
  const item = delayDatasets().find((dataset) => dataset.date === targetDate);
  const file = item?.file || `orders-${targetDate}.json`;
  if (!targetDate || !item?.file) {
    els.freshness.textContent = `${targetDate || "所选日期"} 没有可加载的数据文件`;
    return;
  }
  els.freshness.textContent = `正在加载 ${item.label || targetDate} 数据...`;
  const response = await fetch(`./public/data/${file}`);
  if (response.status === 401) {
    showLogin("登录已过期，请重新登录。");
    return;
  }
  if (!response.ok) throw new Error(`${item.label || targetDate} 数据加载失败 ${response.status}`);
  const payload = await response.json();
  state.columnFilters = {};
  state.openColumnFilter = "";
  state.selectedCustomer = "";
  applyOrderDataset(payload, targetDate);
}

async function boot() {
  try {
    const payload = await api("/api/me");
    state.user = payload.user;
  } catch {
    showLogin();
    return;
  }
  showDashboard();
  await loadData();
}

async function handleExcelImport(fileList) {
  const incoming = [...(fileList || [])];
  const files = incoming.filter((file) => /\.xlsx$/i.test(file.name));
  const unsupported = incoming.filter((file) => !/\.xlsx$/i.test(file.name));
  if (unsupported.length) {
    els.importStatus.textContent = `导入失败：当前只支持 .xlsx，未支持文件：${unsupported.map((file) => file.name).join("、")}`;
    return;
  }
  if (!files.length) {
    els.importStatus.textContent = "请选择 3 张 .xlsx Excel 文件";
    return;
  }
  if (!isAdmin()) {
    els.importStatus.textContent = "当前账号没有导入权限";
    return;
  }
  els.importDropZone.classList.add("importing");
  els.importStatus.textContent = "正在确认登录状态...";
  try {
    const me = await api("/api/me");
    state.user = me.user;
    applyPermissions();
    if (!isAdmin()) {
      throw new Error("当前账号没有导入权限");
    }
    els.importStatus.textContent = `正在导入：${files.map((file) => file.name).join("、")}`;
    const result = await importDailyFiles(files);
    const asOfDate = inferredImportDate(files);
    const generatedAt = localDateTimeText();
    const payload = {
      asOfDate,
      label: labelForIsoDate(asOfDate),
      generatedAt,
      sources: result.counts,
      metrics: metricsFromRecords(result.records, asOfDate),
      records: result.records,
    };
    els.importStatus.textContent = "三表已解析，正在保存到服务器";
    const saved = await api("/api/import-daily", {
      method: "POST",
      body: JSON.stringify(payload),
    });
    const savedDate = saved.asOfDate || asOfDate;
    state.dailyHistory = saved.history || state.dailyHistory;
    resetFiltersAfterImport();
    await loadData();
    els.importStatus.textContent = `已保存：${fmtNumber(saved.records)} 行；判定日期 ${savedDate}；主表 ${fmtNumber(result.counts.formal)}，路径 ${fmtNumber(result.counts.overdue)}，库存 ${fmtNumber(result.counts.inventory)}，出通单匹配 ${fmtNumber(saved.shipmentNoticeMatched || 0)} 行`;
  } catch (error) {
    els.importStatus.textContent = `导入失败：${error.message}`;
  } finally {
    els.importDropZone.classList.remove("importing");
  }
}

els.excelImport.addEventListener("change", async () => {
  await handleExcelImport(els.excelImport.files);
  els.excelImport.value = "";
});

els.asOfDate.addEventListener("change", async () => {
  try {
    await loadOrdersForDate(els.asOfDate.value || todayIso());
  } catch (error) {
    els.freshness.textContent = error.message;
    els.asOfDate.value = state.asOfDate;
  }
});

els.status.addEventListener("change", () => {
  state.status = els.status.value;
  state.selectedCustomer = "";
  render();
});

els.bucket.addEventListener("change", () => {
  state.bucket = els.bucket.value;
  state.selectedCustomer = "";
  if (state.bucket !== "all") {
    state.status = "all";
    els.status.value = "all";
  }
  render();
});

els.planner.addEventListener("change", () => {
  state.planner = els.planner.value;
  state.selectedCustomer = "";
  render();
});

els.salesPerson.addEventListener("change", () => {
  state.salesPerson = els.salesPerson.value;
  state.selectedCustomer = "";
  render();
});

els.productionProgress.addEventListener("change", () => {
  state.productionProgress = els.productionProgress.value;
  state.selectedCustomer = "";
  render();
});

document.querySelectorAll(".tab").forEach((button) => {
  button.addEventListener("click", () => showTab(button.dataset.tab));
});

els.sidebarToggle?.addEventListener("click", () => {
  setSidebarCollapsed(!state.sidebarCollapsed);
});
setSidebarCollapsed(state.sidebarCollapsed);

els.shipmentImportButton.addEventListener("click", openShipmentImport);

els.importButton.addEventListener("click", () => {
  if (!isAdmin()) return;
  els.excelImport.click();
});

["dragenter", "dragover"].forEach((eventName) => {
  els.importDropZone.addEventListener(eventName, (event) => {
    if (!isAdmin()) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = "copy";
    els.importDropZone.classList.add("dragging");
  });
});

els.importDropZone.addEventListener("dragleave", (event) => {
  if (els.importDropZone.contains(event.relatedTarget)) return;
  els.importDropZone.classList.remove("dragging");
});

els.importDropZone.addEventListener("drop", async (event) => {
  if (!isAdmin()) return;
  event.preventDefault();
  els.importDropZone.classList.remove("dragging");
  await handleExcelImport(event.dataTransfer.files);
});

window.addEventListener("resize", () => {
  if (!els.loginView.hidden) resizeSpaceCanvas();
  window.clearTimeout(state.summaryResizeTimer);
  state.summaryResizeTimer = window.setTimeout(() => {
    if (state.activeTab === "summary" && state.records.length) renderSummary();
  }, 120);
});

boot().catch((error) => {
  document.querySelector("#app").innerHTML = `<div class="empty">数据加载失败：${error.message}</div>`;
});
