"""Daily read-only warehouse sales refresh; reviewed customer grades are retained."""
import json
import secrets
import sys
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

from sales_analysis import normalize_snapshot, read_snapshot, save_snapshot

LOCAL_TIME = timezone(timedelta(hours=8))
PRIVATE_FILES = {'warehouse-connection.json', 'warehouse-sales-state.json', 'sales-grade-reference.json',
                 'customer-rating-scores.json', 'customer-rating-ledger.json', 'customer-rating-cache.json'}


def atomic_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.' + secrets.token_hex(8) + '.tmp')
    try:
        temporary.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
        temporary.chmod(0o600)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


class WarehouseSales:
    def __init__(self, data_dir, data_lock):
        self.root = Path(data_dir)
        self.data_lock = data_lock
        self.guard = threading.Lock()
        self.config_path = self.root.parent / 'config' / 'warehouse-connection.json'
        self.state_path = self.root / 'warehouse-sales-state.json'
        self.grades_path = self.root / 'sales-grade-reference.json'
        self.config = json.loads(self.config_path.read_text()) if self.config_path.exists() else None
        self.state = json.loads(self.state_path.read_text()) if self.state_path.exists() else {}
        self.running = False

    def status(self):
        with self.guard:
            return {'enabled': bool(self.config), 'running': self.running, 'schedule': '每天08:00',
                    'lastSuccess': self.state.get('lastSuccess', ''), 'lastAttempt': self.state.get('lastAttempt', ''),
                    'lastError': self.state.get('lastError', ''), 'warehouseUpdatedAt': self.state.get('warehouseUpdatedAt', '')}

    def query(self, start, end, sql_file='warehouse-sales.sql'):
        dependency_path = str(self.root.parent / 'runtime' / 'python-deps')
        if dependency_path not in sys.path:
            sys.path.insert(0, dependency_path)
        import pymysql
        config = self.config
        connection = pymysql.connect(host=config['host'], port=int(config.get('port', 3306)), user=config['user'],
                                     password=config['password'], database=config['database'], charset='utf8mb4',
                                     connect_timeout=10, read_timeout=180, write_timeout=10,
                                     cursorclass=pymysql.cursors.DictCursor, local_infile=False)
        try:
            with connection.cursor() as cursor:
                cursor.execute('SET SESSION MAX_EXECUTION_TIME=120000')
                cursor.execute('START TRANSACTION READ ONLY')
                next_day = end + timedelta(days=1)
                cursor.execute(Path(__file__).with_name(sql_file).read_text(), (start, next_day, start, next_day))
                rows = cursor.fetchall()
                cursor.execute('SELECT MAX(ods_insert_time) AS updated FROM ods_erp_oga_file')
                updated = cursor.fetchone()['updated']
                return rows, str(updated or '')
        finally:
            connection.rollback()
            connection.close()

    def run(self):
        if not self.config:
            raise ValueError('尚未配置数仓连接')
        with self.guard:
            if self.running:
                raise ValueError('数据库同步正在进行')
            self.running = True
        try:
            now = datetime.now(LOCAL_TIME)
            with self.data_lock:
                previous = read_snapshot(self.root)
                reference = json.loads(self.grades_path.read_text()) if self.grades_path.exists() else {}
                reference.update({row['customerId']: row['grade'] for row in previous.get('records', [])})
            rows, updated = self.query(self.config.get('periodStart', '2026-01-01'), now.date())
            records = []
            for row in rows:
                customer = str(row['customerId']).strip()
                amount = format(row['amount'], 'f')
                if '.' in amount:
                    amount = amount.rstrip('0').rstrip('.')
                records.append({'customerId': customer, 'customerName': row['customerName'] or '',
                                'industry': row['industry'] or '', 'salesPerson': row['salesPerson'] or '',
                                'grade': reference.get(customer, 'S'), 'amount': amount})
            snapshot = normalize_snapshot({'records': records, 'periodStart': self.config.get('periodStart', '2026-01-01'),
                                           'periodEnd': now.date().isoformat(), 'sourceFile': 'warehouse · 出货减销退'})
            snapshot['sourceType'] = 'warehouse'
            snapshot['warehouseUpdatedAt'] = updated
            with self.data_lock:
                current = read_snapshot(self.root)
                if current.get('revision', '') != previous.get('revision', ''):
                    raise ValueError('同步期间销售数据已更新，请重新同步')
                reference.update({row['customerId']:row['grade'] for row in records})
                atomic_json(self.grades_path, reference)
                saved = save_snapshot(self.root, snapshot, current, 'warehouse-sync')
            with self.guard:
                self.state = {'lastAttempt': now.isoformat(), 'lastSuccess': datetime.now(LOCAL_TIME).isoformat(),
                              'lastError': '', 'warehouseUpdatedAt': updated}
                atomic_json(self.state_path, self.state)
            return saved
        except Exception as error:
            with self.guard:
                self.state['lastAttempt'] = datetime.now(LOCAL_TIME).isoformat()
                self.state['lastError'] = str(error) if isinstance(error, ValueError) else '数据库连接或查询失败，请检查数仓连接'
                atomic_json(self.state_path, self.state)
            raise
        finally:
            with self.guard:
                self.running = False

    def start(self):
        if not self.config:
            return
        def loop():
            while True:
                now = datetime.now(LOCAL_TIME)
                due = now.replace(hour=8, minute=0, second=0, microsecond=0)
                success = self.status()['lastSuccess']
                # A manual refresh before 08:00 does not replace the scheduled morning refresh.
                succeeded_after_due = bool(success) and datetime.fromisoformat(success) >= due
                if now >= due and not succeeded_after_due:
                    try:
                        self.run()
                    except Exception:
                        # Retry after temporary warehouse outages, retaining the previous snapshot.
                        threading.Event().wait(1800)
                threading.Event().wait(30)
        threading.Thread(target=loop, name='warehouse-sales-daily', daemon=True).start()
