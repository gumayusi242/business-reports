#!/usr/bin/env python3
import argparse
import base64
import hashlib
import hmac
import json
import math
import mimetypes
import os
import posixpath
import secrets
import threading
from datetime import datetime, timedelta, timezone
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote, urlparse, parse_qs
from sales_analysis import MAX_BODY_BYTES, normalize_snapshot, read_snapshot, save_snapshot, summarize
from warehouse_sales import PRIVATE_FILES, WarehouseSales
from customer_ratings import CustomerRatings
from customer_receivables import CustomerReceivables
from customer_credit import CustomerCredit


ROOT = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("ORDER_DELIVERY_DATA_DIR", ROOT / "data")).resolve()
USERS_FILE = DATA_DIR / "users.json"
LOGIN_LOG_FILE = DATA_DIR / "login-log.jsonl"
PUBLIC_DATA_DIR = DATA_DIR / "public-data"
SESSION_SECRET_FILE = DATA_DIR / "session-secret.key"
SESSION_COOKIE = "od_session"
SESSION_TTL = timedelta(hours=10)
HASH_ITERATIONS = 180_000
SESSIONS = {}
LOCK = threading.Lock()
WAREHOUSE_SALES = WarehouseSales(DATA_DIR, LOCK)
CUSTOMER_RATINGS = CustomerRatings(DATA_DIR, WAREHOUSE_SALES)
CUSTOMER_RECEIVABLES = CustomerReceivables(WAREHOUSE_SALES, CUSTOMER_RATINGS)
CUSTOMER_CREDIT = CustomerCredit(CUSTOMER_RECEIVABLES.connect, DATA_DIR)
CUSTOMER_RATINGS.credit_provider = CUSTOMER_CREDIT.evaluate


# Direct-report access is keyed by ERP employee code; names are display labels only.
CUSTOMER_TEAMS = {'90001': {'name': '示例销售团队', 'reports': ['90002', '90003']}}


def customer_portfolio(user):
  """Resolve own/editable and direct-team/readable customers by employee code."""
  if user.get('role') == 'admin':
    return None
  employee = str(user.get('username') or '').strip()
  team = CUSTOMER_TEAMS.get(employee)
  scope = {'employeeCode': employee, 'salesPerson': '', 'bound': False,
           'customerIds': set(), 'editableCustomerIds': set(), 'owners': {},
           'isManager': bool(team), 'teamName': team['name'] if team else '', 'members': []}
  if employee == '99999':
    return scope
  if not employee.isascii() or not employee.isdigit():
    return scope
  connection = CUSTOMER_RECEIVABLES.connect()
  try:
    with connection.cursor() as cursor:
      cursor.execute('SET SESSION MAX_EXECUTION_TIME=30000')
      cursor.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ')
      cursor.execute('START TRANSACTION READ ONLY')
      for code in [employee] + (team['reports'] if team else []):
        cursor.execute('SELECT gen02 AS name FROM ods_erp_gen_file WHERE gen01=%s', (code,))
        person = cursor.fetchone()
        if not person:
          if code == employee: break
          continue
        name = str(person.get('name') or '').strip()
        if code == employee:
          scope.update(bound=True, salesPerson=name)
        elif not scope['bound']:
          # Unbound accounts never inherit a team, even if a configuration is stale.
          break
        scope['members'].append({'employeeCode': code, 'salesPerson': name})
        cursor.execute('SELECT occ01 AS customerId FROM ods_erp_occ_file WHERE occ04=%s', (code,))
        ids = {str(row['customerId']).strip() for row in cursor.fetchall()}
        scope['customerIds'].update(ids)
        if code == employee:
          scope['editableCustomerIds'].update(ids)
        for customer in ids:
          scope['owners'][customer] = {'employeeCode': code, 'salesPerson': name}
      return scope
  finally:
    try: connection.rollback()
    finally: connection.close()


def scoring_view(snapshot, user, portfolio=None):
  if portfolio is None and user.get('role') != 'admin':
    portfolio = customer_portfolio(user)
  fields = ('customerId', 'customerName', 'salesPerson', 'industry', 'customerGroup', 'currentGrade', 'totalScore',
            'opportunity', 'position', 'credit', 'scoreDetails', 'newCustomer', 'customerRevision', 'lowSales', 'scoreExempt', 'scoreExemptReason', 'scoreNotApplicable')
  records = snapshot['records'] if portfolio is None else [row for row in snapshot['records'] if row['customerId'] in portfolio['customerIds']]
  rows = [{key: row.get(key) for key in fields} for row in records]
  for row in rows:
    row['canEditScore'] = not row.get('scoreNotApplicable') and (portfolio is None or row['customerId'] in portfolio['editableCustomerIds'])
    if portfolio is not None:
      row.update(portfolio['owners'][row['customerId']])
  return {'revision': snapshot['revision'], 'year': snapshot['year'], 'month': snapshot['month'],
          'scope': {'allCustomers': True} if portfolio is None else {k: portfolio[k] for k in ('employeeCode','salesPerson','bound','isManager','teamName','members')},
          'records': rows}


def now_iso():
  return datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M:%S")


def b64url_encode(raw):
  return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def b64url_decode(value):
  padding = "=" * (-len(value) % 4)
  return base64.urlsafe_b64decode((value + padding).encode("ascii"))


def load_session_secret():
  DATA_DIR.mkdir(parents=True, exist_ok=True)
  if not SESSION_SECRET_FILE.exists():
    SESSION_SECRET_FILE.write_text(secrets.token_urlsafe(48), encoding="utf-8")
    try:
      os.chmod(SESSION_SECRET_FILE, 0o600)
    except OSError:
      pass
  return SESSION_SECRET_FILE.read_text(encoding="utf-8").strip().encode("utf-8")


def sign_session_payload(payload):
  body = b64url_encode(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
  signature = hmac.new(load_session_secret(), body.encode("ascii"), hashlib.sha256).digest()
  return f"{body}.{b64url_encode(signature)}"


def unsign_session_payload(token):
  try:
    body, signature = str(token or "").split(".", 1)
    expected = hmac.new(load_session_secret(), body.encode("ascii"), hashlib.sha256).digest()
    if not hmac.compare_digest(b64url_decode(signature), expected):
      return None
    return json.loads(b64url_decode(body).decode("utf-8"))
  except Exception:
    return None


def hash_password(password, salt=None, iterations=HASH_ITERATIONS):
  salt_bytes = base64.b64decode(salt) if salt else secrets.token_bytes(16)
  digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt_bytes, iterations)
  return {
    "salt": base64.b64encode(salt_bytes).decode("ascii"),
    "hash": base64.b64encode(digest).decode("ascii"),
    "iterations": iterations,
  }


def verify_password(password, user):
  expected = hash_password(password, user["salt"], int(user.get("iterations", HASH_ITERATIONS)))["hash"]
  return hmac.compare_digest(expected, user.get("passwordHash", ""))


def load_store():
  DATA_DIR.mkdir(parents=True, exist_ok=True)
  if not USERS_FILE.exists():
    password = os.environ.get("ORDER_DELIVERY_ADMIN_PASSWORD") or secrets.token_urlsafe(12)
    hashed = hash_password(password)
    USERS_FILE.write_text(json.dumps({
      "users": [{
        "username": "admin",
        "role": "admin",
        "active": True,
        "salt": hashed["salt"],
        "passwordHash": hashed["hash"],
        "iterations": hashed["iterations"],
        "createdAt": now_iso(),
        "lastLogin": "",
        "remark": "",
      }],
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Initial admin user created: admin / {password}", flush=True)
  return json.loads(USERS_FILE.read_text(encoding="utf-8"))


def save_store(store):
  DATA_DIR.mkdir(parents=True, exist_ok=True)
  tmp = USERS_FILE.with_suffix(".tmp")
  tmp.write_text(json.dumps(store, ensure_ascii=False, indent=2), encoding="utf-8")
  tmp.replace(USERS_FILE)


def public_user(user):
  return {
    "username": user.get("username", ""),
    "remark": user.get("remark", ""),
    "role": user.get("role", "viewer"),
    "active": bool(user.get("active", True)),
    "createdAt": user.get("createdAt", ""),
    "lastLogin": user.get("lastLogin", ""),
  }


def find_user(store, username):
  for user in store.get("users", []):
    if user.get("username") == username:
      return user
  return None


def append_login_log(handler, user):
  DATA_DIR.mkdir(parents=True, exist_ok=True)
  entry = {
    "username": user.get("username", ""),
    "remark": user.get("remark", ""),
    "role": user.get("role", "viewer"),
    "loginAt": now_iso(),
    "ip": handler.client_address[0] if handler.client_address else "",
    "userAgent": handler.headers.get("User-Agent", ""),
  }
  with LOGIN_LOG_FILE.open("a", encoding="utf-8") as file:
    file.write(json.dumps(entry, ensure_ascii=False, separators=(",", ":")) + "\n")


def read_login_logs(limit=200):
  if not LOGIN_LOG_FILE.exists():
    return []
  lines = LOGIN_LOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
  logs = []
  for line in lines[-limit:]:
    try:
      logs.append(json.loads(line))
    except json.JSONDecodeError:
      continue
  logs.reverse()
  return logs


def parse_body(handler):
  length = int(handler.headers.get("Content-Length") or 0)
  if length <= 0:
    return {}
  raw = handler.rfile.read(length)
  return json.loads(raw.decode("utf-8") or "{}")


def mask_customer_identifiers(value):
  if isinstance(value, list):
    return [mask_customer_identifiers(item) for item in value]
  if isinstance(value, dict):
    masked = {}
    for key, item in value.items():
      if key in {"customerId", "customerNo", "customerShortName", "客户编号", "客户简称", "客户名称"}:
        masked[key] = ""
      else:
        masked[key] = mask_customer_identifiers(item)
    return masked
  return value


def label_for_date(value):
  try:
    parsed = datetime.strptime(str(value)[:10], "%Y-%m-%d")
    return f"{parsed.month}月{parsed.day}日"
  except Exception:
    return str(value or "")


def valid_iso_date(value):
  try:
    datetime.strptime(str(value)[:10], "%Y-%m-%d")
    return str(value)[:10]
  except Exception:
    return ""


def generated_date(value):
  return valid_iso_date(str(value or "").replace("T", " ")[:10])


def import_as_of_date(raw_as_of_date, generated_at):
  saved_date = valid_iso_date(raw_as_of_date)
  imported_date = generated_date(generated_at)
  if imported_date and saved_date and imported_date > saved_date:
    return imported_date
  return saved_date or imported_date


def read_json_file(path, fallback):
  if not path.exists():
    return fallback
  return json.loads(path.read_text(encoding="utf-8"))


def write_json_atomic(path, payload):
  path.parent.mkdir(parents=True, exist_ok=True)
  tmp = path.with_suffix(path.suffix + ".tmp")
  tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
  tmp.replace(path)


def build_kitting_reference(body):
  if not isinstance(body, dict):
    raise ValueError("导入数据格式错误")
  rows = body.get("rows")
  if not isinstance(rows, list) or not rows or len(rows) > 150000:
    raise ValueError("请导入包含明细的 Excel，最多支持 150000 行")
  source_file = str(body.get("sourceFile") or "").replace("\\", "/").rsplit("/", 1)[-1]
  if not source_file.lower().endswith(".xlsx") or len(source_file) > 255:
    raise ValueError("请选择 .xlsx 格式的齐套明细表")
  as_of_date = str(body.get("asOfDate") or "")
  if as_of_date and (len(as_of_date) != 10 or valid_iso_date(as_of_date) != as_of_date):
    raise ValueError("文件日期格式不正确")
  orders = {}
  skipped = 0
  for index, row in enumerate(rows, 1):
    if not isinstance(row, dict):
      raise ValueError(f"第 {index} 条明细格式错误")
    order_no = str(row.get("orderNo") or "").strip()
    sku = str(row.get("sku") or "").strip()
    if not order_no or not sku or len(order_no) > 120 or len(sku) > 120:
      raise ValueError(f"第 {index} 条明细缺少有效订单号或品号")
    quantity = row.get("unshippedQty")
    if isinstance(quantity, bool) or not isinstance(quantity, (int, float)) or not math.isfinite(quantity):
      raise ValueError(f"订单 {order_no} 的未发数量不是有效数字")
    if quantity <= 0:
      skipped += 1
      continue
    status = str(row.get("status") or "").strip()
    if status not in {"齐套", "未齐套"}:
      raise ValueError(f"订单 {order_no} 的是否齐套为“{status[:30]}”，仅支持齐套或未齐套")
    order = orders.setdefault(order_no, {
      "skus": set(), "rowCount": 0, "unshippedQty": 0,
      "readyRows": 0, "shortRows": 0, "unknownRows": 0,
    })
    order["skus"].add(sku)
    order["rowCount"] += 1
    order["unshippedQty"] += quantity
    if not math.isfinite(order["unshippedQty"]):
      raise ValueError(f"订单 {order_no} 的未发数量合计过大")
    order["readyRows" if status == "齐套" else "shortRows"] += 1
  if not orders:
    raise ValueError("文件中没有未发数量大于 0 的有效订单，旧数据未替换")
  for order in orders.values():
    order["skuCount"] = len(order.pop("skus"))
    order["unshippedQty"] = round(order["unshippedQty"], 6)
    order["kitted"] = order["shortRows"] == 0
    order["status"] = "齐套" if order["kitted"] else "未齐套"
  ready_count = sum(order["kitted"] for order in orders.values())
  return {
    "sourceFile": source_file, "asOfDate": as_of_date, "generatedAt": now_iso(),
    "orderCount": len(orders), "kittedOrderCount": ready_count,
    "shortOrderCount": len(orders) - ready_count,
    "rowCount": sum(order["rowCount"] for order in orders.values()),
    "skippedRows": skipped, "orders": orders,
  }


def compact_text(value):
  return " ".join(str(value or "").strip().split())


def append_unique_text(existing, value):
  value = compact_text(value)
  if not value:
    return compact_text(existing)
  parts = [part for part in str(existing or "").split("、") if part]
  for part in value.split("、"):
    part = compact_text(part)
    if part and part not in parts:
      parts.append(part)
  return "、".join(parts)


def order_sku_key(record):
  order_no = compact_text(record.get("orderNo"))
  sku = compact_text(record.get("sku"))
  if not order_no or not sku:
    return ""
  return f"{order_no}|{sku}"


def shipment_notice_lookup(exclude_filename=""):
  lookup = {}
  files = sorted(PUBLIC_DATA_DIR.glob("orders-*.json"))
  fallback_dir = ROOT / "public" / "data"
  if fallback_dir.exists():
    files.extend(sorted(fallback_dir.glob("orders-*.json")))
  seen = set()
  for path in files:
    if path.name == exclude_filename or path in seen:
      continue
    seen.add(path)
    payload = read_json_file(path, {})
    for record in payload.get("records") or []:
      key = order_sku_key(record)
      notice_no = compact_text(record.get("shipmentNoticeNo"))
      notice_date = compact_text(record.get("shipmentNoticeDate"))
      if not key or (not notice_no and not notice_date):
        continue
      item = lookup.setdefault(key, {"shipmentNoticeNo": "", "shipmentNoticeDate": ""})
      item["shipmentNoticeNo"] = append_unique_text(item.get("shipmentNoticeNo"), notice_no)
      item["shipmentNoticeDate"] = append_unique_text(item.get("shipmentNoticeDate"), notice_date)
  return lookup


def shipment_reference_for_date(as_of_date, reference):
  versions = [reference] + reference.get("history", []) if reference else []
  eligible = [item for item in versions if item.get("effectiveDate", "9999") <= as_of_date]
  return max(eligible, key=lambda item: item["effectiveDate"], default={})


def apply_shipment_reference(payload, reference=None):
  reference = reference if reference is not None else read_json_file(PUBLIC_DATA_DIR / "shipment-reference.json", {})
  reference = shipment_reference_for_date(str(payload.get("asOfDate", "")), reference)
  if not reference:
    return payload
  lookup = reference.get("lookup", {})
  for record in payload.get("records", []):
    item = lookup.get(order_sku_key(record), {})
    record["shipmentNoticeNo"] = item.get("shipmentNoticeNo", "")
    record["shipmentNoticeDate"] = item.get("shipmentNoticeDate", "")
  return payload


def build_shipment_import(body, current, previous):
  if not isinstance(body, dict) or body.get("mode") not in {"append", "replace"}:
    raise ValueError("请选择追加或完整清单替换")
  rows = body.get("rows")
  if not isinstance(rows, list) or not rows or len(rows) > 150000:
    raise ValueError("出通单明细不能为空且不能超过150000行")
  imported = {}
  for index, row in enumerate(rows, 1):
    if not isinstance(row, dict):
      raise ValueError(f"第{index}行格式无效")
    values = {field: compact_text(row.get(field)) for field in ["orderNo", "sku", "shipmentNoticeNo", "shipmentNoticeDate"]}
    if any(not isinstance(row.get(field, ""), (str, int, float)) or len(values[field]) > 500 for field in values):
      raise ValueError(f"第{index}行字段格式无效或过长")
    if not values["orderNo"] or not values["sku"] or not values["shipmentNoticeNo"]:
      raise ValueError(f"第{index}行缺少订单号、产品编号或出通单号")
    key = order_sku_key(values)
    item = imported.setdefault(key, {"shipmentNoticeNo": "", "shipmentNoticeDate": ""})
    for field in item:
      item[field] = append_unique_text(item[field], values[field])
  lookup = {}
  if body["mode"] == "append":
    if previous:
      lookup = {key: dict(value) for key, value in previous.get("lookup", {}).items()}
    else:
      for record in current["records"]:
        key = order_sku_key(record)
        if key and compact_text(record.get("shipmentNoticeNo")):
          item = lookup.setdefault(key, {"shipmentNoticeNo": "", "shipmentNoticeDate": ""})
          for field in item:
            item[field] = append_unique_text(item[field], record.get(field))
  for key, values in imported.items():
    item = lookup.setdefault(key, {"shipmentNoticeNo": "", "shipmentNoticeDate": ""})
    for field in item:
      item[field] = append_unique_text(item[field], values[field])
  keys = {order_sku_key(record) for record in current["records"]}
  matched_rows = sum(order_sku_key(record) in imported for record in current["records"])
  if not matched_rows:
    raise ValueError("没有匹配当前订单的出通单，原数据未修改")
  return {
    "lookup": lookup, "effectiveDate": current["asOfDate"],
    "sourceFile": compact_text(body.get("sourceFile"))[:250], "mode": body["mode"],
    "rowCount": len(rows), "keyCount": len(imported), "matchedRows": matched_rows,
    "unmatchedKeys": len(set(imported) - keys),
    "clearedRows": sum(bool(record.get("shipmentNoticeNo")) and order_sku_key(record) not in lookup for record in current["records"]),
    "generatedAt": now_iso(),
  }


def apply_shipment_notices(records, exclude_filename="", as_of_date=""):
  reference = read_json_file(PUBLIC_DATA_DIR / "shipment-reference.json", {})
  reference = shipment_reference_for_date(as_of_date, reference)
  if reference:
    apply_shipment_reference({"asOfDate": as_of_date, "records": records}, reference)
    return {"keys": len(reference.get("lookup", {})), "matchedRecords": sum(bool(row.get("shipmentNoticeNo")) for row in records)}
  lookup = shipment_notice_lookup(exclude_filename)
  matched = 0
  for record in records:
    item = lookup.get(order_sku_key(record))
    if not item:
      record.setdefault("shipmentNoticeNo", "")
      record.setdefault("shipmentNoticeDate", "")
      continue
    before_no = compact_text(record.get("shipmentNoticeNo"))
    before_date = compact_text(record.get("shipmentNoticeDate"))
    record["shipmentNoticeNo"] = append_unique_text(before_no, item.get("shipmentNoticeNo"))
    record["shipmentNoticeDate"] = append_unique_text(before_date, item.get("shipmentNoticeDate"))
    if record["shipmentNoticeNo"] or record["shipmentNoticeDate"]:
      matched += 1
  return {"keys": len(lookup), "matchedRecords": matched}


def data_file_target(filename):
  persistent = PUBLIC_DATA_DIR / filename
  if persistent.exists():
    return persistent
  return ROOT / "public" / "data" / filename


def cookie_session_id(headers):
  cookie = SimpleCookie(headers.get("Cookie", ""))
  morsel = cookie.get(SESSION_COOKIE)
  return morsel.value if morsel else ""


def cleanup_sessions():
  now = datetime.now(timezone.utc)
  expired = [sid for sid, session in SESSIONS.items() if session["expires"] <= now]
  for sid in expired:
    SESSIONS.pop(sid, None)


def create_session(user):
  cleanup_sessions()
  expires = datetime.now(timezone.utc) + SESSION_TTL
  token = sign_session_payload({
    "username": user["username"],
    "expires": int(expires.timestamp()),
    "nonce": secrets.token_urlsafe(12),
  })
  sid = token
  SESSIONS[sid] = {
    "username": user["username"],
    "role": user["role"],
    "expires": expires,
  }
  return sid


class Handler(BaseHTTPRequestHandler):
  server_version = "OrderDeliveryAuth/1.0"

  def log_message(self, fmt, *args):
    print(f"{self.address_string()} - {fmt % args}", flush=True)

  def send_json(self, status, payload):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    self.send_response(status)
    self.send_header("Content-Type", "application/json; charset=utf-8")
    self.send_header("Content-Length", str(len(body)))
    self.send_header("Cache-Control", "no-store")
    self.end_headers()
    self.wfile.write(body)

  def send_error_json(self, status, message):
    self.send_json(status, {"error": message})

  def current_user(self):
    sid = cookie_session_id(self.headers)
    if not sid:
      return None
    with LOCK:
      cleanup_sessions()
      session = SESSIONS.get(sid)
      if not session:
        payload = unsign_session_payload(sid)
        if not payload or int(payload.get("expires") or 0) <= int(datetime.now(timezone.utc).timestamp()):
          return None
        session = {
          "username": str(payload.get("username") or ""),
          "role": "",
          "expires": datetime.fromtimestamp(int(payload["expires"]), timezone.utc),
        }
        SESSIONS[sid] = session
      store = load_store()
      user = find_user(store, session["username"])
      if not user or not user.get("active", True):
        return None
      session["expires"] = datetime.now(timezone.utc) + SESSION_TTL
      return public_user(user)

  def require_user(self):
    user = self.current_user()
    if not user:
      self.send_error_json(HTTPStatus.UNAUTHORIZED, "请先登录")
      return None
    return user

  def require_admin(self):
    user = self.require_user()
    if not user:
      return None
    if user.get("role") != "admin":
      self.send_error_json(HTTPStatus.FORBIDDEN, "当前账号没有管理员权限")
      return None
    return user

  def do_GET(self):
    path = urlparse(self.path).path
    if path == '/api/customer-receivables':
      if not self.require_admin():
        return
      try:
        payload = CUSTOMER_RECEIVABLES.fetch(parse_qs(urlparse(self.path).query, keep_blank_values=True))
        self.send_json(HTTPStatus.OK, payload)
      except ValueError as error:
        self.send_error_json(HTTPStatus.BAD_REQUEST, str(error))
      except Exception:
        self.send_error_json(HTTPStatus.BAD_GATEWAY, '客户应收账款查询失败，请稍后重试或检查数仓连接')
      return
    if path == '/api/customer-ratings/versions':
      if not self.require_admin():
        return
      try:
        query = parse_qs(urlparse(self.path).query)
        offset = max(0, int(query.get('offset', ['0'])[0]))
        limit = min(100, max(1, int(query.get('limit', ['50'])[0])))
        self.send_json(HTTPStatus.OK, CUSTOMER_RATINGS.score_versions(query.get('customerId', [''])[0], offset, limit, keyword=query.get('keyword', [''])[0], actor=query.get('actor', [''])[0], latest=query.get('latest', ['0'])[0] == '1'))
      except (ValueError, TypeError):
        self.send_error_json(HTTPStatus.BAD_REQUEST, '无效的历史查询参数')
      return
    if path in ('/api/customer-ratings', '/api/customer-scoring'):
      user = self.require_user() if path == '/api/customer-scoring' else self.require_admin()
      if not user:
        return
      try:
        if path == '/api/customer-scoring':
          now = datetime.now(timezone(timedelta(hours=8)))
          year, month = now.year, now.month
        else:
          year = int(parse_qs(urlparse(self.path).query).get('year', [datetime.now(timezone(timedelta(hours=8))).year])[0])
          month = int(parse_qs(urlparse(self.path).query).get('month', [datetime.now(timezone(timedelta(hours=8))).month])[0])
        snapshot = CUSTOMER_RATINGS.snapshot(year, month)
        self.send_json(HTTPStatus.OK, scoring_view(snapshot, user) if path == '/api/customer-scoring' else snapshot)
      except (ValueError, TypeError):
        self.send_error_json(HTTPStatus.BAD_REQUEST, '无效的分析年份')
      except Exception:
        self.send_error_json(HTTPStatus.INTERNAL_SERVER_ERROR, '客户等级数据读取失败')
      return
    if path == "/api/customer-sales":
      if not self.require_admin():
        return
      try:
        with LOCK:
          payload = read_snapshot(DATA_DIR)
        payload['databaseSync'] = WAREHOUSE_SALES.status()
        self.send_json(HTTPStatus.OK, payload)
      except (OSError, ValueError):
        self.send_error_json(HTTPStatus.INTERNAL_SERVER_ERROR, "销售数据读取失败，请联系管理员")
      return
    if path == "/api/me":
      user = self.require_user()
      if user:
        self.send_json(HTTPStatus.OK, {"user": user})
      return
    if path == "/api/users":
      if not self.require_admin():
        return
      with LOCK:
        users = [public_user(user) for user in load_store().get("users", [])]
      self.send_json(HTTPStatus.OK, {"users": users})
      return
    if path == "/api/login-logs":
      if not self.require_admin():
        return
      with LOCK:
        logs = read_login_logs()
      self.send_json(HTTPStatus.OK, {"logs": logs})
      return
    if path.startswith("/public/data/"):
      user = self.require_user()
      if not user:
        return
      self.serve_data(path, user)
      return
    self.serve_static(path)

  def do_POST(self):
    path = urlparse(self.path).path
    if path in ('/api/customer-ratings/sync', '/api/customer-ratings/scores', '/api/customer-ratings/review', '/api/customer-scoring/scores'):
      user = self.require_user() if path == '/api/customer-scoring/scores' else self.require_admin()
      if not user:
        return
      try:
        length = int(self.headers.get('Content-Length', '0'))
        if length <= 0 or length > 16384:
          raise ValueError('请求内容长度无效')
        payload = json.loads(self.rfile.read(length))
        if not isinstance(payload, dict):
          raise ValueError('请求格式无效')
        if path == '/api/customer-scoring/scores':
          now = datetime.now(timezone(timedelta(hours=8)))
          year, month = now.year, now.month
          payload.update(year=year, month=month)
        else:
          year = int(payload.get('year', datetime.now(timezone(timedelta(hours=8))).year))
          month = int(payload.get('month', datetime.now(timezone(timedelta(hours=8))).month))
        if path.endswith('/sync'):
          result = CUSTOMER_RATINGS.sync(year, month)
        elif path.endswith('/scores'):
          portfolio = None
          if path == '/api/customer-scoring/scores':
            portfolio = customer_portfolio(user)
            if portfolio is not None and str(payload.get('customerId', '')) not in portfolio['editableCustomerIds']:
              self.send_error_json(HTTPStatus.FORBIDDEN, '只能为自己负责的客户评分')
              return
          CUSTOMER_RATINGS.update_scores(payload, user['username'], user.get('remark', ''))
          result = CUSTOMER_RATINGS.snapshot(year, month)
          if path == '/api/customer-scoring/scores':
            result = scoring_view(result, user, portfolio)
        else:
          count = CUSTOMER_RATINGS.review(payload, user['username'])
          result = CUSTOMER_RATINGS.snapshot(year, month)
          result['changedCount'] = count
        self.send_json(HTTPStatus.OK, result)
      except (ValueError, TypeError) as error:
        self.send_error_json(HTTPStatus.CONFLICT, str(error))
      except Exception:
        self.send_error_json(HTTPStatus.BAD_GATEWAY, '处理失败，已保留上次数据，请稍后重试')
      return
    if path == "/api/sync-customer-sales":
      if not self.require_admin():
        return
      try:
        payload = WAREHOUSE_SALES.run()
        payload['databaseSync'] = WAREHOUSE_SALES.status()
        self.send_json(HTTPStatus.OK, payload)
      except ValueError as error:
        self.send_error_json(HTTPStatus.CONFLICT, str(error))
      except Exception:
        self.send_error_json(HTTPStatus.BAD_GATEWAY, "数仓同步失败，已保留上次销售数据，请稍后重试")
      return
    if path == "/api/import-customer-sales":
      self.import_customer_sales()
      return
    if path == "/api/login":
      self.login()
      return
    if path == "/api/logout":
      sid = cookie_session_id(self.headers)
      with LOCK:
        SESSIONS.pop(sid, None)
      self.send_response(HTTPStatus.NO_CONTENT)
      self.send_header("Set-Cookie", f"{SESSION_COOKIE}=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax")
      self.end_headers()
      return
    if path == "/api/users":
      self.create_user()
      return
    if path == "/api/import-daily":
      self.import_daily()
      return
    if path == "/api/import-kitting-reference":
      self.import_kitting_reference()
      return
    if path == "/api/import-shipment-notices":
      self.import_shipment_notices()
      return
    self.send_error_json(HTTPStatus.NOT_FOUND, "接口不存在")

  def do_PATCH(self):
    path = urlparse(self.path).path
    if path.startswith("/api/users/"):
      self.update_user(unquote(path.removeprefix("/api/users/")))
      return
    self.send_error_json(HTTPStatus.NOT_FOUND, "接口不存在")

  def do_DELETE(self):
    path = urlparse(self.path).path
    if path.startswith("/api/users/"):
      self.delete_user(unquote(path.removeprefix("/api/users/")))
      return
    self.send_error_json(HTTPStatus.NOT_FOUND, "接口不存在")

  def login(self):
    try:
      body = parse_body(self)
    except Exception:
      self.send_error_json(HTTPStatus.BAD_REQUEST, "登录参数格式错误")
      return
    username = str(body.get("username") or "").strip()
    password = str(body.get("password") or "")
    with LOCK:
      store = load_store()
      user = find_user(store, username)
      if not user or not user.get("active", True) or not verify_password(password, user):
        self.send_error_json(HTTPStatus.UNAUTHORIZED, "用户名或密码错误")
        return
      user["lastLogin"] = now_iso()
      try:
        save_store(store)
      except OSError as exc:
        print(f"Could not update user store after login: {exc}", flush=True)
      try:
        append_login_log(self, user)
      except OSError as exc:
        print(f"Could not append login log: {exc}", flush=True)
      sid = create_session(user)
      public = public_user(user)
    self.send_response(HTTPStatus.OK)
    self.send_header("Content-Type", "application/json; charset=utf-8")
    self.send_header("Set-Cookie", f"{SESSION_COOKIE}={sid}; Path=/; Max-Age={int(SESSION_TTL.total_seconds())}; HttpOnly; SameSite=Lax")
    body = json.dumps({"user": public}, ensure_ascii=False).encode("utf-8")
    self.send_header("Content-Length", str(len(body)))
    self.send_header("Cache-Control", "no-store")
    self.end_headers()
    self.wfile.write(body)

  def create_user(self):
    if not self.require_admin():
      return
    try:
      body = parse_body(self)
    except Exception:
      self.send_error_json(HTTPStatus.BAD_REQUEST, "账号参数格式错误")
      return
    username = str(body.get("username") or "").strip()
    password = str(body.get("password") or "")
    role = str(body.get("role") or "viewer")
    if not username or len(username) > 40:
      self.send_error_json(HTTPStatus.BAD_REQUEST, "用户名不能为空且不能超过40个字符")
      return
    if not password or len(password) < 6:
      self.send_error_json(HTTPStatus.BAD_REQUEST, "密码至少6位")
      return
    if role not in {"admin", "viewer"}:
      self.send_error_json(HTTPStatus.BAD_REQUEST, "角色不正确")
      return
    with LOCK:
      store = load_store()
      if find_user(store, username):
        self.send_error_json(HTTPStatus.CONFLICT, "用户名已存在")
        return
      hashed = hash_password(password)
      user = {
        "username": username,
        "role": role,
        "active": True,
        "salt": hashed["salt"],
        "passwordHash": hashed["hash"],
        "iterations": hashed["iterations"],
        "createdAt": now_iso(),
        "lastLogin": "",
        "remark": str(body.get("remark") or "").strip()[:100],
      }
      store.setdefault("users", []).append(user)
      save_store(store)
    self.send_json(HTTPStatus.CREATED, {"user": public_user(user)})

  def update_user(self, username):
    admin = self.require_admin()
    if not admin:
      return
    try:
      body = parse_body(self)
    except Exception:
      self.send_error_json(HTTPStatus.BAD_REQUEST, "账号参数格式错误")
      return
    with LOCK:
      store = load_store()
      user = find_user(store, username)
      if not user:
        self.send_error_json(HTTPStatus.NOT_FOUND, "用户不存在")
        return
      if username == admin["username"] and ("active" in body or body.get("role") == "viewer"):
        self.send_error_json(HTTPStatus.BAD_REQUEST, "不能停用自己或移除自己的管理员权限")
        return
      if "username" in body:
        target = str(body["username"] or "").strip()
        if not target or len(target) > 40:
          self.send_error_json(HTTPStatus.BAD_REQUEST, "用户名不能为空且不能超过40个字符")
          return
        if target != username and find_user(store, target):
          self.send_error_json(HTTPStatus.CONFLICT, "用户名已存在")
          return
        if username == admin["username"] and target != username:
          self.send_error_json(HTTPStatus.BAD_REQUEST, "不能修改当前登录账号用户名")
          return
        user["username"] = target
      if "remark" in body:
        user["remark"] = str(body["remark"] or "").strip()[:100]
      if "role" in body:
        role = str(body.get("role") or "")
        if role not in {"admin", "viewer"}:
          self.send_error_json(HTTPStatus.BAD_REQUEST, "角色不正确")
          return
        user["role"] = role
      if "active" in body:
        user["active"] = bool(body.get("active"))
      if "password" in body:
        password = str(body.get("password") or "")
        if len(password) < 6:
          self.send_error_json(HTTPStatus.BAD_REQUEST, "密码至少6位")
          return
        hashed = hash_password(password)
        user["salt"] = hashed["salt"]
        user["passwordHash"] = hashed["hash"]
        user["iterations"] = hashed["iterations"]
      save_store(store)
      public = public_user(user)
    self.send_json(HTTPStatus.OK, {"user": public})

  def delete_user(self, username):
    admin = self.require_admin()
    if not admin:
      return
    if username == admin["username"]:
      self.send_error_json(HTTPStatus.BAD_REQUEST, "不能删除当前登录账号")
      return
    with LOCK:
      store = load_store()
      users = store.get("users", [])
      user = find_user(store, username)
      if not user:
        self.send_error_json(HTTPStatus.NOT_FOUND, "用户不存在")
        return
      store["users"] = [item for item in users if item.get("username") != username]
      save_store(store)
      for sid, session in list(SESSIONS.items()):
        if session.get("username") == username:
          SESSIONS.pop(sid, None)
    self.send_json(HTTPStatus.OK, {"deleted": True, "username": username})

  def import_kitting_reference(self):
    user = self.require_admin()
    if not user:
      return
    try:
      length = int(self.headers.get("Content-Length") or 0)
      if length <= 0 or length > 12 * 1024 * 1024:
        self.close_connection = True
        self.send_error_json(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "导入数据为空或超过 12MB")
        return
      payload = build_kitting_reference(parse_body(self))
    except (ValueError, TypeError, OverflowError) as exc:
      self.send_error_json(HTTPStatus.BAD_REQUEST, str(exc))
      return
    payload["importedBy"] = user["username"]
    try:
      with LOCK:
        target = PUBLIC_DATA_DIR / "kitting-reference.json"
        previous = data_file_target("kitting-reference.json")
        if previous.exists():
          backup = DATA_DIR / "kitting-reference-history" / (datetime.now().strftime("%Y%m%d%H%M%S%f") + "-" + secrets.token_hex(4) + ".json")
          write_json_atomic(backup, read_json_file(previous, {}))
        write_json_atomic(target, payload)
    except (OSError, ValueError):
      self.send_error_json(HTTPStatus.INTERNAL_SERVER_ERROR, "保存失败，旧数据未替换，请重试")
      return
    self.send_json(HTTPStatus.OK, {"saved": True, "reference": payload})

  def import_shipment_notices(self):
    user = self.require_admin()
    if not user:
      return
    try:
      length = int(self.headers.get("Content-Length") or 0)
      if length <= 0 or length > 12 * 1024 * 1024:
        self.close_connection = True
        self.send_error_json(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "导入数据为空或超过12MB")
        return
      body = parse_body(self)
      with LOCK:
        current = read_json_file(data_file_target("orders.json"), {})
        previous = read_json_file(PUBLIC_DATA_DIR / "shipment-reference.json", {})
        if not current.get("records") or not current.get("asOfDate"):
          raise ValueError("请先导入订单三表")
        if previous.get("effectiveDate", "") > current["asOfDate"]:
          raise ValueError("当前订单日期早于已导入的出通单日期，请先加载最新订单数据")
        revision = hashlib.sha256(json.dumps([current, previous], sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        apply_shipment_reference(current, previous)
        payload = build_shipment_import(body, current, previous)
        summary = {key: value for key, value in payload.items() if key != "lookup"}
        if body.get("commit") is not True:
          self.send_json(HTTPStatus.OK, {"preview": summary, "revision": revision})
          return
        if body.get("revision") != revision:
          self.send_error_json(HTTPStatus.CONFLICT, "订单或出通单已更新，请重新预览后导入")
          return
        payload["importedBy"] = user["username"]
        versions = ([{key: value for key, value in previous.items() if key != "history"}] + previous.get("history", [])) if previous else []
        payload["history"] = [item for item in versions if item.get("effectiveDate") != payload["effectiveDate"]]
        backup = DATA_DIR / "shipment-import-history" / (datetime.now().strftime("%Y%m%d%H%M%S%f") + "-" + secrets.token_hex(4) + ".json")
        write_json_atomic(backup, {"previousReference": previous, "currentOrders": current})
        write_json_atomic(PUBLIC_DATA_DIR / "shipment-reference.json", payload)
      self.send_json(HTTPStatus.OK, {"saved": True, "summary": summary})
    except (ValueError, TypeError, OverflowError) as exc:
      self.send_error_json(HTTPStatus.BAD_REQUEST, str(exc))
    except OSError:
      self.send_error_json(HTTPStatus.INTERNAL_SERVER_ERROR, "保存失败，请重新预览后重试")

  def import_daily(self):
    if not self.require_admin():
      return
    try:
      body = parse_body(self)
    except Exception:
      self.send_error_json(HTTPStatus.BAD_REQUEST, "导入数据格式错误")
      return
    raw_as_of_date = str(body.get("asOfDate") or "")[:10]
    generated_at = str(body.get("generatedAt") or now_iso())
    as_of_date = import_as_of_date(raw_as_of_date, generated_at)
    if len(as_of_date) != 10 or as_of_date[4] != "-" or as_of_date[7] != "-":
      self.send_error_json(HTTPStatus.BAD_REQUEST, "判定日期格式不正确")
      return
    records = body.get("records")
    if not isinstance(records, list) or not records:
      self.send_error_json(HTTPStatus.BAD_REQUEST, "导入记录为空")
      return
    raw_label = str(body.get("label") or "")
    label = label_for_date(as_of_date) if not raw_label or raw_label == label_for_date(raw_as_of_date) else raw_label
    filename = f"orders-{as_of_date}.json"
    shipment_match = apply_shipment_notices(records, as_of_date=as_of_date)
    sources = body.get("sources") if isinstance(body.get("sources"), dict) else {}
    sources["shipmentNoticeKeys"] = shipment_match["keys"]
    sources["shipmentNoticeMatched"] = shipment_match["matchedRecords"]
    payload = {
      "asOfDate": as_of_date,
      "label": label,
      "generatedAt": generated_at,
      "sources": sources,
      "metrics": body.get("metrics") if isinstance(body.get("metrics"), dict) else {},
      "records": records,
    }
    history_path = data_file_target("daily-history.json")
    history_payload = read_json_file(history_path, {"datasets": []})
    datasets = history_payload.get("datasets", [])
    entry = {
      "date": as_of_date,
      "label": payload["label"],
      "file": filename,
      "generatedAt": payload["generatedAt"],
      "sources": payload["sources"],
      "records": len(records),
      "metrics": payload["metrics"],
    }
    datasets = [item for item in datasets if item.get("date") != as_of_date]
    datasets.append(entry)
    datasets.sort(key=lambda item: item.get("date", ""))
    with LOCK:
      write_json_atomic(PUBLIC_DATA_DIR / filename, payload)
      write_json_atomic(PUBLIC_DATA_DIR / "orders.json", payload)
      write_json_atomic(PUBLIC_DATA_DIR / "daily-history.json", {"datasets": datasets})
    self.send_json(HTTPStatus.OK, {"saved": True, "asOfDate": as_of_date, "file": filename, "records": len(records), "history": datasets, "shipmentNoticeMatched": shipment_match["matchedRecords"]})

  def import_customer_sales(self):
    user = self.require_admin()
    if not user:
      return
    try:
      length = int(self.headers.get("Content-Length") or 0)
      if not 0 < length <= MAX_BODY_BYTES:
        self.send_error_json(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "销售导入数据为空或超过16MB")
        return
      body = parse_body(self)
      snapshot = normalize_snapshot(body)
      if type(body.get("previewOnly")) is not bool:
        raise ValueError("缺少导入预览标记")
      with LOCK:
        previous = read_snapshot(DATA_DIR)
        if body["previewOnly"]:
          result = {"preview": True, "revision": previous.get("revision", ""), "summary": summarize(snapshot)}
        else:
          if body.get("expectedRevision") != previous.get("revision", ""):
            self.send_error_json(HTTPStatus.CONFLICT, "销售数据已被更新，请重新预览后导入")
            return
          result = save_snapshot(DATA_DIR, snapshot, previous, user["username"])
      self.send_json(HTTPStatus.OK, result)
    except (ValueError, TypeError, OverflowError) as error:
      self.send_error_json(HTTPStatus.BAD_REQUEST, str(error))
    except OSError:
      self.send_error_json(HTTPStatus.INTERNAL_SERVER_ERROR, "销售数据保存失败，未完成导入，请重试")

  def serve_static(self, request_path):
    clean = posixpath.normpath(unquote(request_path)).lstrip("/")
    if clean in {"", "."}:
      clean = "index.html"
    target = (ROOT / clean).resolve()
    if Path(clean).name in PRIVATE_FILES or any(Path(clean).name.startswith(name + '.') for name in PRIVATE_FILES):
      self.send_error_json(HTTPStatus.FORBIDDEN, "私有配置不允许访问")
      return
    # Protect alternate/encoded static paths as well as the normal dataset endpoint.
    data_roots = (DATA_DIR.resolve(), (ROOT / 'data').resolve(), (ROOT / 'public/data').resolve())
    if any(target == root or root in target.parents for root in data_roots) or target.suffix.lower() in {'.json','.jsonl','.csv','.xlsx','.xls','.zip','.gz','.sqlite','.db'}:
      if not self.require_admin():
        return
    # Sales snapshots and backups are private, including paths through the data symlink.
    if Path(clean).name == "sales-analysis.json" or "sales-analysis-history" in Path(clean).parts or target == (DATA_DIR / "sales-analysis.json").resolve() or (DATA_DIR / "sales-analysis-history").resolve() in target.parents or target.name.startswith("sales-analysis-") and target.suffix == ".tmp":
      self.send_error_json(HTTPStatus.FORBIDDEN, "销售数据需通过授权接口访问")
      return
    if ROOT not in target.parents and target != ROOT:
      self.send_error(HTTPStatus.FORBIDDEN)
      return
    if target.is_dir():
      target = target / "index.html"
    if not target.exists() or not target.is_file():
      target = ROOT / "index.html"
    content_type = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
    data = target.read_bytes()
    self.send_response(HTTPStatus.OK)
    self.send_header("Content-Type", content_type)
    self.send_header("Content-Length", str(len(data)))
    self.send_header("Cache-Control", "no-store")
    self.end_headers()
    self.wfile.write(data)

  def serve_data(self, request_path, user):
    clean = posixpath.normpath(unquote(request_path)).lstrip("/")
    if user.get('role') != 'admin' and Path(clean).suffix.lower() != '.json':
      self.send_error_json(HTTPStatus.FORBIDDEN, '查看账号没有文件下载权限')
      return
    if Path(clean).name in PRIVATE_FILES or any(Path(clean).name.startswith(name + '.') for name in PRIVATE_FILES):
      self.send_error_json(HTTPStatus.FORBIDDEN, "私有配置不允许访问")
      return
    data_prefix = "public/data/"
    if clean.startswith(data_prefix):
      target = data_file_target(Path(clean).name).resolve()
      allowed_roots = (ROOT.resolve(), PUBLIC_DATA_DIR.resolve())
    else:
      target = (ROOT / clean).resolve()
      allowed_roots = (ROOT.resolve(),)
    if not any(root in target.parents or target == root for root in allowed_roots):
      self.send_error_json(HTTPStatus.FORBIDDEN, "文件路径不允许")
      return
    if not target.exists() or not target.is_file():
      self.send_error_json(HTTPStatus.NOT_FOUND, "数据文件不存在")
      return
    if target.suffix.lower() == ".json":
      payload = json.loads(target.read_text(encoding="utf-8"))
      if isinstance(payload, dict) and isinstance(payload.get("records"), list) and target.name.startswith("orders"):
        apply_shipment_reference(payload)
      data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
      self.send_response(HTTPStatus.OK)
      self.send_header("Content-Type", "application/json; charset=utf-8")
      self.send_header("Content-Length", str(len(data)))
      self.send_header("Cache-Control", "no-store")
      self.end_headers()
      self.wfile.write(data)
      return
    content_type = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
    data = target.read_bytes()
    self.send_response(HTTPStatus.OK)
    self.send_header("Content-Type", content_type)
    self.send_header("Content-Length", str(len(data)))
    self.send_header("Cache-Control", "no-store")
    self.end_headers()
    self.wfile.write(data)


def main():
  parser = argparse.ArgumentParser()
  parser.add_argument("--host", default="127.0.0.1")
  parser.add_argument("--port", type=int, default=6812)
  args = parser.parse_args()
  with LOCK:
    load_store()
  server = ThreadingHTTPServer((args.host, args.port), Handler)
  WAREHOUSE_SALES.start()
  CUSTOMER_RATINGS.start()
  print(f"Order delivery server listening on http://{args.host}:{args.port}", flush=True)
  server.serve_forever()


if __name__ == "__main__":
  main()
