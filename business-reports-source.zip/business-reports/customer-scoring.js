const groups = [
  {name:'业务机会', weight:10, shares:[40,30,30], keys:[['cooperationPotential','合作潜力'],['futureOrders','后续订单'],['expansionSpace','拓展空间']]},
  {name:'行业地位', weight:5, shares:[50,50], keys:[['industryInfluence','行业影响力'],['benchmarkValue','营业额']]}
];
const fields=groups.flatMap(g=>g.keys), levels=[0,20,40,60,80,100];
const fmt=v=>v==null?'待评分':Number(v).toFixed(2);
export function detailHistory(event,esc) {
  return event.after?.scoreDetails ? `<p>${fields.map(([key,label])=>`${label}：${esc(String(event.before?.scoreDetails?.[key]??'未评'))} → ${esc(String(event.after.scoreDetails[key]))}`).join('；')}</p>` : '';
}
export function openScoreDialog({record:r,revision,year,month,api,esc,onSaved,endpoint="/api/customer-ratings/scores",canEditIdentity=true}) {
  if(r.scoreNotApplicable)return null;
  const dialog=document.createElement('dialog');dialog.className='cr-dialog cs-dialog';
  dialog.innerHTML=`<button class="ghost-button cr-close" aria-label="关闭">×</button><h2>客户评分</h2><p>${esc(r.customerName)} <span class="subtle">${esc(r.customerId)}</span></p>
  ${!r.scoreDetails?'<p class="cs-notice">尚未录入五项明细。非新客户且年度销货净额达到5万元时需填写；S类免评分条件下保留已有分值。</p>':''}
  <form class="cs-form">  <div class="cs-identity"><label>是否为新客户（必选）<select name="newCustomer" aria-label="客户身份" required ${canEditIdentity?'':'disabled'}><option value="" ${r.newCustomer==null?'selected':''}>请先选择客户身份</option><option value="true" ${r.newCustomer===true?'selected':''}>新客户（固定S）</option><option value="false" ${r.newCustomer===false?'selected':''}>非新客户</option></select></label><span class="subtle">信誉度由应收日期与订单交期两个维度自动计算，当前 ${fmt(r.credit)} 分。新客户或年度销货净额不足5万元直接归S，无需五项评分。</span></div><p class="cs-identity-hint" role="status"></p>${groups.map((g,i)=>`<fieldset><legend>${g.name}<span>综合权重 ${g.weight}%</span></legend><div class="cs-score-grid">${g.keys.map(([key,label],j)=>`<label>${label}（${g.shares[j]}%）<select name="${key}" required aria-label="${label}"><option value="">请选择分数</option>${levels.map(v=>`<option value="${v}" ${r.scoreDetails?.[key]===v?'selected':''}>${v} 分</option>`).join('')}</select></label>`).join('')}</div><p class="cs-average" data-average="${i}"></p></fieldset>`).join('')}

  <p class="subtle cs-save-note">组内按各细项权重计算后计入综合分，显示两位小数。每次保存生成独立历史版本，记录操作账号和时间；当前等级随评分自动升降。</p><p class="cr-error" role="alert"></p><div class="cs-footer"><button type="button" class="ghost-button" data-cancel>取消</button><button class="primary-button" type="submit">保存评分</button></div></form>`;
  document.body.append(dialog); const form=dialog.querySelector('form');let saving=false;
  const close=()=>{if(!saving)dialog.close();};dialog.querySelector('.cr-close').onclick=close;dialog.querySelector('[data-cancel]').onclick=close;
  dialog.addEventListener('cancel',e=>{if(saving)e.preventDefault();});dialog.addEventListener('close',()=>dialog.remove());
  const identity=form.elements.namedItem('newCustomer');
  const exempt=()=>identity.value==='true'||r.lowSales===true;
  const identityReady=()=>['true','false'].includes(identity.value);
  function preview(){
    const readyIdentity=identityReady();
    const oldNotice=dialog.querySelector('.cs-notice');if(oldNotice)oldNotice.hidden=exempt();
    form.querySelector('.cs-save-note').textContent=exempt()?'本次仅保存客户身份并生成历史版本，已有评分保留，不重新填写五项分值。':'五项按组内权重计算，保存后更新综合分和等级，并生成历史版本。';
    form.querySelectorAll('fieldset').forEach(el=>{el.hidden=exempt();el.disabled=saving||!readyIdentity||exempt();});
    form.querySelector('[type="submit"]').disabled=saving||!readyIdentity;
    form.querySelector('.cs-identity-hint').textContent=exempt()?(identity.value==='true'?'新客户':'年度销货净额不足5万元')+'：直接归为S类，无需填写五项评分，保存身份即可。已有评分保留。':readyIdentity?'':'请先选择“新客户”或“非新客户”，再填写五项评分。';form.querySelector('[type="submit"]').textContent=exempt()?'保存身份':'保存评分';
    groups.forEach((g,i)=>{const values=g.keys.map(([key])=>form.elements.namedItem(key).value);const ready=values.every(v=>v!=='');const avg=values.reduce((s,v,j)=>s+Number(v)*g.shares[j]/100,0);dialog.querySelector(`[data-average="${i}"]`).textContent=!readyIdentity?'确认客户身份后可评分':ready?`项目得分 ${fmt(avg)}　·　加权分 ${fmt(avg*g.weight/100)}`:'请完成本组各项评分';});
  }
  form.addEventListener('change',preview);preview();
  form.onsubmit=async e=>{e.preventDefault();if(saving)return;if(!identityReady()){preview();identity.focus();return;}if(!form.reportValidity())return;
    const values=new FormData(form);const payload={year,month,customerId:r.customerId,revision,customerRevision:r.customerRevision,newCustomer:values.get('newCustomer')===''?null:values.get('newCustomer')==='true'};
    if(!exempt())payload.scoreDetails=Object.fromEntries(fields.map(([key])=>[key,Number(values.get(key))]));
    if (!canEditIdentity) delete payload.newCustomer;
    saving=true;form.querySelector('[role="alert"]').textContent='';form.querySelectorAll('button,select').forEach(el=>el.disabled=true);
    try {const result=await api(endpoint,{method:'POST',body:JSON.stringify(payload)});dialog.close();onSaved(result);}
    catch(error){form.querySelector('[role="alert"]').textContent=error.message;}
    finally{saving=false;form.querySelectorAll('button,select').forEach(el=>el.disabled=false);if(!canEditIdentity)form.elements.namedItem('newCustomer').disabled=true;preview();}
  };
  dialog.showModal();return dialog;
}
export function createCustomerScoring({root,api,isAdmin,canScore=isAdmin,escapeHtml:esc}) {
  let data=null,busy=false,error='',page=1,keyword='',person='',industry='',group='',grade='',status='',generation=0,dialog=null,notice='';
  const ownPerson=()=>data?.scope?.bound&&!data.scope.allCustomers?(data.scope.isManager?'':data.scope.employeeCode):'';
  const memberOptions=()=>data?.scope?.members||[...new Set((data?.records||[]).map(r=>r.salesPerson).filter(Boolean))].sort().map(name=>({employeeCode:name,salesPerson:name}));
  function draw(){if(!canScore()){root.innerHTML='';return;}
    const rows=(data?.records||[]).filter(r=>(!keyword||`${r.customerId} ${r.customerName}`.toLowerCase().includes(keyword.toLowerCase()))&&(!person||(r.employeeCode||r.salesPerson)===person)&&(!industry||r.industry===industry)&&(!group||r.customerGroup===group)&&(!grade||r.currentGrade===grade)&&(!status||(status==='done'?(r.scoreExempt||!!r.scoreDetails):(!r.scoreExempt&&!r.scoreDetails))));
    const pages=Math.max(1,Math.ceil(rows.length/30));page=Math.min(page,pages);const complete=(data?.records||[]).filter(r=>r.scoreExempt||r.scoreDetails).length;
    root.innerHTML=`<div class="section-head"><div><h2>客户综合分析</h2><p class="subtle">${data?.scope?.allCustomers?'全部客户':data?.scope?.bound?`${data.scope.isManager?`${esc(data.scope.teamName)} · 本人及直属下属客户`:'仅本人客户'} · 工号 ${esc(data.scope.employeeCode)} · ${esc(data.scope.salesPerson)}`:data?'账号未绑定业务员工号，请联系管理员':'正在读取客户范围…'} · 保存后自动联动综合评级</p></div><button class="ghost-button" data-action="refresh" ${busy?'disabled':''}>${busy?'加载中…':'刷新'}</button></div>
    <div class="cs-rule"><strong>评分档位：0、20、40、60、80、100 分</strong><span>业务机会＝合作潜力×40%＋后续订单×30%＋拓展空间×30%，综合权重10%；行业地位＝行业影响力×50%＋营业额×50%，综合权重5%。</span><span>综合得分＝销售额80%＋业务机会10%＋信誉度5%＋行业地位5%。销售分：≥100万元记100分，其余按万元四舍五入取整。保存后更新综合分，当前等级随评分自动升降。</span></div>
    ${error?`<p class="cr-error" role="alert">${esc(error)}</p>`:''}${notice?`<p class="cs-notice" role="status">${esc(notice)}</p>`:''}
    <form class="cs-filters"><label>客户编号／名称<input name="keyword" value="${esc(keyword)}" placeholder="客户编号或名称"></label><label>业务员<select name="person"><option value="">全部业务员</option>${memberOptions().map(v=>`<option value="${esc(v.employeeCode)}" ${v.employeeCode===person?'selected':''}>${esc(v.salesPerson)}${data?.scope?.isManager?`（${esc(v.employeeCode)}${v.employeeCode===data.scope.employeeCode?' · 本人':''}）`:''}</option>`).join('')}</select></label><label>行业<select name="industry"><option value="">全部行业</option>${[...new Set((data?.records||[]).map(r=>r.industry).filter(Boolean))].sort().map(v=>`<option value="${esc(v)}" ${v===industry?'selected':''}>${esc(v)}</option>`).join('')}</select></label><label>客户分组<select name="group"><option value="">全部客户</option>${['普通客户','经销商','废料回收'].map(v=>`<option value="${v}" ${v===group?'selected':''}>${v}</option>`).join('')}</select></label><label>等级<select name="grade"><option value="">全部等级</option>${['A','B','C','D','S','免评分'].map(v=>`<option value="${v}" ${v===grade?'selected':''}>${v}</option>`).join('')}</select></label><label>评分状态<select name="status"><option value="">全部</option><option value="pending" ${status==='pending'?'selected':''}>待补细项</option><option value="done" ${status==='done'?'selected':''}>已完成／免评分</option></select></label><button class="primary-button">查询</button><button type="button" class="ghost-button" data-action="reset">重置</button></form>
    <div class="cr-view-row"><span>客户 ${data?.records?.length||0} 家 · 已完成／免评分 ${complete} 家 · 当前筛选 ${rows.length} 家</span><span class="subtle">废料回收客户免评分；新客户或年度净额不足5万元免五项评分，其他未录入客户保留历史总分</span></div>
    <div class="cs-table-scroll"><table class="cs-table"><thead><tr><th rowspan="2">客户编号／名称</th><th colspan="4">业务机会 · 10%</th><th colspan="3">行业地位 · 5%</th><th rowspan="2">综合得分</th><th rowspan="2">当前等级</th><th rowspan="2">操作</th></tr><tr>${groups.map(g=>g.keys.map(([,label],j)=>`<th>${label}<small>${g.shares[j]}%</small></th>`).join('')+'<th>项目得分</th>').join('')}</tr></thead><tbody>${rows.slice((page-1)*30,page*30).map(r=>`<tr><td><strong>${esc(r.customerId)}</strong><span>${esc(r.customerName)}</span><small>${esc(r.salesPerson||'未分配业务员')} · ${esc(r.customerGroup||'普通客户')} · ${esc(r.industry||'未填写行业')}</small></td>${groups.map((g,i)=>g.keys.map(([key])=>`<td>${r.scoreExempt?'免评分':r.scoreDetails?.[key]??'未评'}</td>`).join('')+`<td class="cs-total">${r.scoreExempt?'免评分':fmt(i===0?r.opportunity:r.position)}${!r.scoreExempt&&!r.scoreDetails?'<small>历史总分</small>':''}</td>`).join('')}<td>${r.scoreExempt?'免评分':r.totalScore??'待评分'}</td><td>${esc(r.currentGrade||'待评分')}</td><td><span class="cs-identity-status ${r.scoreNotApplicable?'is-not-applicable':typeof r.newCustomer==='boolean'?'is-confirmed':'is-pending'}">${r.scoreNotApplicable?'废料回收 · 免评分':r.newCustomer===true?'已确认 · 新客户':r.newCustomer===false?'已确认 · 非新客户':'待确认身份'}</span>${r.canEditScore!==false?`<button class="ghost-button" data-customer="${esc(r.customerId)}">${r.scoreExempt?(typeof r.newCustomer==='boolean'?'修改身份':'确认身份'):r.scoreDetails?'修改评分':'评分'}</button>`:'<span class="subtle">仅查看</span>'}</td></tr>`).join('')||`<tr><td colspan="11">${busy?'正在读取客户…':'没有符合条件的客户'}</td></tr>`}</tbody></table></div>
    <div class="cr-pagination"><span>${page} / ${pages} 页 · 每页30家</span><button class="ghost-button" data-action="prev" ${page===1?'disabled':''}>上一页</button><button class="ghost-button" data-action="next" ${page===pages?'disabled':''}>下一页</button></div>`;
  }
  async function load(){if(busy||!canScore())return;const current=++generation;busy=true;error='';draw();try{const result=await api('/api/customer-scoring');if(current===generation){data=result;if(ownPerson())person=ownPerson();}}catch(e){if(current===generation)error=e.message;}finally{if(current===generation){busy=false;draw();}}}
  root.addEventListener('submit',e=>{if(!e.target.matches('.cs-filters'))return;e.preventDefault();const values=new FormData(e.target);keyword=String(values.get('keyword')).trim();person=values.get('person');industry=values.get('industry');group=values.get('group');grade=values.get('grade');status=values.get('status');page=1;draw();});
  root.addEventListener('click',e=>{const button=e.target.closest('button');if(!button)return;if(button.dataset.customer){const r=data.records.find(r=>r.customerId===button.dataset.customer);if(r.canEditScore===false)return;const {year,month}=data;dialog=openScoreDialog({record:r,revision:data.revision,year,month,api,esc,endpoint:"/api/customer-scoring/scores",canEditIdentity:canScore(),onSaved:result=>{data=result;if(ownPerson())person=ownPerson();notice=`已保存 ${r.customerName}，当前等级已自动更新。`;draw();}});return;}
    switch(button.dataset.action){case 'refresh':notice='';return load();case 'reset':keyword='';person=ownPerson();industry='';group='';grade='';status='';page=1;break;case 'prev':page--;break;case 'next':page++;break;default:return;}draw();
  });
  return {render(){if(!busy)load();else draw();},reset(){generation++;busy=false;data=null;dialog?.close();root.innerHTML='';}};
}
