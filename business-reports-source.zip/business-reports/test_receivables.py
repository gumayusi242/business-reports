import unittest
from datetime import date
from decimal import Decimal

from customer_receivables import CustomerReceivables,query_options,where_clause,money,read_date


class ReceivablesTests(unittest.TestCase):
    def test_scope_exact_ids_and_fail_closed(self):
        class Ratings:
            def snapshot(self,year,month):
                return {'ready':True,'period':'2026-10','records':[{'customerId':'0001'},{'customerId':'0001'},{'customerId':'0002'}]}
        reader=CustomerReceivables(None,Ratings())
        self.assertEqual(reader.customer_scope(date(2026,10,27)),(['0001','0002'],'2026-10'))
        reader.customer_ratings.snapshot=lambda *args:{'ready':False,'records':[{'customerId':'0001'}]}
        with self.assertRaises(ValueError):reader.customer_scope(date(2026,10,27))
        reader.customer_ratings.snapshot=lambda *args:{'ready':True,'records':[]}
        self.assertEqual(reader.customer_scope(date(2026,10,27))[0],[])

    def test_defaults(self):
        options=query_options({})
        self.assertEqual(options['status'],'open')
        self.assertEqual(options['pageSize'],50)
        self.assertEqual(options['start'],'')

    def test_invalid_options(self):
        for params in [{'view':['unknown']},{'view':['detail']},{'orderNo':['x'*61]},
                       {'status':['anything']},{'dateBasis':['oma01;DROP']},{'page':['-1']},{'pageSize':['1000']},
                       {'start':['2026-10-28'],'end':['2026-10-01']},{'start':['2026-02-30']},
                       {'start':['26-1-1']},{'keyword':['a'*101]}]:
            with self.assertRaises(ValueError):query_options(params)

    def test_bound_parameters(self):
        options=query_options({'keyword':["x%' OR 1=1 --_"]})
        sql,params=where_clause(options,date(2026,10,27))
        self.assertNotIn('OR 1=1',sql)
        self.assertIn("x!%' OR 1=1 --!_",params[2])
        self.assertEqual(params[1],date(2026,10,28))
        self.assertIn('a.oma00 LIKE %s',sql)
        self.assertEqual(params[0],'1%')
        self.assertIn("a.omaconf='Y'",sql)
        self.assertIn('a.oma61 > 0',sql)

    def test_date_basis_and_overdue(self):
        opts=query_options({'dateBasis':['due'],'start':['2026-10-01'],'end':['2026-10-27'],'status':['overdue']})
        sql,params=where_clause(opts,date(2026,10,27))
        self.assertIn('a.oma11 >= %s',sql)
        self.assertIn('a.oma11 < %s',sql)
        self.assertEqual(params[-1],date(2026,10,28))

    def test_amount_precision_and_missing_values(self):
        self.assertEqual(money(Decimal('123456789.125')),'123456789.13')
        self.assertEqual(money('-10.005'),'-10.01')
        self.assertIsNone(money(None))
        self.assertEqual(money(0),'0.00')
        self.assertEqual(read_date(None),'')
        self.assertEqual(read_date(date(2026,10,27)),'2026-10-27')


if __name__=='__main__':unittest.main()
