const GRADES = ['V', 'A', 'B', 'C', 'D', 'S'];
const number = (value, digits = 0) => Number(value).toLocaleString('zh-CN', {minimumFractionDigits: digits, maximumFractionDigits: digits});

export function parseSalesRows(rows, sourceFile) {
  const aliases = {customerId: ['客户编号', '客户编码'], customerName: ['客户简称', '客户名称'],
    industry: ['行业'], grade: ['改后等级'], salesPerson: ['业务员'], amount: ['销货额', '销货金额']};
  const headerIndex = rows.findIndex((row, index) => index < 20 && row.some(value => aliases.customerId.includes(String(value).trim())) && row.some(value => aliases.amount.includes(String(value).trim())));
  if (headerIndex < 0) throw new Error('第一张工作表未找到客户编号、销货额表头');
  const header = rows[headerIndex].map(value => String(value ?? '').trim());
  const columns = Object.fromEntries(Object.entries(aliases).map(([key, names]) => [key, header.findIndex(value => names.includes(value))]));
  for (const key of ['customerId', 'grade', 'industry', 'amount']) {
    if (columns[key] < 0) throw new Error(`缺少必填列：${aliases[key][0]}`);
  }
  const records = [], seen = new Set();
  rows.slice(headerIndex + 1).forEach((row, offset) => {
    if (row.every(value => value == null || String(value).trim() === '')) return;
    const line = headerIndex + offset + 2;
    const get = key => String(row[columns[key]] ?? '').trim();
    const customerId = get('customerId'), grade = get('grade').toUpperCase();
    if (!customerId) throw new Error(`第${line}行缺少客户编号`);
    if (seen.has(customerId)) throw new Error(`第${line}行客户编号重复：${customerId}；请提供每客户一行的汇总表`);
    seen.add(customerId);
    if (!GRADES.includes(grade)) throw new Error(`第${line}行改后等级无效，仅支持 V/A/B/C/D/S`);
    const amount = get('amount').replace(/[,，]/g, '');
    if (!/^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i.test(amount) || !Number.isFinite(Number(amount))) throw new Error(`第${line}行销货额不是有效数字`);
    records.push({customerId, customerName: get('customerName'), industry: get('industry'), salesPerson: get('salesPerson'), grade, amount});
  });
  if (!records.length) throw new Error('没有可导入的客户明细');
  if (records.length > 50000) throw new Error('客户明细不能超过50,000行');
  return {sourceFile, records};
}

export function salesGroups(records, mergeV) {
  const grades = mergeV ? GRADES.slice(1) : GRADES;
  const groups = grades.map(grade => ({grade, records: [], amount: 0}));
  for (const record of records) {
    const grade = mergeV && record.grade === 'V' ? 'A' : record.grade;
    const group = groups.find(item => item.grade === grade);
    group.records.push(record);
    group.amount += Number(record.amount);
  }
  return groups;
}

export function filterSalesDetails(records, filters) {
  const query = filters.query.trim().toLocaleLowerCase('zh-CN');
  return records.filter(row =>
    (!query || String(row.customerId).toLocaleLowerCase('zh-CN').includes(query) || String(row.customerName).toLocaleLowerCase('zh-CN').includes(query)) &&
    (!filters.industry || row.industry === filters.industry.slice(6)) &&
    (!filters.grade || row.grade === filters.grade) &&
    (filters.minimum === '' || Number(row.amount) >= Number(filters.minimum)) &&
    (filters.maximum === '' || Number(row.amount) <= Number(filters.maximum))
  );
}

export function createSalesAnalysis({root, api, isAdmin, parseXlsxRows, escapeHtml: esc}) {
  let dataset = null, loading = null, generation = 0;
  let scope = 'all', salesPerson = '', mergeV = true, selectedGrade = '', page = 0;
  let notice = '', failed = false, activeDialog = null, syncing = false;
  const emptyDetailFilters = () => ({query: '', industry: '', grade: '', minimum: '', maximum: ''});
  let detailFilters = emptyDetailFilters(), detailGroup = null;
  const PAGE_SIZE = 30;

  function resetDetailFilters() { detailFilters = emptyDetailFilters(); page = 0; }

  function reset() {
    generation += 1;
    dataset = null; loading = null; notice = ''; failed = false;
    syncing = false;
    scope = 'all'; salesPerson = ''; mergeV = true; selectedGrade = ''; page = 0;
    resetDetailFilters(); detailGroup = null;
    activeDialog?.close();
    root.replaceChildren();
  }

  async function load() {
    if (loading || !isAdmin()) return;
    const token = generation;
    loading = api('/api/customer-sales');
    try { const next = await loading; if (token === generation && isAdmin()) dataset = next; }
    catch (error) { if (token === generation) {notice = error.message; failed = true;} }
    finally { if (token === generation) {loading = null; draw();} }
  }

  function render() {
    if (!isAdmin()) {root.textContent = '当前账号没有客户销售数据查看权限。'; return;}
    draw();
    if (!dataset && !loading && !failed) load();
  }

  function draw() {
    if (!isAdmin()) return;
    const rows = dataset?.records || [];
    const filtered = rows.filter(row => (scope === 'all' || (row.industry === '经销商@经销商') === (scope === 'dealer')) && (!salesPerson || row.salesPerson === salesPerson));
    const groups = salesGroups(filtered, mergeV);
    detailGroup = groups.find(group => group.grade === selectedGrade) || null;
    const total = filtered.reduce((sum, row) => sum + Number(row.amount), 0);
    const names = [...new Set(rows.map(row => row.salesPerson).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'zh-CN'));
    const maxAmount = Math.max(1, ...groups.map(group => Math.abs(group.amount)));
    const maxCount = Math.max(1, ...groups.map(group => group.records.length));
    const period = dataset?.periodStart ? `${dataset.periodStart} 至 ${dataset.periodEnd} · 人民币 · 销货净额` : '尚未导入销售数据';
    const sync = dataset?.databaseSync;
    root.innerHTML = `<div class="section-head"><div><h2>客户销售额等级分析</h2><div class="hint">${esc(period)}</div></div><div class="sales-actions"><button type="button" class="ghost-button" data-sales-refresh>刷新</button>${sync?.enabled ? `<button type="button" class="primary-button" data-sales-sync ${syncing || sync.running ? 'disabled' : ''}>${syncing || sync.running ? '同步中…' : '同步数据库'}</button>` : ''}</div></div>
      ${sync?.enabled ? `<div class="sales-sync-meta hint">数仓自动更新：每天08:00${sync.lastSuccess ? ` · 最近同步 ${esc(new Date(sync.lastSuccess).toLocaleString('zh-CN',{hour12:false}))}` : ''}${sync.warehouseUpdatedAt ? ` · 数仓更新时间 ${esc(sync.warehouseUpdatedAt)}` : ''}${sync.lastError ? ` <span class="sales-error">${esc(sync.lastError)}</span>` : ''}</div>` : ''}
      <div class="sales-feedback ${failed ? 'sales-error' : ''}" role="status">${esc(notice)}</div>
      ${dataset ? `<div class="sales-filterbar"><label>客户范围<select data-sales-scope><option value="all">全部客户</option><option value="dealer">经销商@经销商</option><option value="other">其他行业</option></select></label><label>业务员<select data-sales-person><option value="">全部业务员</option>${names.map(name => `<option value="${esc(name)}">${esc(name)}</option>`).join('')}</select></label><label>等级统计口径<select data-sales-mode><option value="merge">V并入A（仅统计）</option><option value="original">原等级（V单列）</option></select></label><aside class="sales-grade-guide" aria-label="客户等级含义"><span>V：签约经销商</span><span>A：100万及以上</span><span>B：50万至不足100万</span><span>C：20万至不足50万</span><span>D：5万至不足20万</span><span>S：不足5万或新客户</span><small>金额单位：人民币元 · 经销商沿用原等级 · V统计时可并入A</small></aside></div>
      <div class="sales-matrix-wrap"><table class="sales-matrix" aria-label="客户销售额等级矩阵"><thead><tr><th scope="col">等级</th><th scope="col">客户数（家）</th><th scope="col">金额（万元）</th><th scope="col">总额占比</th></tr></thead><tbody>${groups.map(group => {
        const share = total > 0 ? group.amount / total * 100 : null;
        return `<tr data-sales-grade="${group.grade}" class="${selectedGrade === group.grade ? 'sales-selected' : ''}"><th scope="row">${group.grade}${mergeV && group.grade === 'A' ? '<small>含V</small>' : ''}</th><td><button type="button" class="sales-count" data-sales-detail="${group.grade}" aria-label="查看${group.grade}类${group.records.length}家客户明细" aria-pressed="${selectedGrade === group.grade}">${number(group.records.length)}</button><div class="sales-track"><span style="width:${group.records.length / maxCount * 100}%"></span></div></td><td><strong>${number(group.amount / 10000, 2)}</strong><div class="sales-track sales-amount-track"><span class="${group.amount < 0 ? 'sales-negative' : ''}" style="width:${Math.abs(group.amount) / maxAmount * 100}%"></span></div></td><td class="sales-share">${share === null ? '—' : `${number(share, 2)}%`}</td></tr>`;
      }).join('')}</tbody><tfoot><tr><th scope="row">合计</th><td>${number(filtered.length)}</td><td>${number(total / 10000, 2)}</td><td>${total > 0 ? '100.00%' : '—'}</td></tr></tfoot></table></div>
      <div class="sales-provenance hint">等级来源：改后等级 · 经销商价格等级保留原值${total <= 0 ? ' · 净额不大于0，占比不适用' : ''}</div>
      ${detailGroup ? detailMarkup(detailGroup) : ''}
      <div class="sales-source hint">${esc(dataset.sourceFile || '')}${dataset.importedAt ? ` · 导入时间 ${esc(new Date(dataset.importedAt).toLocaleString('zh-CN', {hour12:false}))}` : ''}</div>` : `<div class="empty">${failed ? '销售数据加载失败，请刷新重试。' : '正在加载销售数据…'}</div>`}`;
    root.querySelector('[data-sales-refresh]').addEventListener('click', () => {notice = ''; failed = false; load();});
    root.querySelector('[data-sales-sync]')?.addEventListener('click', async () => {
      if (syncing || !isAdmin()) return;
      const token = generation;
      syncing = true; notice = '正在同步数仓…'; failed = false; draw();
      try {
        const saved = await api('/api/sync-customer-sales',{method:'POST',body:'{}'});
        if (token !== generation || !isAdmin()) return;
        generation++; loading = null; dataset = saved;
        resetDetailFilters(); notice = `同步成功：${number(saved.records.length)}家客户`;
      } catch (error) {if (token === generation) {notice = error.message; failed = true;}}
      finally {syncing = false; draw();}
    });
    if (!dataset) return;
    const scopeInput = root.querySelector('[data-sales-scope]'); scopeInput.value = scope;
    scopeInput.addEventListener('change', () => {scope = scopeInput.value; resetDetailFilters(); draw();});
    const personInput = root.querySelector('[data-sales-person]'); personInput.value = salesPerson;
    personInput.addEventListener('change', () => {salesPerson = personInput.value; resetDetailFilters(); draw();});
    const modeInput = root.querySelector('[data-sales-mode]'); modeInput.value = mergeV ? 'merge' : 'original';
    modeInput.addEventListener('change', () => {mergeV = modeInput.value === 'merge'; selectedGrade = ''; resetDetailFilters(); draw();});
    root.querySelectorAll('[data-sales-detail]').forEach(button => button.addEventListener('click', () => {selectedGrade = selectedGrade === button.dataset.salesDetail ? '' : button.dataset.salesDetail; resetDetailFilters(); draw();}));
    bindDetailEvents();
  }

  function detailMarkup(group) {
    if (!group) return '';
    const records = filterSalesDetails(group.records, detailFilters).sort((a, b) => Number(b.amount) - Number(a.amount));
    const amount = records.reduce((sum, row) => sum + Number(row.amount), 0);
    const industries = [...new Set(group.records.map(row => row.industry))].sort((a, b) => a.localeCompare(b, 'zh-CN'));
    if (detailFilters.industry && !industries.includes(detailFilters.industry.slice(6))) industries.push(detailFilters.industry.slice(6));
    const grades = GRADES.filter(grade => group.records.some(row => row.grade === grade) || detailFilters.grade === grade);
    const pages = Math.max(1, Math.ceil(records.length / PAGE_SIZE)); page = Math.min(page, pages - 1);
    return `<section class="sales-details"><div class="business-month-head"><h3>${group.grade}类客户明细</h3><span class="hint" data-detail-summary aria-live="polite">筛选 ${number(records.length)} / 本类 ${number(group.records.length)} 家 · 销货额 ${number(amount, 2)} 元</span></div>
      <form class="sales-detail-filters" aria-label="客户明细筛选">
        <label class="sales-detail-query">客户编号 / 客户简称<input type="search" name="query" value="${esc(detailFilters.query)}" placeholder="编号或名称关键词"></label>
        <label>行业<select name="industry"><option value="">全部行业</option>${industries.map(industry => `<option value="${esc('value:' + industry)}" ${detailFilters.industry === 'value:' + industry ? 'selected' : ''}>${esc(industry || '未填写')}</option>`).join('')}</select></label>
        <label>原表等级<select name="grade"><option value="">全部等级</option>${grades.map(grade => `<option value="${grade}" ${detailFilters.grade === grade ? 'selected' : ''}>${grade}</option>`).join('')}</select></label>
        <label>销货额下限（元）<input type="number" step="any" name="minimum" value="${esc(detailFilters.minimum)}" placeholder="不限"></label>
        <label>销货额上限（元）<input type="number" step="any" name="maximum" value="${esc(detailFilters.maximum)}" placeholder="不限"></label>
        <div class="sales-detail-actions"><button type="submit" class="primary-button">筛选</button><button type="button" class="ghost-button" data-detail-clear>重置</button></div>
        <div class="sales-error" data-detail-error role="alert" hidden></div>
      </form>
      <div class="sales-detail-scroll"><table aria-label="客户销售明细"><thead><tr><th>客户编号</th><th>客户简称</th><th>行业</th><th>原表等级</th><th>业务员</th><th class="num">销货额（元）</th></tr></thead><tbody>${records.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE).map(row => `<tr><td>${esc(row.customerId)}</td><td>${esc(row.customerName)}</td><td>${esc(row.industry)}</td><td>${esc(row.grade)}</td><td>${esc(row.salesPerson)}</td><td class="num">${number(row.amount, 2)}</td></tr>`).join('') || '<tr><td colspan="6" class="empty-cell">没有符合筛选条件的客户</td></tr>'}</tbody></table></div><footer class="customer-orders-pagination"><span>${page + 1} / ${pages} 页 · ${number(records.length)}家</span><button type="button" data-sales-prev aria-label="上一页" title="上一页" ${page === 0 ? 'disabled' : ''}>‹</button><button type="button" data-sales-next aria-label="下一页" title="下一页" ${page + 1 === pages ? 'disabled' : ''}>›</button></footer></section>`;
  }

  function redrawDetails(focusName = '') {
    const section = root.querySelector('.sales-details');
    if (!section || !detailGroup) return;
    const scrollTop = root.scrollTop;
    section.outerHTML = detailMarkup(detailGroup);
    bindDetailEvents();
    root.scrollTop = scrollTop;
    root.querySelector('.sales-detail-filters')?.elements.namedItem(focusName)?.focus({preventScroll:true});
  }

  function bindDetailEvents() {
    const form = root.querySelector('.sales-detail-filters');
    if (!form) return;
    const apply = () => {
      if (!form.reportValidity()) return;
      const next = Object.fromEntries(Object.keys(detailFilters).map(key => [key, form.elements.namedItem(key).value.trim()]));
      if (next.minimum !== '' && next.maximum !== '' && Number(next.minimum) > Number(next.maximum)) {
        const error = form.querySelector('[data-detail-error]');
        error.textContent = '销货额下限不能大于上限'; error.hidden = false;
        return;
      }
      const focusName = form.contains(document.activeElement) ? document.activeElement.name : '';
      detailFilters = next; page = 0; redrawDetails(focusName);
    };
    form.addEventListener('submit', event => {event.preventDefault(); apply();});
    form.querySelectorAll('select').forEach(select => select.addEventListener('change', apply));
    form.querySelector('[data-detail-clear]').addEventListener('click', () => {resetDetailFilters(); redrawDetails('query');});
    root.querySelector('[data-sales-prev]')?.addEventListener('click', () => {page--; redrawDetails();});
    root.querySelector('[data-sales-next]')?.addEventListener('click', () => {page++; redrawDetails();});
  }

  function openImport() {
    if (!isAdmin() || activeDialog) return;
    const dialog = document.createElement('dialog');
    activeDialog = dialog;
    dialog.className = 'sales-import-dialog';
    dialog.setAttribute('aria-label', '销售 Excel 导入');
    dialog.innerHTML = `<header class="delay-drill-head"><h2>销售 Excel 导入</h2><button type="button" data-close aria-label="关闭">×</button></header><form><label>客户销售汇总表（.xlsx）<input type="file" name="file" accept=".xlsx" required></label><div class="sales-date-fields"><label>统计开始日期<input type="date" name="start" required value="${esc(dataset?.periodStart || '')}"></label><label>统计结束日期<input type="date" name="end" required value="${esc(dataset?.periodEnd || '')}"></label></div><p class="hint">必填列：客户编号、行业、改后等级、销货额（元）。每客户一行，读取第一张工作表。</p><p class="hint">完整替换本模块销售数据；订单数据和 ERP 价格等级不变。</p><div data-import-result role="status" aria-live="polite">等待选择文件</div><footer><button type="submit" class="ghost-button">预览校验</button><button type="button" class="primary-button" data-save disabled>确认导入</button></footer></form>`;
    document.body.append(dialog); dialog.showModal();
    const form = dialog.querySelector('form'), result = dialog.querySelector('[data-import-result]');
    const save = dialog.querySelector('[data-save]'), previewButton = form.querySelector('[type="submit"]');
    const fields = [form.elements.file, form.elements.start, form.elements.end];
    let prepared = null, busy = false;
    const close = () => {if (!busy) dialog.close();};
    dialog.querySelector('[data-close]').addEventListener('click', close);
    dialog.addEventListener('cancel', event => {if (busy) event.preventDefault();});
    dialog.addEventListener('close', () => {activeDialog = null; dialog.remove(); root.querySelector('[data-sales-import]')?.focus();}, {once:true});
    fields.forEach(field => field.addEventListener('change', () => {prepared = null; save.disabled = true; result.textContent = '待预览校验'; result.classList.remove('sales-error');}));
    const setBusy = value => {busy = value; fields.forEach(field => field.disabled = value); previewButton.disabled = value; save.disabled = value || !prepared; dialog.querySelector('[data-close]').disabled = value;};
    form.addEventListener('submit', async event => {
      event.preventDefault();
      if (busy || !form.reportValidity()) return;
      prepared = null; setBusy(true); result.textContent = '正在解析并校验…'; result.classList.remove('sales-error');
      try {
        const file = form.elements.file.files[0];
        if (!file || !/\.xlsx$/i.test(file.name)) throw new Error('请选择 .xlsx 格式的客户销售汇总表');
        if (file.size > 20 * 1024 * 1024) throw new Error('Excel 文件不能超过20MB');
        if (form.elements.start.value > form.elements.end.value) throw new Error('统计开始日期不能晚于结束日期');
        let rows;
        try {rows = await parseXlsxRows(file);} catch {throw new Error('无法读取 Excel，请使用未加密且可正常打开的 .xlsx 文件');}
        const body = {...parseSalesRows(rows, file.name), periodStart: form.elements.start.value, periodEnd: form.elements.end.value};
        const preview = await api('/api/import-customer-sales', {method:'POST', body:JSON.stringify({...body, previewOnly:true})});
        prepared = {...body, expectedRevision: preview.revision};
        result.innerHTML = `<strong>校验通过：${number(preview.summary.customers)}家 · ${number(Number(preview.summary.amount) / 10000, 2)}万元</strong><table class="sales-preview-table"><thead><tr><th>原表等级</th><th>客户数</th><th>金额（万元）</th></tr></thead><tbody>${GRADES.map(grade => `<tr><td>${grade}</td><td>${number(preview.summary.grades[grade].count)}</td><td>${number(Number(preview.summary.grades[grade].amount) / 10000, 2)}</td></tr>`).join('')}</tbody></table>`;
      } catch (error) {result.textContent = error.message; result.classList.add('sales-error');}
      finally {setBusy(false);}
    });
    save.addEventListener('click', async () => {
      if (busy || !prepared || !isAdmin()) return;
      setBusy(true); result.textContent = '正在保存…'; result.classList.remove('sales-error');
      try {
        const saved = await api('/api/import-customer-sales', {method:'POST', body:JSON.stringify({...prepared, previewOnly:false})});
        generation += 1; loading = null; dataset = {...saved, databaseSync: dataset?.databaseSync};
        scope = 'all'; salesPerson = ''; selectedGrade = ''; page = 0;
        resetDetailFilters();
        notice = `导入成功：${number(dataset.records.length)}家客户`; failed = false;
        draw(); dialog.close();
      } catch (error) {prepared = null; result.textContent = `${error.message}，请重新预览核对后再导入`; result.classList.add('sales-error');}
      finally {setBusy(false);}
    });
  }
  window.setInterval(() => {
    if (dataset?.databaseSync?.enabled && root.classList.contains('active') && document.visibilityState === 'visible' && isAdmin() && !syncing && !activeDialog) load();
  }, 60000);
  return {render, reset};
}
